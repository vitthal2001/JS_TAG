package com.workday.sample;

import static com.capeclear.assembly.annotation.Component.Type.mediation;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import com.capeclear.assembly.annotation.Property.Edit;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
import java.util.UUID;


@Component(
        name = "ManifestFileCreation",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/MessageDigest_16.png",
        largeIconPath = "icons/MessageDigest_24.png"
        )
public class ManifestFileCreation {

	public String algorithm;
	
	
    @ComponentMethod
    public String process( InputStream input ) {
    	if ( ( algorithm == null ) || (algorithm.trim().length() == 0 )) {
    		throw new RuntimeException("Algorithm has not been configured");
    	}
    	
    	
        try {
        	//
        	// Obtain the specified digest algorithm
        	//
        	UUID uuid=UUID.randomUUID();
        	MediationContext context = MediationTube.getCurrentMediationContext();
        	MessageDigest message_digest = MessageDigest.getInstance( algorithm );
			
			//
			// Read the input message and create the digest
			//
			
			byte buffer[] = new byte[1024];
			int num_bytes;
			
			
			do {
				num_bytes = input.read(buffer);
				if ( num_bytes > 0 ) {
					message_digest.update(buffer, 0, num_bytes);
					
				}
			} while (num_bytes >= 0);

			byte digest[] = message_digest.digest();
			
			//
			// Convert the digest into a hexadecimal string
			//
			
			StringBuffer sb = new StringBuffer("");
			
			for (int i = 0; i < digest.length; i++) {
				sb.append(Integer.toString((digest[i] & 0xff) + 0x100, 16).substring(1));
			}
			
			//
			// and return the result to the calling assembly
			//
			
			String output_chksum = sb.toString();
			
			context.setProperty("cksum.value", output_chksum );
	        context.setProperty("random.uuid", uuid);
			
			return sb.toString();
			
			
		} catch (NoSuchAlgorithmException nsa_e) {
			throw new RuntimeException("No digest algorithm found for '" + algorithm +"'", nsa_e);
		} catch (IOException io_e) {
			throw new RuntimeException("An error occurred reading the input message", io_e);
		}
    }

	public String getAlgorithm() {
		return algorithm;
	}

	@Property(edit=Edit.DEFAULT, name="Algorithm", toolTip="The name of the message digest algorithm.  e.g. SHA-256 or MD5")
	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}
    
    
}

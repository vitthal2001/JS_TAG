package com.createXLS;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;



import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.apache.poi.ss.usermodel.CellType;


public class CSVToExcelConverter {

//	public static void main(String[] args) {
//		String fName = "abc.csv";
//	//	CSVToExcelConverter cs = new CSVToExcelConverter();
//		OutputStream ostr = null;
//		try {
//			FileInputStream fis = new FileInputStream(fName);
//			ostr = CSVToExcelConverter.createXLSFromCSV(fis, "|");
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//
//	}
	public static OutputStream createXLSFromCSV (InputStream fis, String delimiter) throws IOException
	{
		OutputStream osw = null;
		ArrayList arList=null;
		ArrayList al=null;
		BufferedReader myInput = null;
		String delimiterToUse = null;
		String thisLine;
		int count=0;

		myInput = new BufferedReader(new InputStreamReader(fis));
		int i=0;
		arList = new ArrayList();
		while ((thisLine = myInput.readLine()) != null)
		{
			al = new ArrayList();
			if (delimiter.equalsIgnoreCase("|")){
				delimiterToUse = "\\|";
				
			}
			else if (delimiter.equalsIgnoreCase(",")){
				delimiterToUse = ",";
			}
			String strar[] = thisLine.split(delimiterToUse);
			for(int j=0;j<strar.length;j++)
			{
				al.add(strar[j]);
			}
			arList.add(al);
			i++;
		}
		myInput.close();

		try
		{
			XSSFWorkbook hwb = new XSSFWorkbook();
			XSSFSheet sheet = hwb.createSheet("Sheet1");
			for(int k=0;k<arList.size();k++)
			{
				ArrayList ardata = (ArrayList)arList.get(k);
				XSSFRow row = sheet.createRow((short) 0+k);
				for(int p=0;p<ardata.size();p++)
				{
					XSSFCell cell = row.createCell((short) p);
					String data = ardata.get(p).toString();
					if(data.startsWith("=")){
				//		cell.setCellType(CellType.STRING);
						data=data.replaceAll("\"", "");
						data=data.replaceAll("=", "");
						cell.setCellValue(data);
					}else if(data.startsWith("\"")){
						data=data.replaceAll("\"", "");
				//		cell.setCellType(CellType.STRING);
						cell.setCellValue(data);
					}else{
						data=data.replaceAll("\"", "");
				//		cell.setCellType(CellType.NUMERIC);
						cell.setCellValue(data);
					}
				}
			}
		//	FileOutputStream fileOut = new FileOutputStream("test.xls");
			hwb.write(osw);
		//	fileOut.close();
			System.out.println("Your excel file has been generated");






		} catch ( Exception ex ) {
			ex.printStackTrace();
		}
		return osw; 
	}
}
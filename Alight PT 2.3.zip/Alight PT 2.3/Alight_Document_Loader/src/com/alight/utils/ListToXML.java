package com.alight.utils;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.io.ByteArrayOutputStream;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * Custom outtransport
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "ListToXML",
        type = outtransport,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/ListToXML_16.png",
        largeIconPath = "icons/ListToXML_24.png"
        )
public class ListToXML {

    /**
     * This method is called by the Assembly framework.    
     */
    @ComponentMethod
    public byte[] process(java.io.InputStream arg0) {
    	MediationContext ctx = MediationTube.getCurrentMediationContext();
    	final String hostname = (String) ctx.getProperty("lp.sftp.endpoint");
    	final String login = (String) ctx.getProperty("lp.username");
    	final String password = (String) ctx.getProperty("lp.password");
    	final String directory = (String) ctx.getProperty("lp.directory");
    	
		/////Write Creds to log////
    	// System.out.println("hostname : " + hostname);
    	//System.out.println("login : " + login);
    	//System.out.println("password : " + password);
    	//System.out.println("directory : " + directory);
    	
    	java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");

		JSch ssh = new JSch();
		Session session = null;

		try {
			session = ssh.getSession(login, hostname, 22);
			session.setConfig(config);
			session.setPassword(password);
			System.out.println("Before session connect");
			session.connect();
			System.out.println("After session connect");
			Channel channel = session.openChannel("sftp");
			System.out.println("before connect");
			channel.connect();
			System.out.println("After connect");
			ChannelSftp sftp = (ChannelSftp) channel;

			@SuppressWarnings("unchecked")
			Vector<ChannelSftp.LsEntry> files = sftp.ls(directory + "/*.*");
			
			//XML Output
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		    DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		    Document doc = docBuilder.newDocument();
		    Element rootElement = doc.createElement("FilesOnSFTPServer");
		    doc.appendChild(rootElement);
			
			for (ChannelSftp.LsEntry entry : files) {
				if (entry.getAttrs().isDir()) {
					continue;
				}
				Element file = doc.createElement("file");
		        rootElement.appendChild(file);
		        Attr attr = doc.createAttribute("nm");
		        attr.setValue(entry.getFilename());
		        file.setAttributeNode(attr);
		        attr = doc.createAttribute("sz");
		        attr.setValue(String.valueOf(entry.getAttrs().getSize()));
		        file.setAttributeNode(attr);
			}

	        TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        Transformer transformer = transformerFactory.newTransformer();
	        DOMSource source = new DOMSource(doc);
	        
	        ByteArrayOutputStream bos=new ByteArrayOutputStream();
	        StreamResult result=new StreamResult(bos);
	        transformer.transform(source, result);
	        return bos.toByteArray();

		} catch (JSchException | SftpException | ParserConfigurationException | TransformerException e) {
			e.printStackTrace();
			ctx.setException(e);
		}
		return null;
    }
}

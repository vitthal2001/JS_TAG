package com.alight.utils;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.util.Map;

/**
 * Custom outtransport
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "MultithreadedMgetAndBase64Encode",
        type = outtransport,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/MultithreadedMgetAndBase64Encode_16.png",
        largeIconPath = "icons/MultithreadedMgetAndBase64Encode_24.png"
        )
public class MultithreadedMgetAndBase64Encode {

    /**
     * This method is called by the Assembly framework.    
     */
	
	 
    @ComponentMethod
    public byte[] process(java.io.InputStream arg0) {
       	MediationContext ctx = MediationTube.getCurrentMediationContext();
    	
    	final String hostname = (String) ctx.getProperty("p.host.name");
    	final String login = (String) ctx.getProperty("p.login");
    	final String password = (String) ctx.getProperty("p.password");
    	final String directory = (String) ctx.getProperty("p.directory");
    	final int MTSFTPTPCount = Integer.parseInt((String) ctx.getProperty("p.MTSFTPTPCount"));
    	final int MTWSTPDivCount = Integer.parseInt((String) ctx.getProperty("p.MTWSTPDivCount"));
		
        /////Write Creds to log////
        //System.out.println("hostname : " + hostname);
        //System.out.println("login : " + login);
        //System.out.println("password : " + password);
        //System.out.println("directory : " + directory);
        //System.out.println("MTSFTPTPCount : " + MTSFTPTPCount);
        //System.out.println("MTWSTPDivCount : " + MTWSTPDivCount);

        @SuppressWarnings("unchecked")
		java.util.Map<String,String> allFileNames = (Map<String, String>) ctx.getProperty("p.file.names.map");

        return com.alight.utils.MultithreadedSftpGet.getAndProcessFiles(
        		
        		hostname, 
        		login, 
        		password, 
        		directory, 
        		allFileNames, 
        		MTSFTPTPCount, 
        		MTWSTPDivCount
        		);
       	
        
    }
}

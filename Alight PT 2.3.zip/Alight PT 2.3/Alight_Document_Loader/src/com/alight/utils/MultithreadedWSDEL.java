package com.alight.utils;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;

import static com.capeclear.assembly.annotation.Component.Type.*;


/**
 * Custom outtransport
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "MultithreadedWSDEL",
        type = outtransport,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/MultithreadedWSDEL_16.png",
        largeIconPath = "icons/MultithreadedWSDEL_24.png"
        )
public class MultithreadedWSDEL {
	private String root = "WSCalls";
	private String wsRequest = "Delete_Worker_Document_Request";
	/**
     * This method is called by the Assembly framework.    
     */
    @ComponentMethod
    public byte[] process(java.io.InputStream inStream) {
    	MediationContext ctx = MediationTube.getCurrentMediationContext();
    	
    	final String vEndPoint = ctx.getDynamicEndpoint();
    	final String vUserid = (String) ctx.getProperty("p.agg.ISUID") + "@" + ctx.getCustomerId();
    	final String vPassword = (String) ctx.getProperty("p.agg.ISUPWD");
    	String vpMode = (String) ctx.getProperty("p.agg.Vmode");
    	
		boolean vMode = true;
		if("1|true".contains(vpMode))
			vMode = true;
		else
			vMode = false;
		final int MTWSTPCount = Integer.parseInt((String) ctx.getProperty("p.agg.MTWSTPCount"));
		
		/////Write Creds to log////
		//System.out.println("vEndPoint : " + vEndPoint);
		//System.out.println("vUserid : " + vEndPoint);
		//System.out.println("vPassword : " + vPassword);
		//System.out.println("vpMode : " + vpMode);
		//System.out.println("vMode : " + vMode);
		
		return com.alight.utils.MultiThreadedSoapCallsVer2.processWSCalls(
				vEndPoint, 
				vUserid, 
				vPassword, 
				inStream, 
				root, 
				wsRequest, 
				vMode,
				MTWSTPCount);
        ////////////////////////////////
    }
}

package com.alight.utils;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;


/**
 * Custom outtransport
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "MgetAndBase64Encode",
        type = outtransport,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/MgetAndBase64Encode_16.png",
        largeIconPath = "icons/MgetAndBase64Encode_24.png"
        )
public class MgetAndBase64Encode {

    /**
     * This method is called by the Assembly framework.    
     */
    @ComponentMethod
    public byte[] process(java.io.InputStream arg0) {
       	MediationContext ctx = MediationTube.getCurrentMediationContext();
    	
    	String hostname = (String) ctx.getProperty("p.host.name");
		String login = (String) ctx.getProperty("p.login");
		String password = (String) ctx.getProperty("p.password");
		String directory = (String) ctx.getProperty("p.directory");

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ZipOutputStream zos = new ZipOutputStream(baos);
		
		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");

			JSch ssh = new JSch();
			Session session;

			session = ssh.getSession(login, hostname, 22);

			session.setConfig(config);
			session.setPassword(password);
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();

			ChannelSftp sftp = (ChannelSftp) channel;

			@SuppressWarnings("unchecked")
			java.util.Map<String,String> allFileNames = (Map<String, String>) ctx.getProperty("p.file.names.map");
			System.out.println("--------------Start-----------------------------");
			Iterator<Map.Entry<String, String>> iterator = allFileNames.entrySet().iterator();
			while (iterator.hasNext()) {
				Entry<String, String> entry = iterator.next();
				System.out.println("Reading file : " + entry.getKey());
				try {
				InputStream currFileStream = sftp.get(directory + "/" + entry.getKey());
				ZipEntry zentry = new ZipEntry(entry.getKey());
				zos.putNextEntry(zentry);
				zos.write(org.apache.commons.codec.binary.Base64.encodeBase64(IOUtils.toByteArray(currFileStream)));
				zos.closeEntry();
				}catch(Exception ex) {
					System.out.println("ERROR Reading file : " + entry.getKey());
				}
			}
			System.out.println("-------------End-------------------------------");
			
			channel.disconnect();
			channel = null;
			session.disconnect();
			session = null;
			zos.close();
			baos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
        return baos.toByteArray();
        }
}

package test;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import static com.capeclear.assembly.annotation.Component.Type.*;


/**
 * Custom out transport
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "test1",
        type = outtransport,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/test1_16.png",
        largeIconPath = "icons/test1_24.png"
        )
public class test1 {

    /**
     * This method is called by the Assembly framework.
     *
     * Use the <code>MediationContext</code> to access objects in the context,
     * such as the message, properties and variables e.g.
     * <ul>
     * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
     * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
     * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
     * </ul>    
     */
    @ComponentMethod
    public void process(com.capeclear.mediation.MediationContext arg0) {
        // TODO implement
    }
}

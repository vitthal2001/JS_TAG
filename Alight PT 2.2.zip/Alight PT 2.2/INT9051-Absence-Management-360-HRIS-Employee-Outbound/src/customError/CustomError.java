package customError;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.Property;
import com.capeclear.mediation.MediationAction;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.OnErrorHandler;
import static com.capeclear.assembly.annotation.Component.Type.*;

@Component(
        name = "CustomError",
        type = onerrorhandler,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/CustomError_16.png",
        largeIconPath = "icons/CustomError_24.png"
        )
public class CustomError implements OnErrorHandler {

    public String getId() {
        return null;
    }
    public interface OnErrorHandler {
        MediationAction handleError(MediationContext context);
    }


    public MediationAction handleError(MediationContext mediationContext) {
    	mediationContext.setException(null);
    	mediationContext.setErrorHandled(true);
        return null;
    }
}

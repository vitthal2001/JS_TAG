package com.alight.workday;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;
/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "MultipartCall",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/MultipartCall_16.png",
        largeIconPath = "icons/MultipartCall_24.png"
        )
public final class MultipartCall {
	private static final String LINE_FEED = "\r\n";
	private MediationContext ctx = null;
	private HttpURLConnection httpConn = null;
	private String charset = "UTF-8";
	private String content = null;
	private String boundary = null;
	private String urlEndpoint = null;
	private String bearertoken = null;
	private String asgSessionToken = null;
	private String restMethod = null;
	
	
    /**
     * This method is called by the Assembly framework.    
     * @throws Exception 
     */
    @ComponentMethod
    public void process(java.io.InputStream input, java.io.OutputStream output) throws Exception {
    	
       //////////Get PROPS/////////////    	
    	ctx = MediationTube.getCurrentMediationContext();
    	
    	urlEndpoint = (String) ctx.getProperty("url");
		if (urlEndpoint == null || urlEndpoint.isEmpty()) {
			Exception ex = new Exception("Endpoint cannot be empty. Cannot proceed.");
			ctx.setException(ex);
			throw ex;
		}
    	
		bearertoken = (String) ctx.getProperty("bearertoken");
		if (bearertoken == null || bearertoken.isEmpty()) {
			Exception ex = new Exception("Bearer token cannot be empty. Cannot proceed.");
			ctx.setException(ex);
			throw ex;
		}
		
		asgSessionToken = (String) ctx.getProperty("ASG-SessionToken");
		if (asgSessionToken == null || asgSessionToken.isEmpty()) {
			Exception ex = new Exception("ASG-SessionToken cannot be empty. Cannot proceed.");
			ctx.setException(ex);
			throw ex;
		}
		
		restMethod = (String) ctx.getProperty("rest.method");
		if (restMethod == null || restMethod.isEmpty()) {
			Exception ex = new Exception("Rest Method cannot be empty. Cannot proceed.");
			ctx.setException(ex);
			throw ex;
		}
		
    	boundary = System.currentTimeMillis() + "D";
        Charset utf8 = Charset.forName("UTF-8");
        
        try {
			content = IOUtils.toString(input, StandardCharsets.UTF_8);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
        
    	try {
    		
        URL url = new URL(urlEndpoint);
        
        httpConn = (HttpURLConnection) url.openConnection();
        httpConn.setUseCaches(false);
        httpConn.setDoOutput(true); 
        httpConn.setDoInput(true);
        if(restMethod == "POST") {
           httpConn.setRequestMethod("POST");
        }else {
           httpConn.setRequestMethod("PUT");
        }
        httpConn.setRequestProperty("ASG-SessionToken", asgSessionToken);
        httpConn.setRequestProperty("Authorization", "Bearer " + bearertoken);
        httpConn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        
        //Prepare payload
        OutputStream outputStream = httpConn.getOutputStream();
        PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream, charset), true);
        
        writer.append("--" + boundary).append(LINE_FEED);
        writer.append("Content-Disposition: form-data; name=\"job\"").append(LINE_FEED);
        writer.append("Content-Type: application/json; charset=" + charset).append(LINE_FEED);
        writer.append(LINE_FEED);
        writer.append(content).append(LINE_FEED);
        writer.append("--" + boundary + "--").append(LINE_FEED);
        writer.flush();
        writer.close();
        
        IOUtils.copy(httpConn.getInputStream(),output);
        
    	}catch(Exception ex) {
            try {
				IOUtils.copy(httpConn.getErrorStream(),output);
			} catch (IOException e) {
				e.printStackTrace();
			}
    		ex.printStackTrace();
    	}

    }
}

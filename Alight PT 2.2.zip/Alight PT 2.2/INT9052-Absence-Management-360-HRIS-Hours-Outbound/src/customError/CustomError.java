package customError;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.Property;
import com.capeclear.mediation.MediationAction;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.OnErrorHandler;
import static com.capeclear.assembly.annotation.Component.Type.*;

/**
 * Custom error handler.
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "CustomError",
        type = onerrorhandler,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/CustomError_16.png",
        largeIconPath = "icons/CustomError_24.png"
        )
public class CustomError implements OnErrorHandler {

    public String getId() {
        // TODO remove when SVR-3099 is fixed
        return null;
    }

    /**
     * <p>Called when an exception is raised and this error handler is in scope.</p>
     *
     * <p>To mark the error as handled use <code>mediationContext.setErrorHandled(true);</code></p>
     *
     * <p>To examine the exception raised use <code>mediationContext.getException();</code></p>
     *
     * <p>Use one of the static methods of <code>MediationAction</code> to return with i.e. one of
     * <code>invoke</code>, <code>invokeAndForget</code>, <code>returnWith</code> or <code>throwException</code></p>
     *
     * @param context Context containing current message being processed as the exception that
     *                caused the error to be raised.
     *
     * @return the next action to take
     */
    public MediationAction handleError(MediationContext mediationContext) {
    	mediationContext.setException(null);
    	mediationContext.setErrorHandled(true);
      	return MediationAction.returnWith(mediationContext);
    
    }
}

package com.alight.utils;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Objects;
import java.util.Random;

/**

*/
public class PasswordDigest {

	public static String CreateNonce() {
		byte[] newKeyResult;
		SecureRandom random = new SecureRandom();

		try {
			random = SecureRandom.getInstance("SHA1PRNG");
		} catch (NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		}
		byte nonce[] = new byte[16];
		random.nextBytes(nonce); // compute a 16 byte random

		newKeyResult = Base64.getEncoder().encode(nonce);
		String stringOut = new String(newKeyResult);
		// System.out.println("encoded Bytes " + stringOut);

		return stringOut;
	}
	
	public static String CreateUsernameToken() {
		return "UsernameToken-" + new CusRandomString(33).nextString().toUpperCase();
	}

	public static String GenerateDigest(String pnonce, String cdate, String in_passwd) {

		ByteBuffer buf1 = ByteBuffer.allocate(1000);

		buf1.put(Base64.getDecoder().decode(pnonce));

		try {
			buf1.put(cdate.toString().getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		}

		try {
			buf1.put(in_passwd.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

		byte[] toHash = new byte[buf1.position()];

		buf1.rewind();
		buf1.get(toHash);

		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA-1");
		} catch (NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		}

		byte[] hash = md.digest(toHash);

		String pword = new String(Base64.getEncoder().encode(hash));

		return pword.toString();
	}
	
}

class CusRandomString {
	public String nextString() {
        for (int idx = 0; idx < buf.length; ++idx)
            buf[idx] = symbols[random.nextInt(symbols.length)];
        return new String(buf);
    }

    public static final String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    public static final String lower = "abcdefghijklmnopqrstuvwxyz";

    public static final String digits = "0123456789";

    public static final String alphanum = upper + lower + digits;

    private final Random random;

    private final char[] symbols;

    private final char[] buf;

    public CusRandomString(int length, Random random, String symbols) {
        if (length < 1) throw new IllegalArgumentException();
        if (symbols.length() < 2) throw new IllegalArgumentException();
        this.random = Objects.requireNonNull(random);
        this.symbols = symbols.toCharArray();
        this.buf = new char[length];
    }

    public CusRandomString(int length, Random random) {
        this(length, random, alphanum);
    }

    public CusRandomString(int length) {
        this(length, new SecureRandom());
    }

    public CusRandomString() {
        this(21);
    }
}	

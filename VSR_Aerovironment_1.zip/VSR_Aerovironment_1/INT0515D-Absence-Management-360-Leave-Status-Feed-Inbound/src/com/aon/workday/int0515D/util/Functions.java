package com.aon.workday.int0515D.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

public class Functions {
	public static String formatDateTimeString(String currentTimeString, int timeZoneOffset, int offset) {
		int rawOffset = timeZoneOffset * 60 * 60 * 1000;
		String[] ids = TimeZone.getAvailableIDs(rawOffset);
		TimeZone zone = new SimpleTimeZone(rawOffset,ids[0],Calendar.MARCH,8,-Calendar.SUNDAY,SimpleTimeZone.WALL_TIME,Calendar.NOVEMBER,1,-Calendar.SUNDAY,SimpleTimeZone.WALL_TIME,3600000);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
		sdf.setTimeZone(zone);
		Calendar cal = new GregorianCalendar(zone);
		cal.set(Calendar.YEAR, Integer.valueOf(currentTimeString.substring(0, 4)));
		cal.set(Calendar.MONTH, Integer.valueOf(currentTimeString.substring(5, 7))-1);
		cal.set(Calendar.DAY_OF_MONTH, Integer.valueOf(currentTimeString.substring(8, 10)));
		cal.set(Calendar.HOUR_OF_DAY, Integer.valueOf(currentTimeString.substring(11, 13)));
		cal.set(Calendar.MINUTE, Integer.valueOf(currentTimeString.substring(14, 16)));
		cal.set(Calendar.SECOND, Integer.valueOf(currentTimeString.substring(17, 19)));
		cal.add(Calendar.MINUTE, offset);
		return sdf.format(cal.getTime());
	}
}
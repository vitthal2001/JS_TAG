package com.workday.ait.java;

import java.util.HashMap;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import com.capeclear.assembly.annotation.Property.Edit;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
//import com.capeclear.assembly.annotation.Property;
import com.capeclear.xml.utils.XmlUtils;

import static com.capeclear.assembly.annotation.Component.Type.*;


/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "HashMapPopulation",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/HashMapPopulation_16.png",
        largeIconPath = "icons/HashMapPopulation_24.png"
        )
public class HashMapPopulation {
	public String itemPath = "";
	public String employeeIDColumnHeadingOverride = "";
	public String customIDColumnHeadingOverride = "";
    /**
     * This method is called by the Assembly framework.
     *
     * Use the <code>MediationContext</code> to access objects in the context,
     * such as the message, properties and variables e.g.
     * <ul>
     * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
     * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
     * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
     * </ul>    
     */
    @ComponentMethod
    // Note that we have added the InputStream as a parameter to the process method.
    //  The input stream will pull from the input in the bean view.
    public void process(java.io.InputStream input) {
       // Get the mediation context
    	MediationContext ctx = MediationTube.getCurrentMediationContext();
    	
    	// Use attributes to find the "split" node
    	String lastElement = itemPath;
		int lastNodeLength = 0;
		if (lastElement.contains("/")) {
			lastNodeLength = lastElement.split("/").length;
			lastElement = lastElement.split("/")[lastNodeLength - 1];
		}
		if (lastElement.contains("\\")) {
			lastNodeLength = lastElement.split("\\\\").length;
			lastElement = lastElement.split("\\\\")[lastNodeLength - 1];
		}
		System.out.println("******SPLIT ELEMENT:" + lastElement);
		
		HashMap<String, String> ids = new HashMap<String, String>();
    	
    	// Create the XMLInputFactory.   The factory is a class that is used to create the XMLReader
    	XMLInputFactory inputFactory = XmlUtils.getXMLInputFactory();
    	//Create the XMLReader
		XMLEventReader xmlReader;
		// Try to create the reader from the factory
		try {
			//input is from the parameters to the process method
			xmlReader = inputFactory.createXMLEventReader(input);
		} catch (XMLStreamException e) {
			// not XML, then the error below is likely
			throw new RuntimeException(
					"XML reader was unable to be created based on your input.  Please confrim that the message is XML",
					e);
		}
		
		//Start the loop
		try {
		//XML event that we are on now	
		XMLEvent curr = null;
		String xmlText = "";
		String lastChars = "";
		String lastStartTag = "";
		String lastPath = "";
		String key = "";
		String customId = "";
		String tagName = "";
		boolean process = false;
		//Loop through all nodes
		do {
			// if the current element is null, get the next one (first record only)
			if (curr == null) {
				//gets next event from the stream (whitespace included)
				curr = xmlReader.nextEvent();
			}
			// Check Start element
						if (curr.isStartElement()) {
							// Get the tag name
							tagName = getTagNameFromStart(curr.asStartElement());
							//if the tag name matches the split node
							if (tagName.equals(lastElement)) {
								// Set our flag that we are looking between these nodes
								process = true;
							// if we are processing									
							} else if (process) {
								if (lastStartTag.equals("")) {
									lastStartTag = tagName;
								}
								//store the last start node
								lastPath = concatIfNotBlank(lastPath, tagName);
							}
							
						}
						// Check End element
						else if (curr.isEndElement()) {
							// Only look at end element when we are processing the
							// record
							// If we are processing the record
							if (process) {
								// get the tag name
								tagName = getTagNameFromEnd(curr.asEndElement());
								// if the tag name equals the split node
								if (tagName.equals(lastElement)) {
									// if key is not null
									if (key != null) {
										// and if key is not blank
										if (!key.equals("")) {
											// add it to the hashMap
											ids.put(key, customId);
										} 
									}
									//Resets values for next loop
									key = "";
									process = false;
									// If we are in the element that we are looking for
								} else if (tagName.equals(lastStartTag)) {
									
									// if the last start tag was for employee ID
									if (lastStartTag.equals(employeeIDColumnHeadingOverride)) {
										// Set the variable to the lastChars
										key = lastChars;
										
									}
									// if the last start tag was for custom ID
									if (lastStartTag.equals(customIDColumnHeadingOverride)) {
										// Set the variable to the lastChars
										customId = lastChars;
										
									}
									//reset values
									lastStartTag = "";
									lastPath = "";
									lastChars = "";
								} 
							}
						
						}
						// Check if the node is characters
						else if (curr.isCharacters()) {
							// If whitespace skip
							if (curr.asCharacters().isWhiteSpace()) {
								// do nothing
							}
							// If CDATA or ignorable whitespace, skip
							else if (curr.asCharacters().isIgnorableWhiteSpace()
									|| curr.asCharacters().isCData()) {
								// Do Nothing - will be skipped
							}
							// Otherwise store the last data value Process Chars
							else {

								if (process) {
									xmlText = curr.asCharacters().getData();
									//System.out.println("Data:" + xmlText);
									lastChars = xmlText;
									// get data;
								}

							}
							
						}
			//gets next event from the stream (whitespace included)
			curr = xmlReader.nextEvent();
		// end of loop - keeps going until curr is the end document	
		} while (!curr.isEndDocument());
		ctx.setProperty("sample.hash.map", ids);
		//end try
		} catch (XMLStreamException e) {
			//throw this error if a problem happens while looping through the records
			throw new RuntimeException(
					"XML reader had a problem reading the nextEvent",
					e);
		}
		
    }
    // Helper method for tag names
    private String concatIfNotBlank(String current, String in) {
    	if (in == null || current == null) {
    		return "";
    	}
    	if (current.equals("")) {
    		return in;
    	} else if (current.endsWith(in)) {
    		return current;
    	} else {
    		return current + "/" + in;
    	}

    }    //Helper method to get the tag name from an end element
	private String getTagNameFromEnd(EndElement end) {
		if (end.getName().getPrefix() != "") {
			return end.getName().getPrefix() + ":"
					+ end.getName().getLocalPart();
		}

		return end.getName().getLocalPart();
	}
	//Helper method to get the tag name from an start element
	private String getTagNameFromStart(StartElement start) {
		if (start.getName().getPrefix() != "") {
			return start.getName().getPrefix() + ":"
					+ start.getName().getLocalPart();
		}

		return start.getName().getLocalPart();
	}
	 @Property(name = "Item Path", order = 1, edit = Edit.DEFAULT, toolTip = "The XPATH to the primary record,  normally wd:Report Data/wd:Report_Entry")
	public String getItemPath() {
		return itemPath;
	}
	public void setItemPath(String itemPath) {
		this.itemPath = itemPath;
	}
	 @Property(name = "Employee ID XML Tag Name", order = 2, edit = Edit.DEFAULT, toolTip = "The XML Tag Name of the Employee ID")
	public String getEmployeeIDColumnHeadingOverride() {
		return employeeIDColumnHeadingOverride;
	}
	public void setEmployeeIDColumnHeadingOverride(
			String employeeIDColumnHeadingOverride) {
		this.employeeIDColumnHeadingOverride = employeeIDColumnHeadingOverride;
	}
	@Property(name = "Custom ID XML Tag Name", order = 3, edit = Edit.DEFAULT, toolTip = "The XML Tag Name of the Custom ID")
	public String getCustomIDColumnHeadingOverride() {
		return customIDColumnHeadingOverride;
	}
	public void setCustomIDColumnHeadingOverride(
			String customIDColumnHeadingOverride) {
		this.customIDColumnHeadingOverride = customIDColumnHeadingOverride;
	}
}

package com.workday.custom.step;

import static com.capeclear.assembly.annotation.Component.Type.mediation;

import java.io.IOException;

import javax.xml.transform.stream.StreamSource;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;


/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "PdfMerge",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/PdfMerge_16.png",
        largeIconPath = "icons/PdfMerge_24.png"
        )
public class PdfMerge {

    /**
     * This method is called by the Assembly framework.    
     */
    @ComponentMethod
    public void process(java.io.InputStream in, java.io.OutputStream out) {

    		MediationContext ctx = MediationTube.getCurrentMediationContext();
    		
    		/*
    		 * Get the document count
    		 */
    		
    		Object o_docCount = ctx.getProperty( "docCount" );
    		if ( o_docCount == null ) {
    			throw new RuntimeException("Unable to find property docCount");
    		}
    		
    		
    		
    		int doc_count = (o_docCount instanceof Integer) ? ((Integer)o_docCount) : Integer.parseInt( o_docCount.toString());
    		
    		if ( doc_count == 0 ) {
    			throw new RuntimeException("There are no PDFs to merge");
    		}
    		
    		PDFMergerUtility merge = new PDFMergerUtility();
    		for(int i=1; i<=doc_count; i++ ) {
    			String var_name = "pdfDoc-" + i;
    			//
    			// Get an InputStream for merging
    			//
    			try {
    				merge.addSource(  ((StreamSource)ctx.getVariables().getVariable(var_name )).getInputStream() );
    			}
    			catch (IOException io_e) {
    				throw new RuntimeException("Unable to obtain InputStream to variable \"" + var_name + '"');
    			}
    		}
    		
    		//
    		// Generate the merge document
    		//
    		merge.setDestinationStream(out);
    		try {
			merge.mergeDocuments( MemoryUsageSetting.setupMixed( 1024*1024*1024 ) );
		} catch (Exception e) {
			throw new RuntimeException("An error occurred merging the PDF documents: " + e.getMessage(), e);
		}
	
    }
}

package com.workday.saml;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;

import com.capeclear.mediation.MediationException;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;

import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Iterator;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.XMLUtils;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "BuildSAML",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/BuildSAML_16.png",
        largeIconPath = "icons/BuildSAML_24.png"
        )
public class BuildSAML {

    /**
     * This method is called by the Assembly framework.
     *
     * Use the <code>MediationContext</code> to access objects in the context,
     * such as the message, properties and variables e.g.
     * <ul>
     * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
     * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
     * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
     * </ul>    
     * @throws IOException 
     * @throws FileNotFoundException 
     * @throws CertificateException 
     * @throws NoSuchAlgorithmException 
     * @throws KeyStoreException 
     * @throws UnrecoverableKeyException 
     * @throws SAXException 
     * @throws ParserConfigurationException 
     */
	

	
    @ComponentMethod
    public void process(com.capeclear.mediation.MediationContext ctx) throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, UnrecoverableKeyException, ParserConfigurationException, SAXException {
  
  try {
    	
 
    	String samlSignedResponseStr = ctx.getVariables().get("inbound.xml").getText();
    	
    	Document samlSignedResponseDocument =  parseXML(new InputSource(new StringReader(samlSignedResponseStr)));
    	
    	  //Load the private key from a keystore
        
        String baseURL = ctx.getBaseURL().getPath() + "/keystore";
        String pKeyFile = (String) ctx.getProperty("key.store.file.name");
        String dirURL = baseURL + "/" + pKeyFile;
		
        String keystorePwd = (String) ctx.getProperty("key.store.pwd");
        String keyAlias = (String) ctx.getProperty("key.alias");
        
        KeyStore keystore = KeyStore.getInstance("JKS");
	
        
        keystore.load(new FileInputStream(dirURL), keystorePwd.toCharArray());
        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, keystorePwd.toCharArray());
        
   
        
        X509Certificate certificate = (X509Certificate) keystore.getCertificate(keyAlias);
        
      String oAuthType = ctx.getProperty("auth.type").toString();
    	
    	try {
			String returnedXML = addSign(samlSignedResponseDocument,privateKey,certificate,null,null,oAuthType);
			ctx.getMessage().getVariables().setVariable("assertion", returnedXML, "text/xml");
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			throw new MediationException("KeyStore load error", e);
		} catch (XMLSecurityException e) {
			// TODO Auto-generated catch block
			throw new MediationException("KeyStore load error", e);
		} catch (IllegalArgumentException e) {
			throw new MediationException("KeyStore load error", e);
		}
    
    	
  }
  catch (KeyStoreException | IOException | NoSuchAlgorithmException | CertificateException
			| UnrecoverableKeyException e) {
		throw new MediationException("KeyStore load error", e);
	}
    	
    	}
    	
  
    	
    
    
    
    
    public String addSign(Document document, PrivateKey key, X509Certificate certificate,  String signAlgorithm, String digestAlgorithm, String oAuthType) throws XMLSecurityException, XPathExpressionException  {
		
    	String SHA1 = "http://www.w3.org/2000/09/xmldsig#sha1";
    	String RSA_SHA1 = "http://www.w3.org/2000/09/xmldsig#rsa-sha1";
    	String RSA_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
    	String SHA256 = "http://www.w3.org/2001/04/xmlenc#sha256";
    	String C14NEXC = "http://www.w3.org/2001/10/xml-exc-c14n#";
    	String ENVSIG = "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
    	
    	// Check arguments.
		if (document == null) {
			throw new IllegalArgumentException("Provided document was null");
		}

		if (document.getDocumentElement() == null) {
			throw new IllegalArgumentException("The Xml Document has no root element.");
		}

		if (key == null) {
			throw new IllegalArgumentException("Provided key was null");
		}

		if (certificate == null) {
			throw new IllegalArgumentException("Provided certificate was null");
		}

		if (signAlgorithm == null || signAlgorithm.isEmpty()) {
			signAlgorithm = RSA_SHA256;
			//signAlgorithm = RSA_SHA1;
		}
		if (digestAlgorithm == null || digestAlgorithm.isEmpty()) {
			digestAlgorithm = SHA256;
		}

		org.apache.xml.security.Init.init();
		
		document.normalizeDocument();

		String c14nMethod = C14NEXC;

		// Signature object
		XMLSignature sig = new XMLSignature(document, null, signAlgorithm, c14nMethod);

	
		
		// Including the signature into the document before sign, because
		// this is an envelope signature
		Element root = document.getDocumentElement();
		document.setXmlStandalone(false);
			
		
		Element elemToSign = null;
		
		if (oAuthType.endsWith("X509")) 
		{
			NodeList securityNodes = root.getElementsByTagName("wsse:Security");
			if (securityNodes.getLength() > 0) 
			{
				Node securityNode =  securityNodes.item(0);
				securityNode.appendChild(sig.getElement());
				elemToSign = (Element) securityNode.getParentNode();
			} 
		}
		 else
		 {
				
				NodeList issuerNodes = root.getElementsByTagName("saml:Issuer");
				if (issuerNodes.getLength() > 0) 
				{
					Node issuer =  issuerNodes.item(0);
					Node subjectNode = root.getElementsByTagName("saml:Subject").item(0);
					
					root.insertBefore(sig.getElement(), subjectNode);
					elemToSign = (Element) issuer.getParentNode();
					
				} 
			}
		
		
		
		String id = elemToSign.getAttribute("ID");

		String reference = id;
		if (!id.isEmpty()) {
			elemToSign.setIdAttributeNS(null, "ID", true);
			reference = "#" + id;
		}

		
		
		// Create the transform for the document
		Transforms transforms = new Transforms(document);
		transforms.addTransform(ENVSIG);
		transforms.addTransform(c14nMethod);
		sig.addDocument(reference, transforms, digestAlgorithm);

		// Add the certification info
		sig.addKeyInfo(certificate);

		// Sign the document
		sig.sign(key);

		return convertDocumentToString(document, true);
	}
    
	 
	  public  NodeList query(Document dom, String query) throws XPathExpressionException {
		  
		  String NS_SAML = "urn:oasis:names:tc:SAML:2.0:assertion";
		  String NS_SAMLP = "urn:oasis:names:tc:SAML:2.0:protocol";
		  String NS_SOAP = "http://schemas.xmlsoap.org/soap/envelope/";
		  String NS_MD = "urn:oasis:names:tc:SAML:2.0:metadata";
		  String NS_XS = "http://www.w3.org/2001/XMLSchema";
		  String NS_XSI = "http://www.w3.org/2001/XMLSchema-instance";
		  String NS_XENC = "http://www.w3.org/2001/04/xmlenc#";
		  String NS_DS = "http://www.w3.org/2000/09/xmldsig#";
		  String NS_WSSE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
		  
			NodeList nodeList;
			XPath xpath = getXPathFactory().newXPath();
				
			xpath.setNamespaceContext(new NamespaceContext() {

				@Override
				public String getNamespaceURI(String prefix) {
					String result = null;
					if (prefix.equals("samlp") || prefix.equals("samlp2") || prefix.equals("saml2p")) {
						result = NS_SAMLP;
					} else if (prefix.equals("saml") || prefix.equals("saml2")) {
						result = NS_SAML;
					} else if (prefix.equals("ds")) {
						result = NS_DS;
					} else if (prefix.equals("xenc")) {
						result = NS_XENC;
					} else if (prefix.equals("md")) {
						result = NS_MD;
					} else if (prefix.equals("wsse")) {
						result = NS_WSSE;
					}
					return result;
				}

				@Override
				public String getPrefix(String namespaceURI) {
					return null;
				}

				@SuppressWarnings("rawtypes")
				@Override
				public Iterator getPrefixes(String namespaceURI) {
					return null;
				}
			});

			
				nodeList = (NodeList) xpath.evaluate(query, dom, XPathConstants.NODESET);
			
			return nodeList;
		}

	  private XPathFactory getXPathFactory() {
			try {
				/*
				 * Since different environments may return a different XPathFactoryImpl, we should try to initialize the factory
				 * using specific implementation that way the XML is parsed in an expected way.
				 *
				 * We should use the standard XPathFactoryImpl that comes standard with Java.
				 *
				 * NOTE: We could implement a check to see if the "javax.xml.xpath.XPathFactory" System property exists and is set
				 *       to a value, if people have issues with using the specified implementor. This would allow users to always
				 *       override the implementation if they so need to.
				 */
				return XPathFactory.newInstance(XPathFactory.DEFAULT_OBJECT_MODEL_URI, "com.sun.org.apache.xpath.internal.jaxp.XPathFactoryImpl", java.lang.ClassLoader.getSystemClassLoader());
			} catch (XPathFactoryConfigurationException e) {
				//LOGGER.debug("Error generating XPathFactory instance: " + e.getMessage(), e);
			}

			/*
			 * If the expected XPathFactory did not exist, we fallback to loading the one defined as the default.
			 *
			 * If this is still throwing an error, the developer can set the "javax.xml.xpath.XPathFactory" system property
			 * to specify the default XPathFactoryImpl implementation to use. For example:
			 *
			 * -Djavax.xml.xpath.XPathFactory:http://java.sun.com/jaxp/xpath/dom=net.sf.saxon.xpath.XPathFactoryImpl
			 * -Djavax.xml.xpath.XPathFactory:http://java.sun.com/jaxp/xpath/dom=com.sun.org.apache.xpath.internal.jaxp.XPathFactoryImpl
			 *
			 */
			return XPathFactory.newInstance();
		}
    
	  public Document convertStringToDocument(String xmlStr) throws ParserConfigurationException, SAXException, IOException {
			return parseXML(new InputSource(new StringReader(xmlStr)));
		}
	  
    public String convertDocumentToString(Document doc, Boolean c14n) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		if (c14n) {
			XMLUtils.outputDOMc14nWithComments(doc, baos);
		} else {
			XMLUtils.outputDOM(doc, baos);
		}

		return toStringUtf8(baos.toByteArray());
		
	}



    private String toStringUtf8(byte[] bytes) {
		try {
			return new String(bytes, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new IllegalStateException(e);
		}
	}
    
    public Document parseXML(InputSource inputSource) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory docfactory = DocumentBuilderFactory.newInstance();
		docfactory.setNamespaceAware(true);

		// do not expand entity reference nodes
		docfactory.setExpandEntityReferences(false);

		docfactory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", XMLConstants.W3C_XML_SCHEMA_NS_URI);

		// Add various options explicitly to prevent XXE attacks.
		// (adding try/catch around every setAttribute just in case a specific parser does not support it.
		try {
			// do not include external general entities
			docfactory.setAttribute("http://xml.org/sax/features/external-general-entities", Boolean.FALSE);
		} catch (Throwable e) {}
		try {
			// do not include external parameter entities or the external DTD subset
			docfactory.setAttribute("http://xml.org/sax/features/external-parameter-entities", Boolean.FALSE);
		} catch (Throwable e) {}
		try {
			docfactory.setAttribute("http://apache.org/xml/features/disallow-doctype-decl", Boolean.TRUE);
		} catch (Throwable e) {}
		try {
			docfactory.setAttribute("http://javax.xml.XMLConstants/feature/secure-processing", Boolean.TRUE);
		} catch (Throwable e) {}
		try {
			// ignore the external DTD completely
			docfactory.setAttribute("http://apache.org/xml/features/nonvalidating/load-external-dtd", Boolean.FALSE);
		} catch (Throwable e) {}
		try {
			// build the grammar but do not use the default attributes and attribute types information it contains
			docfactory.setAttribute("http://apache.org/xml/features/nonvalidating/load-dtd-grammar", Boolean.FALSE);
		} catch (Throwable e) {}
		try {
			docfactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
		} catch (Throwable e) {}

		DocumentBuilder builder = docfactory.newDocumentBuilder();
		Document doc = builder.parse(inputSource);

		// Loop through the doc and tag every element with an ID attribute
		// as an XML ID node.
		XPath xpath = getXPathFactory().newXPath();
		XPathExpression expr;
		try {
			expr = xpath.compile("//*[@ID]");

			NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
			for (int i = 0; i < nodeList.getLength(); i++) {
				Element elem = (Element) nodeList.item(i);
				Attr attr = (Attr) elem.getAttributes().getNamedItem("ID");
				elem.setIdAttributeNode(attr, true);
			}
		} catch (XPathExpressionException e) {
			return null;
		}

		return doc;
	}
}

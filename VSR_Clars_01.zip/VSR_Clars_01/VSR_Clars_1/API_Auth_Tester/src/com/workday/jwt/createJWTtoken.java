package com.workday.jwt;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.text.MessageFormat;

import org.apache.commons.codec.binary.Base64;


/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "createJWTtoken",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/createJWTtoken_16.png",
        largeIconPath = "icons/createJWTtoken_24.png"
        )
public class createJWTtoken {

    /**
     * This method is called by the Assembly framework.
     *
     * Use the <code>MediationContext</code> to access objects in the context,
     * such as the message, properties and variables e.g.
     * <ul>
     * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
     * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
     * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
     * </ul>    
     */
    @ComponentMethod
    public void process(com.capeclear.mediation.MediationContext arg0) {
    	MediationContext ctx = MediationTube.getCurrentMediationContext();
    	
   	 String header = "{\"alg\":\"RS256\",\"typ\":\"JWT\"}";
        String claimTemplate = "'{'\"iss\": \"{0}\", \"sub\": \"{1}\", \"aud\": \"{2}\", \"exp\": \"{3}\"'}'";
     

/*        // To generate key
        keytool -genkey -keyalg RSA -alias Workday -keystore JWTkeystore.jks -storepass Workday123! -validity 360 -keysize 2048

        b-	User this command to extract the public key from the newly created keystore:

        keytool -export -alias Workday -keystore JWTkeystore.jks -rfc -file publickey.cert
*/


        try {
            StringBuffer token = new StringBuffer();

            //Encode the JWT Header and add it to our string to sign
            token.append(Base64.encodeBase64URLSafeString(header.getBytes("UTF-8")));

            //Separate with a period
            token.append(".");


            //Create the JWT Claims Object
            String[] claimArray = new String[4];
            //Client ID
            claimArray[0] = (String) ctx.getProperty("client.id");
            //User
            claimArray[1] = (String) ctx.getProperty("workday.account");
            //audience - always set to "wd"
            claimArray[2] = "wd";
            //expires
            claimArray[3] = Long.toString( ( System.currentTimeMillis()/1000 ) + 300);
            MessageFormat claims;
            claims = new MessageFormat(claimTemplate);
            String payload = claims.format(claimArray);

            //Add the encoded claims object
            token.append(Base64.encodeBase64URLSafeString(payload.getBytes("UTF-8")));

            //Load the private key from a keystore
           
            String baseURL = ctx.getBaseURL().getPath() + "/keystore";
            String pKeyFile = (String) ctx.getProperty("key.store.file.name");
            String dirURL = baseURL + "/" + pKeyFile;
			
            String keystorePwd = (String) ctx.getProperty("key.store.pwd");
            String keyAlias = (String) ctx.getProperty("key.alias");
            
            KeyStore keystore = KeyStore.getInstance("JKS");
            
            keystore.load(new FileInputStream(dirURL), keystorePwd.toCharArray());
            PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, keystorePwd.toCharArray());

            //Sign the JWT Header + "." + JWT Claims Object
            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initSign(privateKey);
            signature.update(token.toString().getBytes("UTF-8"));
            String signedPayload = Base64.encodeBase64URLSafeString(signature.sign());

            //Separate with a period
            token.append(".");

            //Add the encoded signature
            token.append(signedPayload);

            //System.out.println(token.toString());
            ctx.setProperty("jwt.assertion", token.toString());

        } catch (Exception e) {
            e.printStackTrace();
            ctx.setException(e);
        }
    }
}


package workday.com.logmessages;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Log_MessageType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Log_MessageType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Timestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Log_Level" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Message" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Message_Detail" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Reference_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Local_In" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Record_Number" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Worker_Type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Worker_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Pay_Component_Type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Pay_Component_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Support_Data" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Log_MessageType", propOrder = {
    "timestamp",
    "logLevel",
    "message",
    "messageDetail",
    "referenceID",
    "localIn",
    "recordNumber",
    "workerType",
    "workerID",
    "payComponentType",
    "payComponentID",
    "supportData"
})
public class LogMessageType {

    @XmlElement(name = "Timestamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar timestamp;
    @XmlElement(name = "Log_Level", required = true)
    protected String logLevel;
    @XmlElement(name = "Message", required = true)
    protected String message;
    @XmlElement(name = "Message_Detail", required = true)
    protected String messageDetail;
    @XmlElement(name = "Reference_ID", required = true)
    protected String referenceID;
    @XmlElement(name = "Local_In", required = true)
    protected String localIn;
    @XmlElement(name = "Record_Number", required = true)
    protected String recordNumber;
    @XmlElement(name = "Worker_Type", required = true)
    protected String workerType;
    @XmlElement(name = "Worker_ID", required = true)
    protected String workerID;
    @XmlElement(name = "Pay_Component_Type", required = true)
    protected String payComponentType;
    @XmlElement(name = "Pay_Component_ID", required = true)
    protected String payComponentID;
    @XmlElement(name = "Support_Data", required = true)
    protected String supportData;

    /**
     * Gets the value of the timestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the value of the timestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTimestamp(XMLGregorianCalendar value) {
        this.timestamp = value;
    }

    /**
     * Gets the value of the logLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogLevel() {
        return logLevel;
    }

    /**
     * Sets the value of the logLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogLevel(String value) {
        this.logLevel = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the messageDetail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageDetail() {
        return messageDetail;
    }

    /**
     * Sets the value of the messageDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageDetail(String value) {
        this.messageDetail = value;
    }

    /**
     * Gets the value of the referenceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceID() {
        return referenceID;
    }

    /**
     * Sets the value of the referenceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceID(String value) {
        this.referenceID = value;
    }

    /**
     * Gets the value of the localIn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalIn() {
        return localIn;
    }

    /**
     * Sets the value of the localIn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalIn(String value) {
        this.localIn = value;
    }

    /**
     * Gets the value of the recordNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordNumber() {
        return recordNumber;
    }

    /**
     * Sets the value of the recordNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordNumber(String value) {
        this.recordNumber = value;
    }

    /**
     * Gets the value of the workerType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkerType() {
        return workerType;
    }

    /**
     * Sets the value of the workerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkerType(String value) {
        this.workerType = value;
    }

    /**
     * Gets the value of the workerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkerID() {
        return workerID;
    }

    /**
     * Sets the value of the workerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkerID(String value) {
        this.workerID = value;
    }

    /**
     * Gets the value of the payComponentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayComponentType() {
        return payComponentType;
    }

    /**
     * Sets the value of the payComponentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayComponentType(String value) {
        this.payComponentType = value;
    }

    /**
     * Gets the value of the payComponentID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayComponentID() {
        return payComponentID;
    }

    /**
     * Sets the value of the payComponentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayComponentID(String value) {
        this.payComponentID = value;
    }

    /**
     * Gets the value of the supportData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSupportData() {
        return supportData;
    }

    /**
     * Sets the value of the supportData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSupportData(String value) {
        this.supportData = value;
    }

}

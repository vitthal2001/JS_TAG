@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com.workday/LogMessages", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package workday.com.logmessages;


package workday.com.bsvc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Integration_System__Audited_ObjectType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Integration_System__Audited_ObjectType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ID" type="{urn:com.workday/bsvc}Integration_System__Audited_ObjectIDType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Descriptor" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Integration_System__Audited_ObjectType", propOrder = {
    "id"
})
public class IntegrationSystemAuditedObjectType {

    @XmlElement(name = "ID")
    protected IntegrationSystemAuditedObjectIDType id;
    @XmlAttribute(name = "Descriptor", namespace = "urn:com.workday/bsvc")
    protected String descriptor;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link IntegrationSystemAuditedObjectIDType }
     *     
     */
    public IntegrationSystemAuditedObjectIDType getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link IntegrationSystemAuditedObjectIDType }
     *     
     */
    public void setID(IntegrationSystemAuditedObjectIDType value) {
        this.id = value;
    }

    /**
     * Gets the value of the descriptor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescriptor() {
        return descriptor;
    }

    /**
     * Sets the value of the descriptor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescriptor(String value) {
        this.descriptor = value;
    }

}


package workday.com.bsvc;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Additional Input Details
 * 
 * <p>Java class for Additional_Input_DetailsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Additional_Input_DetailsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Related_Calculation_Reference" type="{urn:com.workday/bsvc}Related_Calculation__All_ObjectType" minOccurs="0"/>
 *         &lt;element name="Input_Value" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;totalDigits value="26"/>
 *               &lt;fractionDigits value="6"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Additional_Input_DetailsType", propOrder = {
    "relatedCalculationReference",
    "inputValue"
})
public class AdditionalInputDetailsType {

    @XmlElement(name = "Related_Calculation_Reference")
    protected RelatedCalculationAllObjectType relatedCalculationReference;
    @XmlElement(name = "Input_Value")
    protected BigDecimal inputValue;

    /**
     * Gets the value of the relatedCalculationReference property.
     * 
     * @return
     *     possible object is
     *     {@link RelatedCalculationAllObjectType }
     *     
     */
    public RelatedCalculationAllObjectType getRelatedCalculationReference() {
        return relatedCalculationReference;
    }

    /**
     * Sets the value of the relatedCalculationReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link RelatedCalculationAllObjectType }
     *     
     */
    public void setRelatedCalculationReference(RelatedCalculationAllObjectType value) {
        this.relatedCalculationReference = value;
    }

    /**
     * Gets the value of the inputValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInputValue() {
        return inputValue;
    }

    /**
     * Sets the value of the inputValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInputValue(BigDecimal value) {
        this.inputValue = value;
    }

}

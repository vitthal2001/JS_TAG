
package workday.com.bsvc;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the workday.com.bsvc package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PayrollInputProcessorRequest_QNAME = new QName("urn:com.workday/bsvc", "Payroll_Input_Processor_Request");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: workday.com.bsvc
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CustomWorktag06ObjectType }
     * 
     */
    public CustomWorktag06ObjectType createCustomWorktag06ObjectType() {
        return new CustomWorktag06ObjectType();
    }

    /**
     * Create an instance of {@link ProjectPlanPhaseObjectIDType }
     * 
     */
    public ProjectPlanPhaseObjectIDType createProjectPlanPhaseObjectIDType() {
        return new ProjectPlanPhaseObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag14ObjectIDType }
     * 
     */
    public CustomWorktag14ObjectIDType createCustomWorktag14ObjectIDType() {
        return new CustomWorktag14ObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag14ObjectType }
     * 
     */
    public CustomWorktag14ObjectType createCustomWorktag14ObjectType() {
        return new CustomWorktag14ObjectType();
    }

    /**
     * Create an instance of {@link IntegrationSystemAuditedObjectIDType }
     * 
     */
    public IntegrationSystemAuditedObjectIDType createIntegrationSystemAuditedObjectIDType() {
        return new IntegrationSystemAuditedObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollInputWorktagsDataType }
     * 
     */
    public PayrollInputWorktagsDataType createPayrollInputWorktagsDataType() {
        return new PayrollInputWorktagsDataType();
    }

    /**
     * Create an instance of {@link CompanyObjectType }
     * 
     */
    public CompanyObjectType createCompanyObjectType() {
        return new CompanyObjectType();
    }

    /**
     * Create an instance of {@link PayrollLocalSchoolDistrictAuthorityObjectIDType }
     * 
     */
    public PayrollLocalSchoolDistrictAuthorityObjectIDType createPayrollLocalSchoolDistrictAuthorityObjectIDType() {
        return new PayrollLocalSchoolDistrictAuthorityObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag04ObjectType }
     * 
     */
    public CustomWorktag04ObjectType createCustomWorktag04ObjectType() {
        return new CustomWorktag04ObjectType();
    }

    /**
     * Create an instance of {@link RegionObjectType }
     * 
     */
    public RegionObjectType createRegionObjectType() {
        return new RegionObjectType();
    }

    /**
     * Create an instance of {@link ObjectClassObjectIDType }
     * 
     */
    public ObjectClassObjectIDType createObjectClassObjectIDType() {
        return new ObjectClassObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollIncomeCodeObjectType }
     * 
     */
    public PayrollIncomeCodeObjectType createPayrollIncomeCodeObjectType() {
        return new PayrollIncomeCodeObjectType();
    }

    /**
     * Create an instance of {@link NICategoryObjectType }
     * 
     */
    public NICategoryObjectType createNICategoryObjectType() {
        return new NICategoryObjectType();
    }

    /**
     * Create an instance of {@link WithholdingOrderCaseObjectType }
     * 
     */
    public WithholdingOrderCaseObjectType createWithholdingOrderCaseObjectType() {
        return new WithholdingOrderCaseObjectType();
    }

    /**
     * Create an instance of {@link PayrollLocalCityAuthorityObjectIDType }
     * 
     */
    public PayrollLocalCityAuthorityObjectIDType createPayrollLocalCityAuthorityObjectIDType() {
        return new PayrollLocalCityAuthorityObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag05ObjectType }
     * 
     */
    public CustomWorktag05ObjectType createCustomWorktag05ObjectType() {
        return new CustomWorktag05ObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag04ObjectIDType }
     * 
     */
    public CustomWorktag04ObjectIDType createCustomWorktag04ObjectIDType() {
        return new CustomWorktag04ObjectIDType();
    }

    /**
     * Create an instance of {@link ARRCOAGIRCRubricValueObjectIDType }
     * 
     */
    public ARRCOAGIRCRubricValueObjectIDType createARRCOAGIRCRubricValueObjectIDType() {
        return new ARRCOAGIRCRubricValueObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag11ObjectIDType }
     * 
     */
    public CustomWorktag11ObjectIDType createCustomWorktag11ObjectIDType() {
        return new CustomWorktag11ObjectIDType();
    }

    /**
     * Create an instance of {@link RelatedCalculationAllObjectType }
     * 
     */
    public RelatedCalculationAllObjectType createRelatedCalculationAllObjectType() {
        return new RelatedCalculationAllObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag10ObjectType }
     * 
     */
    public CustomWorktag10ObjectType createCustomWorktag10ObjectType() {
        return new CustomWorktag10ObjectType();
    }

    /**
     * Create an instance of {@link ObjectClassObjectType }
     * 
     */
    public ObjectClassObjectType createObjectClassObjectType() {
        return new ObjectClassObjectType();
    }

    /**
     * Create an instance of {@link GiftObjectIDType }
     * 
     */
    public GiftObjectIDType createGiftObjectIDType() {
        return new GiftObjectIDType();
    }

    /**
     * Create an instance of {@link ProjectPlanTaskObjectIDType }
     * 
     */
    public ProjectPlanTaskObjectIDType createProjectPlanTaskObjectIDType() {
        return new ProjectPlanTaskObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag13ObjectIDType }
     * 
     */
    public CustomWorktag13ObjectIDType createCustomWorktag13ObjectIDType() {
        return new CustomWorktag13ObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag08ObjectIDType }
     * 
     */
    public CustomWorktag08ObjectIDType createCustomWorktag08ObjectIDType() {
        return new CustomWorktag08ObjectIDType();
    }

    /**
     * Create an instance of {@link ProjectObjectType }
     * 
     */
    public ProjectObjectType createProjectObjectType() {
        return new ProjectObjectType();
    }

    /**
     * Create an instance of {@link GrantObjectType }
     * 
     */
    public GrantObjectType createGrantObjectType() {
        return new GrantObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag09ObjectType }
     * 
     */
    public CustomWorktag09ObjectType createCustomWorktag09ObjectType() {
        return new CustomWorktag09ObjectType();
    }

    /**
     * Create an instance of {@link DeductionAllObjectType }
     * 
     */
    public DeductionAllObjectType createDeductionAllObjectType() {
        return new DeductionAllObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag12ObjectType }
     * 
     */
    public CustomWorktag12ObjectType createCustomWorktag12ObjectType() {
        return new CustomWorktag12ObjectType();
    }

    /**
     * Create an instance of {@link MatchExistingRecordObjectType }
     * 
     */
    public MatchExistingRecordObjectType createMatchExistingRecordObjectType() {
        return new MatchExistingRecordObjectType();
    }

    /**
     * Create an instance of {@link PayrollInputProcessorRequestType }
     * 
     */
    public PayrollInputProcessorRequestType createPayrollInputProcessorRequestType() {
        return new PayrollInputProcessorRequestType();
    }

    /**
     * Create an instance of {@link NICategoryObjectIDType }
     * 
     */
    public NICategoryObjectIDType createNICategoryObjectIDType() {
        return new NICategoryObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollIncomeCodeObjectIDType }
     * 
     */
    public PayrollIncomeCodeObjectIDType createPayrollIncomeCodeObjectIDType() {
        return new PayrollIncomeCodeObjectIDType();
    }

    /**
     * Create an instance of {@link BusinessUnitObjectIDType }
     * 
     */
    public BusinessUnitObjectIDType createBusinessUnitObjectIDType() {
        return new BusinessUnitObjectIDType();
    }

    /**
     * Create an instance of {@link SubmitPayrollInputDataType }
     * 
     */
    public SubmitPayrollInputDataType createSubmitPayrollInputDataType() {
        return new SubmitPayrollInputDataType();
    }

    /**
     * Create an instance of {@link FundObjectIDType }
     * 
     */
    public FundObjectIDType createFundObjectIDType() {
        return new FundObjectIDType();
    }

    /**
     * Create an instance of {@link CustomOrganizationObjectType }
     * 
     */
    public CustomOrganizationObjectType createCustomOrganizationObjectType() {
        return new CustomOrganizationObjectType();
    }

    /**
     * Create an instance of {@link WorkerObjectType }
     * 
     */
    public WorkerObjectType createWorkerObjectType() {
        return new WorkerObjectType();
    }

    /**
     * Create an instance of {@link ProjectPlanTaskObjectType }
     * 
     */
    public ProjectPlanTaskObjectType createProjectPlanTaskObjectType() {
        return new ProjectPlanTaskObjectType();
    }

    /**
     * Create an instance of {@link PayrollLocalCountyAuthorityObjectType }
     * 
     */
    public PayrollLocalCountyAuthorityObjectType createPayrollLocalCountyAuthorityObjectType() {
        return new PayrollLocalCountyAuthorityObjectType();
    }

    /**
     * Create an instance of {@link ProjectPlanPhaseObjectType }
     * 
     */
    public ProjectPlanPhaseObjectType createProjectPlanPhaseObjectType() {
        return new ProjectPlanPhaseObjectType();
    }

    /**
     * Create an instance of {@link RegionObjectIDType }
     * 
     */
    public RegionObjectIDType createRegionObjectIDType() {
        return new RegionObjectIDType();
    }

    /**
     * Create an instance of {@link DeductionAllObjectIDType }
     * 
     */
    public DeductionAllObjectIDType createDeductionAllObjectIDType() {
        return new DeductionAllObjectIDType();
    }

    /**
     * Create an instance of {@link WithholdingOrderCaseObjectIDType }
     * 
     */
    public WithholdingOrderCaseObjectIDType createWithholdingOrderCaseObjectIDType() {
        return new WithholdingOrderCaseObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag08ObjectType }
     * 
     */
    public CustomWorktag08ObjectType createCustomWorktag08ObjectType() {
        return new CustomWorktag08ObjectType();
    }

    /**
     * Create an instance of {@link BusinessUnitObjectType }
     * 
     */
    public BusinessUnitObjectType createBusinessUnitObjectType() {
        return new BusinessUnitObjectType();
    }

    /**
     * Create an instance of {@link JobProfileObjectType }
     * 
     */
    public JobProfileObjectType createJobProfileObjectType() {
        return new JobProfileObjectType();
    }

    /**
     * Create an instance of {@link JobProfileObjectIDType }
     * 
     */
    public JobProfileObjectIDType createJobProfileObjectIDType() {
        return new JobProfileObjectIDType();
    }

    /**
     * Create an instance of {@link AdditionalInputDetailsType }
     * 
     */
    public AdditionalInputDetailsType createAdditionalInputDetailsType() {
        return new AdditionalInputDetailsType();
    }

    /**
     * Create an instance of {@link WorkersCompensationCodeObjectIDType }
     * 
     */
    public WorkersCompensationCodeObjectIDType createWorkersCompensationCodeObjectIDType() {
        return new WorkersCompensationCodeObjectIDType();
    }

    /**
     * Create an instance of {@link EarningAllObjectIDType }
     * 
     */
    public EarningAllObjectIDType createEarningAllObjectIDType() {
        return new EarningAllObjectIDType();
    }

    /**
     * Create an instance of {@link ProgramObjectType }
     * 
     */
    public ProgramObjectType createProgramObjectType() {
        return new ProgramObjectType();
    }

    /**
     * Create an instance of {@link CurrencyObjectIDType }
     * 
     */
    public CurrencyObjectIDType createCurrencyObjectIDType() {
        return new CurrencyObjectIDType();
    }

    /**
     * Create an instance of {@link GrantObjectIDType }
     * 
     */
    public GrantObjectIDType createGrantObjectIDType() {
        return new GrantObjectIDType();
    }

    /**
     * Create an instance of {@link CountryObjectType }
     * 
     */
    public CountryObjectType createCountryObjectType() {
        return new CountryObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag02ObjectType }
     * 
     */
    public CustomWorktag02ObjectType createCustomWorktag02ObjectType() {
        return new CustomWorktag02ObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag02ObjectIDType }
     * 
     */
    public CustomWorktag02ObjectIDType createCustomWorktag02ObjectIDType() {
        return new CustomWorktag02ObjectIDType();
    }

    /**
     * Create an instance of {@link CostCenterObjectType }
     * 
     */
    public CostCenterObjectType createCostCenterObjectType() {
        return new CostCenterObjectType();
    }

    /**
     * Create an instance of {@link RunCategoryObjectType }
     * 
     */
    public RunCategoryObjectType createRunCategoryObjectType() {
        return new RunCategoryObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag01ObjectIDType }
     * 
     */
    public CustomWorktag01ObjectIDType createCustomWorktag01ObjectIDType() {
        return new CustomWorktag01ObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag15ObjectType }
     * 
     */
    public CustomWorktag15ObjectType createCustomWorktag15ObjectType() {
        return new CustomWorktag15ObjectType();
    }

    /**
     * Create an instance of {@link LocationObjectType }
     * 
     */
    public LocationObjectType createLocationObjectType() {
        return new LocationObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag15ObjectIDType }
     * 
     */
    public CustomWorktag15ObjectIDType createCustomWorktag15ObjectIDType() {
        return new CustomWorktag15ObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollExemptionCodeObjectIDType }
     * 
     */
    public PayrollExemptionCodeObjectIDType createPayrollExemptionCodeObjectIDType() {
        return new PayrollExemptionCodeObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag05ObjectIDType }
     * 
     */
    public CustomWorktag05ObjectIDType createCustomWorktag05ObjectIDType() {
        return new CustomWorktag05ObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag09ObjectIDType }
     * 
     */
    public CustomWorktag09ObjectIDType createCustomWorktag09ObjectIDType() {
        return new CustomWorktag09ObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag01ObjectType }
     * 
     */
    public CustomWorktag01ObjectType createCustomWorktag01ObjectType() {
        return new CustomWorktag01ObjectType();
    }

    /**
     * Create an instance of {@link GiftObjectType }
     * 
     */
    public GiftObjectType createGiftObjectType() {
        return new GiftObjectType();
    }

    /**
     * Create an instance of {@link RelatedCalculationAllObjectIDType }
     * 
     */
    public RelatedCalculationAllObjectIDType createRelatedCalculationAllObjectIDType() {
        return new RelatedCalculationAllObjectIDType();
    }

    /**
     * Create an instance of {@link PositionElementObjectIDType }
     * 
     */
    public PositionElementObjectIDType createPositionElementObjectIDType() {
        return new PositionElementObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollStateAuthorityObjectType }
     * 
     */
    public PayrollStateAuthorityObjectType createPayrollStateAuthorityObjectType() {
        return new PayrollStateAuthorityObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag07ObjectIDType }
     * 
     */
    public CustomWorktag07ObjectIDType createCustomWorktag07ObjectIDType() {
        return new CustomWorktag07ObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag13ObjectType }
     * 
     */
    public CustomWorktag13ObjectType createCustomWorktag13ObjectType() {
        return new CustomWorktag13ObjectType();
    }

    /**
     * Create an instance of {@link ARRCOAGIRCRubricValueObjectType }
     * 
     */
    public ARRCOAGIRCRubricValueObjectType createARRCOAGIRCRubricValueObjectType() {
        return new ARRCOAGIRCRubricValueObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag11ObjectType }
     * 
     */
    public CustomWorktag11ObjectType createCustomWorktag11ObjectType() {
        return new CustomWorktag11ObjectType();
    }

    /**
     * Create an instance of {@link RunCategoryObjectIDType }
     * 
     */
    public RunCategoryObjectIDType createRunCategoryObjectIDType() {
        return new RunCategoryObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollLocalCityAuthorityObjectType }
     * 
     */
    public PayrollLocalCityAuthorityObjectType createPayrollLocalCityAuthorityObjectType() {
        return new PayrollLocalCityAuthorityObjectType();
    }

    /**
     * Create an instance of {@link CustomOrganizationObjectIDType }
     * 
     */
    public CustomOrganizationObjectIDType createCustomOrganizationObjectIDType() {
        return new CustomOrganizationObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag06ObjectIDType }
     * 
     */
    public CustomWorktag06ObjectIDType createCustomWorktag06ObjectIDType() {
        return new CustomWorktag06ObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollOtherAuthorityObjectType }
     * 
     */
    public PayrollOtherAuthorityObjectType createPayrollOtherAuthorityObjectType() {
        return new PayrollOtherAuthorityObjectType();
    }

    /**
     * Create an instance of {@link PayrollStateAuthorityObjectIDType }
     * 
     */
    public PayrollStateAuthorityObjectIDType createPayrollStateAuthorityObjectIDType() {
        return new PayrollStateAuthorityObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag03ObjectIDType }
     * 
     */
    public CustomWorktag03ObjectIDType createCustomWorktag03ObjectIDType() {
        return new CustomWorktag03ObjectIDType();
    }

    /**
     * Create an instance of {@link ProjectObjectIDType }
     * 
     */
    public ProjectObjectIDType createProjectObjectIDType() {
        return new ProjectObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollLocalCountyAuthorityObjectIDType }
     * 
     */
    public PayrollLocalCountyAuthorityObjectIDType createPayrollLocalCountyAuthorityObjectIDType() {
        return new PayrollLocalCountyAuthorityObjectIDType();
    }

    /**
     * Create an instance of {@link WorkerObjectIDType }
     * 
     */
    public WorkerObjectIDType createWorkerObjectIDType() {
        return new WorkerObjectIDType();
    }

    /**
     * Create an instance of {@link EarningAllObjectType }
     * 
     */
    public EarningAllObjectType createEarningAllObjectType() {
        return new EarningAllObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag03ObjectType }
     * 
     */
    public CustomWorktag03ObjectType createCustomWorktag03ObjectType() {
        return new CustomWorktag03ObjectType();
    }

    /**
     * Create an instance of {@link WorkersCompensationCodeObjectType }
     * 
     */
    public WorkersCompensationCodeObjectType createWorkersCompensationCodeObjectType() {
        return new WorkersCompensationCodeObjectType();
    }

    /**
     * Create an instance of {@link CustomWorktag10ObjectIDType }
     * 
     */
    public CustomWorktag10ObjectIDType createCustomWorktag10ObjectIDType() {
        return new CustomWorktag10ObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag07ObjectType }
     * 
     */
    public CustomWorktag07ObjectType createCustomWorktag07ObjectType() {
        return new CustomWorktag07ObjectType();
    }

    /**
     * Create an instance of {@link PayrollLocalSchoolDistrictAuthorityObjectType }
     * 
     */
    public PayrollLocalSchoolDistrictAuthorityObjectType createPayrollLocalSchoolDistrictAuthorityObjectType() {
        return new PayrollLocalSchoolDistrictAuthorityObjectType();
    }

    /**
     * Create an instance of {@link FundObjectType }
     * 
     */
    public FundObjectType createFundObjectType() {
        return new FundObjectType();
    }

    /**
     * Create an instance of {@link LocationObjectIDType }
     * 
     */
    public LocationObjectIDType createLocationObjectIDType() {
        return new LocationObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollOtherAuthorityObjectIDType }
     * 
     */
    public PayrollOtherAuthorityObjectIDType createPayrollOtherAuthorityObjectIDType() {
        return new PayrollOtherAuthorityObjectIDType();
    }

    /**
     * Create an instance of {@link ProgramObjectIDType }
     * 
     */
    public ProgramObjectIDType createProgramObjectIDType() {
        return new ProgramObjectIDType();
    }

    /**
     * Create an instance of {@link CompanyObjectIDType }
     * 
     */
    public CompanyObjectIDType createCompanyObjectIDType() {
        return new CompanyObjectIDType();
    }

    /**
     * Create an instance of {@link PayrollExemptionCodeObjectType }
     * 
     */
    public PayrollExemptionCodeObjectType createPayrollExemptionCodeObjectType() {
        return new PayrollExemptionCodeObjectType();
    }

    /**
     * Create an instance of {@link PositionElementObjectType }
     * 
     */
    public PositionElementObjectType createPositionElementObjectType() {
        return new PositionElementObjectType();
    }

    /**
     * Create an instance of {@link IntegrationSystemAuditedObjectType }
     * 
     */
    public IntegrationSystemAuditedObjectType createIntegrationSystemAuditedObjectType() {
        return new IntegrationSystemAuditedObjectType();
    }

    /**
     * Create an instance of {@link CountryObjectIDType }
     * 
     */
    public CountryObjectIDType createCountryObjectIDType() {
        return new CountryObjectIDType();
    }

    /**
     * Create an instance of {@link CustomWorktag12ObjectIDType }
     * 
     */
    public CustomWorktag12ObjectIDType createCustomWorktag12ObjectIDType() {
        return new CustomWorktag12ObjectIDType();
    }

    /**
     * Create an instance of {@link CurrencyObjectType }
     * 
     */
    public CurrencyObjectType createCurrencyObjectType() {
        return new CurrencyObjectType();
    }

    /**
     * Create an instance of {@link CostCenterObjectIDType }
     * 
     */
    public CostCenterObjectIDType createCostCenterObjectIDType() {
        return new CostCenterObjectIDType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PayrollInputProcessorRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com.workday/bsvc", name = "Payroll_Input_Processor_Request")
    public JAXBElement<PayrollInputProcessorRequestType> createPayrollInputProcessorRequest(PayrollInputProcessorRequestType value) {
        return new JAXBElement<PayrollInputProcessorRequestType>(_PayrollInputProcessorRequest_QNAME, PayrollInputProcessorRequestType.class, null, value);
    }

}


package workday.com.bsvc;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Payroll Worktags
 * 
 * <p>Java class for Payroll_Input_Worktags_DataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Payroll_Input_Worktags_DataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Location_Reference" type="{urn:com.workday/bsvc}LocationObjectType" minOccurs="0"/>
 *         &lt;element name="Region_Reference" type="{urn:com.workday/bsvc}RegionObjectType" minOccurs="0"/>
 *         &lt;element name="Job_Profile_Reference" type="{urn:com.workday/bsvc}Job_ProfileObjectType" minOccurs="0"/>
 *         &lt;element name="Cost_Center_Reference" type="{urn:com.workday/bsvc}Cost_CenterObjectType" minOccurs="0"/>
 *         &lt;choice>
 *           &lt;element name="Project_Reference" type="{urn:com.workday/bsvc}ProjectObjectType" minOccurs="0"/>
 *           &lt;element name="Project_Phase_Reference" type="{urn:com.workday/bsvc}Project_Plan_PhaseObjectType" minOccurs="0"/>
 *           &lt;element name="Project_Task_Reference" type="{urn:com.workday/bsvc}Project_Plan_TaskObjectType" minOccurs="0"/>
 *         &lt;/choice>
 *         &lt;element name="Withholding_Order_Case_Reference" type="{urn:com.workday/bsvc}Withholding_Order_CaseObjectType" minOccurs="0"/>
 *         &lt;element name="State_Authority_Reference" type="{urn:com.workday/bsvc}Payroll_State_AuthorityObjectType" minOccurs="0"/>
 *         &lt;element name="Workers_Compensation_Code_Reference" type="{urn:com.workday/bsvc}Workers_Compensation_CodeObjectType" minOccurs="0"/>
 *         &lt;element name="County_Authority_Reference" type="{urn:com.workday/bsvc}Payroll_Local_County_AuthorityObjectType" minOccurs="0"/>
 *         &lt;element name="City_Authority_Reference" type="{urn:com.workday/bsvc}Payroll_Local_City_AuthorityObjectType" minOccurs="0"/>
 *         &lt;element name="School_District_Authority_Reference" type="{urn:com.workday/bsvc}Payroll_Local_School_District_AuthorityObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_01_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_01ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_02_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_02ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_03_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_03ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_04_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_04ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_05_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_05ObjectType" minOccurs="0"/>
 *         &lt;element name="Fund_Reference" type="{urn:com.workday/bsvc}FundObjectType" minOccurs="0"/>
 *         &lt;element name="Grant_Reference" type="{urn:com.workday/bsvc}GrantObjectType" minOccurs="0"/>
 *         &lt;element name="Gift_Reference" type="{urn:com.workday/bsvc}GiftObjectType" minOccurs="0"/>
 *         &lt;element name="Program_Reference" type="{urn:com.workday/bsvc}ProgramObjectType" minOccurs="0"/>
 *         &lt;element name="Business_Unit_Reference" type="{urn:com.workday/bsvc}Business_UnitObjectType" minOccurs="0"/>
 *         &lt;element name="Object_Class_Reference" type="{urn:com.workday/bsvc}Object_ClassObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Organization_Reference" type="{urn:com.workday/bsvc}Custom_OrganizationObjectType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_06_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_06ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_07_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_07ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_08_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_08ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_09_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_09ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_10_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_10ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_11_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_11ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_12_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_12ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_13_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_13ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_14_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_14ObjectType" minOccurs="0"/>
 *         &lt;element name="Custom_Worktag_15_Reference" type="{urn:com.workday/bsvc}Custom_Worktag_15ObjectType" minOccurs="0"/>
 *         &lt;element name="Local_Other_Tax_Authority_Reference" type="{urn:com.workday/bsvc}Payroll_Other_AuthorityObjectType" minOccurs="0"/>
 *         &lt;element name="NI_Category_Reference" type="{urn:com.workday/bsvc}NI_CategoryObjectType" minOccurs="0"/>
 *         &lt;element name="ARRCO-AGIRC_Category_Reference" type="{urn:com.workday/bsvc}ARRCO-AGIRC_Rubric_ValueObjectType" minOccurs="0"/>
 *         &lt;element name="Income_Code_Reference" type="{urn:com.workday/bsvc}Payroll_Income_CodeObjectType" minOccurs="0"/>
 *         &lt;element name="Exemption_Code_Reference" type="{urn:com.workday/bsvc}Payroll_Exemption_CodeObjectType" minOccurs="0"/>
 *         &lt;element name="Tax_Residency_Country_Reference" type="{urn:com.workday/bsvc}CountryObjectType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Payroll_Input_Worktags_DataType", propOrder = {
    "locationReference",
    "regionReference",
    "jobProfileReference",
    "costCenterReference",
    "projectReference",
    "projectPhaseReference",
    "projectTaskReference",
    "withholdingOrderCaseReference",
    "stateAuthorityReference",
    "workersCompensationCodeReference",
    "countyAuthorityReference",
    "cityAuthorityReference",
    "schoolDistrictAuthorityReference",
    "customWorktag01Reference",
    "customWorktag02Reference",
    "customWorktag03Reference",
    "customWorktag04Reference",
    "customWorktag05Reference",
    "fundReference",
    "grantReference",
    "giftReference",
    "programReference",
    "businessUnitReference",
    "objectClassReference",
    "customOrganizationReference",
    "customWorktag06Reference",
    "customWorktag07Reference",
    "customWorktag08Reference",
    "customWorktag09Reference",
    "customWorktag10Reference",
    "customWorktag11Reference",
    "customWorktag12Reference",
    "customWorktag13Reference",
    "customWorktag14Reference",
    "customWorktag15Reference",
    "localOtherTaxAuthorityReference",
    "niCategoryReference",
    "arrcoagircCategoryReference",
    "incomeCodeReference",
    "exemptionCodeReference",
    "taxResidencyCountryReference"
})
public class PayrollInputWorktagsDataType {

    @XmlElement(name = "Location_Reference")
    protected LocationObjectType locationReference;
    @XmlElement(name = "Region_Reference")
    protected RegionObjectType regionReference;
    @XmlElement(name = "Job_Profile_Reference")
    protected JobProfileObjectType jobProfileReference;
    @XmlElement(name = "Cost_Center_Reference")
    protected CostCenterObjectType costCenterReference;
    @XmlElement(name = "Project_Reference")
    protected ProjectObjectType projectReference;
    @XmlElement(name = "Project_Phase_Reference")
    protected ProjectPlanPhaseObjectType projectPhaseReference;
    @XmlElement(name = "Project_Task_Reference")
    protected ProjectPlanTaskObjectType projectTaskReference;
    @XmlElement(name = "Withholding_Order_Case_Reference")
    protected WithholdingOrderCaseObjectType withholdingOrderCaseReference;
    @XmlElement(name = "State_Authority_Reference")
    protected PayrollStateAuthorityObjectType stateAuthorityReference;
    @XmlElement(name = "Workers_Compensation_Code_Reference")
    protected WorkersCompensationCodeObjectType workersCompensationCodeReference;
    @XmlElement(name = "County_Authority_Reference")
    protected PayrollLocalCountyAuthorityObjectType countyAuthorityReference;
    @XmlElement(name = "City_Authority_Reference")
    protected PayrollLocalCityAuthorityObjectType cityAuthorityReference;
    @XmlElement(name = "School_District_Authority_Reference")
    protected PayrollLocalSchoolDistrictAuthorityObjectType schoolDistrictAuthorityReference;
    @XmlElement(name = "Custom_Worktag_01_Reference")
    protected CustomWorktag01ObjectType customWorktag01Reference;
    @XmlElement(name = "Custom_Worktag_02_Reference")
    protected CustomWorktag02ObjectType customWorktag02Reference;
    @XmlElement(name = "Custom_Worktag_03_Reference")
    protected CustomWorktag03ObjectType customWorktag03Reference;
    @XmlElement(name = "Custom_Worktag_04_Reference")
    protected CustomWorktag04ObjectType customWorktag04Reference;
    @XmlElement(name = "Custom_Worktag_05_Reference")
    protected CustomWorktag05ObjectType customWorktag05Reference;
    @XmlElement(name = "Fund_Reference")
    protected FundObjectType fundReference;
    @XmlElement(name = "Grant_Reference")
    protected GrantObjectType grantReference;
    @XmlElement(name = "Gift_Reference")
    protected GiftObjectType giftReference;
    @XmlElement(name = "Program_Reference")
    protected ProgramObjectType programReference;
    @XmlElement(name = "Business_Unit_Reference")
    protected BusinessUnitObjectType businessUnitReference;
    @XmlElement(name = "Object_Class_Reference")
    protected ObjectClassObjectType objectClassReference;
    @XmlElement(name = "Custom_Organization_Reference")
    protected List<CustomOrganizationObjectType> customOrganizationReference;
    @XmlElement(name = "Custom_Worktag_06_Reference")
    protected CustomWorktag06ObjectType customWorktag06Reference;
    @XmlElement(name = "Custom_Worktag_07_Reference")
    protected CustomWorktag07ObjectType customWorktag07Reference;
    @XmlElement(name = "Custom_Worktag_08_Reference")
    protected CustomWorktag08ObjectType customWorktag08Reference;
    @XmlElement(name = "Custom_Worktag_09_Reference")
    protected CustomWorktag09ObjectType customWorktag09Reference;
    @XmlElement(name = "Custom_Worktag_10_Reference")
    protected CustomWorktag10ObjectType customWorktag10Reference;
    @XmlElement(name = "Custom_Worktag_11_Reference")
    protected CustomWorktag11ObjectType customWorktag11Reference;
    @XmlElement(name = "Custom_Worktag_12_Reference")
    protected CustomWorktag12ObjectType customWorktag12Reference;
    @XmlElement(name = "Custom_Worktag_13_Reference")
    protected CustomWorktag13ObjectType customWorktag13Reference;
    @XmlElement(name = "Custom_Worktag_14_Reference")
    protected CustomWorktag14ObjectType customWorktag14Reference;
    @XmlElement(name = "Custom_Worktag_15_Reference")
    protected CustomWorktag15ObjectType customWorktag15Reference;
    @XmlElement(name = "Local_Other_Tax_Authority_Reference")
    protected PayrollOtherAuthorityObjectType localOtherTaxAuthorityReference;
    @XmlElement(name = "NI_Category_Reference")
    protected NICategoryObjectType niCategoryReference;
    @XmlElement(name = "ARRCO-AGIRC_Category_Reference")
    protected ARRCOAGIRCRubricValueObjectType arrcoagircCategoryReference;
    @XmlElement(name = "Income_Code_Reference")
    protected PayrollIncomeCodeObjectType incomeCodeReference;
    @XmlElement(name = "Exemption_Code_Reference")
    protected PayrollExemptionCodeObjectType exemptionCodeReference;
    @XmlElement(name = "Tax_Residency_Country_Reference")
    protected CountryObjectType taxResidencyCountryReference;

    /**
     * Gets the value of the locationReference property.
     * 
     * @return
     *     possible object is
     *     {@link LocationObjectType }
     *     
     */
    public LocationObjectType getLocationReference() {
        return locationReference;
    }

    /**
     * Sets the value of the locationReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocationObjectType }
     *     
     */
    public void setLocationReference(LocationObjectType value) {
        this.locationReference = value;
    }

    /**
     * Gets the value of the regionReference property.
     * 
     * @return
     *     possible object is
     *     {@link RegionObjectType }
     *     
     */
    public RegionObjectType getRegionReference() {
        return regionReference;
    }

    /**
     * Sets the value of the regionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link RegionObjectType }
     *     
     */
    public void setRegionReference(RegionObjectType value) {
        this.regionReference = value;
    }

    /**
     * Gets the value of the jobProfileReference property.
     * 
     * @return
     *     possible object is
     *     {@link JobProfileObjectType }
     *     
     */
    public JobProfileObjectType getJobProfileReference() {
        return jobProfileReference;
    }

    /**
     * Sets the value of the jobProfileReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link JobProfileObjectType }
     *     
     */
    public void setJobProfileReference(JobProfileObjectType value) {
        this.jobProfileReference = value;
    }

    /**
     * Gets the value of the costCenterReference property.
     * 
     * @return
     *     possible object is
     *     {@link CostCenterObjectType }
     *     
     */
    public CostCenterObjectType getCostCenterReference() {
        return costCenterReference;
    }

    /**
     * Sets the value of the costCenterReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CostCenterObjectType }
     *     
     */
    public void setCostCenterReference(CostCenterObjectType value) {
        this.costCenterReference = value;
    }

    /**
     * Gets the value of the projectReference property.
     * 
     * @return
     *     possible object is
     *     {@link ProjectObjectType }
     *     
     */
    public ProjectObjectType getProjectReference() {
        return projectReference;
    }

    /**
     * Sets the value of the projectReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProjectObjectType }
     *     
     */
    public void setProjectReference(ProjectObjectType value) {
        this.projectReference = value;
    }

    /**
     * Gets the value of the projectPhaseReference property.
     * 
     * @return
     *     possible object is
     *     {@link ProjectPlanPhaseObjectType }
     *     
     */
    public ProjectPlanPhaseObjectType getProjectPhaseReference() {
        return projectPhaseReference;
    }

    /**
     * Sets the value of the projectPhaseReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProjectPlanPhaseObjectType }
     *     
     */
    public void setProjectPhaseReference(ProjectPlanPhaseObjectType value) {
        this.projectPhaseReference = value;
    }

    /**
     * Gets the value of the projectTaskReference property.
     * 
     * @return
     *     possible object is
     *     {@link ProjectPlanTaskObjectType }
     *     
     */
    public ProjectPlanTaskObjectType getProjectTaskReference() {
        return projectTaskReference;
    }

    /**
     * Sets the value of the projectTaskReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProjectPlanTaskObjectType }
     *     
     */
    public void setProjectTaskReference(ProjectPlanTaskObjectType value) {
        this.projectTaskReference = value;
    }

    /**
     * Gets the value of the withholdingOrderCaseReference property.
     * 
     * @return
     *     possible object is
     *     {@link WithholdingOrderCaseObjectType }
     *     
     */
    public WithholdingOrderCaseObjectType getWithholdingOrderCaseReference() {
        return withholdingOrderCaseReference;
    }

    /**
     * Sets the value of the withholdingOrderCaseReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link WithholdingOrderCaseObjectType }
     *     
     */
    public void setWithholdingOrderCaseReference(WithholdingOrderCaseObjectType value) {
        this.withholdingOrderCaseReference = value;
    }

    /**
     * Gets the value of the stateAuthorityReference property.
     * 
     * @return
     *     possible object is
     *     {@link PayrollStateAuthorityObjectType }
     *     
     */
    public PayrollStateAuthorityObjectType getStateAuthorityReference() {
        return stateAuthorityReference;
    }

    /**
     * Sets the value of the stateAuthorityReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link PayrollStateAuthorityObjectType }
     *     
     */
    public void setStateAuthorityReference(PayrollStateAuthorityObjectType value) {
        this.stateAuthorityReference = value;
    }

    /**
     * Gets the value of the workersCompensationCodeReference property.
     * 
     * @return
     *     possible object is
     *     {@link WorkersCompensationCodeObjectType }
     *     
     */
    public WorkersCompensationCodeObjectType getWorkersCompensationCodeReference() {
        return workersCompensationCodeReference;
    }

    /**
     * Sets the value of the workersCompensationCodeReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link WorkersCompensationCodeObjectType }
     *     
     */
    public void setWorkersCompensationCodeReference(WorkersCompensationCodeObjectType value) {
        this.workersCompensationCodeReference = value;
    }

    /**
     * Gets the value of the countyAuthorityReference property.
     * 
     * @return
     *     possible object is
     *     {@link PayrollLocalCountyAuthorityObjectType }
     *     
     */
    public PayrollLocalCountyAuthorityObjectType getCountyAuthorityReference() {
        return countyAuthorityReference;
    }

    /**
     * Sets the value of the countyAuthorityReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link PayrollLocalCountyAuthorityObjectType }
     *     
     */
    public void setCountyAuthorityReference(PayrollLocalCountyAuthorityObjectType value) {
        this.countyAuthorityReference = value;
    }

    /**
     * Gets the value of the cityAuthorityReference property.
     * 
     * @return
     *     possible object is
     *     {@link PayrollLocalCityAuthorityObjectType }
     *     
     */
    public PayrollLocalCityAuthorityObjectType getCityAuthorityReference() {
        return cityAuthorityReference;
    }

    /**
     * Sets the value of the cityAuthorityReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link PayrollLocalCityAuthorityObjectType }
     *     
     */
    public void setCityAuthorityReference(PayrollLocalCityAuthorityObjectType value) {
        this.cityAuthorityReference = value;
    }

    /**
     * Gets the value of the schoolDistrictAuthorityReference property.
     * 
     * @return
     *     possible object is
     *     {@link PayrollLocalSchoolDistrictAuthorityObjectType }
     *     
     */
    public PayrollLocalSchoolDistrictAuthorityObjectType getSchoolDistrictAuthorityReference() {
        return schoolDistrictAuthorityReference;
    }

    /**
     * Sets the value of the schoolDistrictAuthorityReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link PayrollLocalSchoolDistrictAuthorityObjectType }
     *     
     */
    public void setSchoolDistrictAuthorityReference(PayrollLocalSchoolDistrictAuthorityObjectType value) {
        this.schoolDistrictAuthorityReference = value;
    }

    /**
     * Gets the value of the customWorktag01Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag01ObjectType }
     *     
     */
    public CustomWorktag01ObjectType getCustomWorktag01Reference() {
        return customWorktag01Reference;
    }

    /**
     * Sets the value of the customWorktag01Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag01ObjectType }
     *     
     */
    public void setCustomWorktag01Reference(CustomWorktag01ObjectType value) {
        this.customWorktag01Reference = value;
    }

    /**
     * Gets the value of the customWorktag02Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag02ObjectType }
     *     
     */
    public CustomWorktag02ObjectType getCustomWorktag02Reference() {
        return customWorktag02Reference;
    }

    /**
     * Sets the value of the customWorktag02Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag02ObjectType }
     *     
     */
    public void setCustomWorktag02Reference(CustomWorktag02ObjectType value) {
        this.customWorktag02Reference = value;
    }

    /**
     * Gets the value of the customWorktag03Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag03ObjectType }
     *     
     */
    public CustomWorktag03ObjectType getCustomWorktag03Reference() {
        return customWorktag03Reference;
    }

    /**
     * Sets the value of the customWorktag03Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag03ObjectType }
     *     
     */
    public void setCustomWorktag03Reference(CustomWorktag03ObjectType value) {
        this.customWorktag03Reference = value;
    }

    /**
     * Gets the value of the customWorktag04Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag04ObjectType }
     *     
     */
    public CustomWorktag04ObjectType getCustomWorktag04Reference() {
        return customWorktag04Reference;
    }

    /**
     * Sets the value of the customWorktag04Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag04ObjectType }
     *     
     */
    public void setCustomWorktag04Reference(CustomWorktag04ObjectType value) {
        this.customWorktag04Reference = value;
    }

    /**
     * Gets the value of the customWorktag05Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag05ObjectType }
     *     
     */
    public CustomWorktag05ObjectType getCustomWorktag05Reference() {
        return customWorktag05Reference;
    }

    /**
     * Sets the value of the customWorktag05Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag05ObjectType }
     *     
     */
    public void setCustomWorktag05Reference(CustomWorktag05ObjectType value) {
        this.customWorktag05Reference = value;
    }

    /**
     * Gets the value of the fundReference property.
     * 
     * @return
     *     possible object is
     *     {@link FundObjectType }
     *     
     */
    public FundObjectType getFundReference() {
        return fundReference;
    }

    /**
     * Sets the value of the fundReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link FundObjectType }
     *     
     */
    public void setFundReference(FundObjectType value) {
        this.fundReference = value;
    }

    /**
     * Gets the value of the grantReference property.
     * 
     * @return
     *     possible object is
     *     {@link GrantObjectType }
     *     
     */
    public GrantObjectType getGrantReference() {
        return grantReference;
    }

    /**
     * Sets the value of the grantReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link GrantObjectType }
     *     
     */
    public void setGrantReference(GrantObjectType value) {
        this.grantReference = value;
    }

    /**
     * Gets the value of the giftReference property.
     * 
     * @return
     *     possible object is
     *     {@link GiftObjectType }
     *     
     */
    public GiftObjectType getGiftReference() {
        return giftReference;
    }

    /**
     * Sets the value of the giftReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link GiftObjectType }
     *     
     */
    public void setGiftReference(GiftObjectType value) {
        this.giftReference = value;
    }

    /**
     * Gets the value of the programReference property.
     * 
     * @return
     *     possible object is
     *     {@link ProgramObjectType }
     *     
     */
    public ProgramObjectType getProgramReference() {
        return programReference;
    }

    /**
     * Sets the value of the programReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProgramObjectType }
     *     
     */
    public void setProgramReference(ProgramObjectType value) {
        this.programReference = value;
    }

    /**
     * Gets the value of the businessUnitReference property.
     * 
     * @return
     *     possible object is
     *     {@link BusinessUnitObjectType }
     *     
     */
    public BusinessUnitObjectType getBusinessUnitReference() {
        return businessUnitReference;
    }

    /**
     * Sets the value of the businessUnitReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link BusinessUnitObjectType }
     *     
     */
    public void setBusinessUnitReference(BusinessUnitObjectType value) {
        this.businessUnitReference = value;
    }

    /**
     * Gets the value of the objectClassReference property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectClassObjectType }
     *     
     */
    public ObjectClassObjectType getObjectClassReference() {
        return objectClassReference;
    }

    /**
     * Sets the value of the objectClassReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectClassObjectType }
     *     
     */
    public void setObjectClassReference(ObjectClassObjectType value) {
        this.objectClassReference = value;
    }

    /**
     * Gets the value of the customOrganizationReference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customOrganizationReference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomOrganizationReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CustomOrganizationObjectType }
     * 
     * 
     */
    public List<CustomOrganizationObjectType> getCustomOrganizationReference() {
        if (customOrganizationReference == null) {
            customOrganizationReference = new ArrayList<CustomOrganizationObjectType>();
        }
        return this.customOrganizationReference;
    }

    /**
     * Gets the value of the customWorktag06Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag06ObjectType }
     *     
     */
    public CustomWorktag06ObjectType getCustomWorktag06Reference() {
        return customWorktag06Reference;
    }

    /**
     * Sets the value of the customWorktag06Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag06ObjectType }
     *     
     */
    public void setCustomWorktag06Reference(CustomWorktag06ObjectType value) {
        this.customWorktag06Reference = value;
    }

    /**
     * Gets the value of the customWorktag07Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag07ObjectType }
     *     
     */
    public CustomWorktag07ObjectType getCustomWorktag07Reference() {
        return customWorktag07Reference;
    }

    /**
     * Sets the value of the customWorktag07Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag07ObjectType }
     *     
     */
    public void setCustomWorktag07Reference(CustomWorktag07ObjectType value) {
        this.customWorktag07Reference = value;
    }

    /**
     * Gets the value of the customWorktag08Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag08ObjectType }
     *     
     */
    public CustomWorktag08ObjectType getCustomWorktag08Reference() {
        return customWorktag08Reference;
    }

    /**
     * Sets the value of the customWorktag08Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag08ObjectType }
     *     
     */
    public void setCustomWorktag08Reference(CustomWorktag08ObjectType value) {
        this.customWorktag08Reference = value;
    }

    /**
     * Gets the value of the customWorktag09Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag09ObjectType }
     *     
     */
    public CustomWorktag09ObjectType getCustomWorktag09Reference() {
        return customWorktag09Reference;
    }

    /**
     * Sets the value of the customWorktag09Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag09ObjectType }
     *     
     */
    public void setCustomWorktag09Reference(CustomWorktag09ObjectType value) {
        this.customWorktag09Reference = value;
    }

    /**
     * Gets the value of the customWorktag10Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag10ObjectType }
     *     
     */
    public CustomWorktag10ObjectType getCustomWorktag10Reference() {
        return customWorktag10Reference;
    }

    /**
     * Sets the value of the customWorktag10Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag10ObjectType }
     *     
     */
    public void setCustomWorktag10Reference(CustomWorktag10ObjectType value) {
        this.customWorktag10Reference = value;
    }

    /**
     * Gets the value of the customWorktag11Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag11ObjectType }
     *     
     */
    public CustomWorktag11ObjectType getCustomWorktag11Reference() {
        return customWorktag11Reference;
    }

    /**
     * Sets the value of the customWorktag11Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag11ObjectType }
     *     
     */
    public void setCustomWorktag11Reference(CustomWorktag11ObjectType value) {
        this.customWorktag11Reference = value;
    }

    /**
     * Gets the value of the customWorktag12Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag12ObjectType }
     *     
     */
    public CustomWorktag12ObjectType getCustomWorktag12Reference() {
        return customWorktag12Reference;
    }

    /**
     * Sets the value of the customWorktag12Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag12ObjectType }
     *     
     */
    public void setCustomWorktag12Reference(CustomWorktag12ObjectType value) {
        this.customWorktag12Reference = value;
    }

    /**
     * Gets the value of the customWorktag13Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag13ObjectType }
     *     
     */
    public CustomWorktag13ObjectType getCustomWorktag13Reference() {
        return customWorktag13Reference;
    }

    /**
     * Sets the value of the customWorktag13Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag13ObjectType }
     *     
     */
    public void setCustomWorktag13Reference(CustomWorktag13ObjectType value) {
        this.customWorktag13Reference = value;
    }

    /**
     * Gets the value of the customWorktag14Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag14ObjectType }
     *     
     */
    public CustomWorktag14ObjectType getCustomWorktag14Reference() {
        return customWorktag14Reference;
    }

    /**
     * Sets the value of the customWorktag14Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag14ObjectType }
     *     
     */
    public void setCustomWorktag14Reference(CustomWorktag14ObjectType value) {
        this.customWorktag14Reference = value;
    }

    /**
     * Gets the value of the customWorktag15Reference property.
     * 
     * @return
     *     possible object is
     *     {@link CustomWorktag15ObjectType }
     *     
     */
    public CustomWorktag15ObjectType getCustomWorktag15Reference() {
        return customWorktag15Reference;
    }

    /**
     * Sets the value of the customWorktag15Reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomWorktag15ObjectType }
     *     
     */
    public void setCustomWorktag15Reference(CustomWorktag15ObjectType value) {
        this.customWorktag15Reference = value;
    }

    /**
     * Gets the value of the localOtherTaxAuthorityReference property.
     * 
     * @return
     *     possible object is
     *     {@link PayrollOtherAuthorityObjectType }
     *     
     */
    public PayrollOtherAuthorityObjectType getLocalOtherTaxAuthorityReference() {
        return localOtherTaxAuthorityReference;
    }

    /**
     * Sets the value of the localOtherTaxAuthorityReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link PayrollOtherAuthorityObjectType }
     *     
     */
    public void setLocalOtherTaxAuthorityReference(PayrollOtherAuthorityObjectType value) {
        this.localOtherTaxAuthorityReference = value;
    }

    /**
     * Gets the value of the niCategoryReference property.
     * 
     * @return
     *     possible object is
     *     {@link NICategoryObjectType }
     *     
     */
    public NICategoryObjectType getNICategoryReference() {
        return niCategoryReference;
    }

    /**
     * Sets the value of the niCategoryReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link NICategoryObjectType }
     *     
     */
    public void setNICategoryReference(NICategoryObjectType value) {
        this.niCategoryReference = value;
    }

    /**
     * Gets the value of the arrcoagircCategoryReference property.
     * 
     * @return
     *     possible object is
     *     {@link ARRCOAGIRCRubricValueObjectType }
     *     
     */
    public ARRCOAGIRCRubricValueObjectType getARRCOAGIRCCategoryReference() {
        return arrcoagircCategoryReference;
    }

    /**
     * Sets the value of the arrcoagircCategoryReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link ARRCOAGIRCRubricValueObjectType }
     *     
     */
    public void setARRCOAGIRCCategoryReference(ARRCOAGIRCRubricValueObjectType value) {
        this.arrcoagircCategoryReference = value;
    }

    /**
     * Gets the value of the incomeCodeReference property.
     * 
     * @return
     *     possible object is
     *     {@link PayrollIncomeCodeObjectType }
     *     
     */
    public PayrollIncomeCodeObjectType getIncomeCodeReference() {
        return incomeCodeReference;
    }

    /**
     * Sets the value of the incomeCodeReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link PayrollIncomeCodeObjectType }
     *     
     */
    public void setIncomeCodeReference(PayrollIncomeCodeObjectType value) {
        this.incomeCodeReference = value;
    }

    /**
     * Gets the value of the exemptionCodeReference property.
     * 
     * @return
     *     possible object is
     *     {@link PayrollExemptionCodeObjectType }
     *     
     */
    public PayrollExemptionCodeObjectType getExemptionCodeReference() {
        return exemptionCodeReference;
    }

    /**
     * Sets the value of the exemptionCodeReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link PayrollExemptionCodeObjectType }
     *     
     */
    public void setExemptionCodeReference(PayrollExemptionCodeObjectType value) {
        this.exemptionCodeReference = value;
    }

    /**
     * Gets the value of the taxResidencyCountryReference property.
     * 
     * @return
     *     possible object is
     *     {@link CountryObjectType }
     *     
     */
    public CountryObjectType getTaxResidencyCountryReference() {
        return taxResidencyCountryReference;
    }

    /**
     * Sets the value of the taxResidencyCountryReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryObjectType }
     *     
     */
    public void setTaxResidencyCountryReference(CountryObjectType value) {
        this.taxResidencyCountryReference = value;
    }

}

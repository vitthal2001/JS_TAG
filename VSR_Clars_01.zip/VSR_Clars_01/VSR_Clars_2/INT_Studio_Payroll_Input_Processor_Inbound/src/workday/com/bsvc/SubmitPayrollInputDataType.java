
package workday.com.bsvc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Submit Payroll Input Data
 * 
 * <p>Java class for Submit_Payroll_Input_DataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Submit_Payroll_Input_DataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Origin_Record_Nbr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Payroll_Input_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Batch_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Source_Reference" type="{urn:com.workday/bsvc}Integration_System__Audited_ObjectType" minOccurs="0"/>
 *         &lt;element name="Ongoing_Input" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Match_Existing_Record" type="{urn:com.workday/bsvc}Match_Existing_RecordObjectType" minOccurs="0"/>
 *         &lt;choice>
 *           &lt;element name="Start_Date_Lookup" type="{urn:com.workday/bsvc}StartEnd_DateTypeEnumeration" minOccurs="0"/>
 *           &lt;element name="Start_Date" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;/choice>
 *         &lt;choice>
 *           &lt;element name="End_Date_Lookup" type="{urn:com.workday/bsvc}StartEnd_DateTypeEnumeration" minOccurs="0"/>
 *           &lt;element name="End_Date" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;/choice>
 *         &lt;element name="Run_Category_Reference" type="{urn:com.workday/bsvc}Run_CategoryObjectType" minOccurs="0"/>
 *         &lt;element name="Worker_Reference" type="{urn:com.workday/bsvc}WorkerObjectType"/>
 *         &lt;element name="Position_Reference" type="{urn:com.workday/bsvc}Position_ElementObjectType" minOccurs="0"/>
 *         &lt;choice>
 *           &lt;element name="Earning_Reference" type="{urn:com.workday/bsvc}Earning__All_ObjectType"/>
 *           &lt;element name="Deduction_Reference" type="{urn:com.workday/bsvc}Deduction__All_ObjectType"/>
 *         &lt;/choice>
 *         &lt;element name="Amount" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;totalDigits value="26"/>
 *               &lt;fractionDigits value="6"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Hours" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;totalDigits value="26"/>
 *               &lt;fractionDigits value="6"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Rate" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;totalDigits value="26"/>
 *               &lt;fractionDigits value="6"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Adjustment" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Worktag_Data" type="{urn:com.workday/bsvc}Payroll_Input_Worktags_DataType" minOccurs="0"/>
 *         &lt;element name="Additional_Input_Details_Data" type="{urn:com.workday/bsvc}Additional_Input_DetailsType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Comment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Currency_Reference" type="{urn:com.workday/bsvc}CurrencyObjectType" minOccurs="0"/>
 *         &lt;element name="Company_Reference" type="{urn:com.workday/bsvc}CompanyObjectType" minOccurs="0"/>
 *         &lt;element name="Costing_Company_Reference" type="{urn:com.workday/bsvc}CompanyObjectType" minOccurs="0"/>
 *         &lt;element name="Coverage_Start_Date" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Coverage_End_Date" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Last_Period_End_Date" type="{http://www.w3.org/2001/XMLSchema}date" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Submit_Payroll_Input_DataType", propOrder = {
    "originRecordNbr",
    "payrollInputID",
    "batchID",
    "sourceReference",
    "ongoingInput",
    "matchExistingRecord",
    "startDateLookup",
    "startDate",
    "endDateLookup",
    "endDate",
    "runCategoryReference",
    "workerReference",
    "positionReference",
    "earningReference",
    "deductionReference",
    "amount",
    "hours",
    "rate",
    "adjustment",
    "worktagData",
    "additionalInputDetailsData",
    "comment",
    "currencyReference",
    "companyReference",
    "costingCompanyReference",
    "coverageStartDate",
    "coverageEndDate"
})
public class SubmitPayrollInputDataType {

    @XmlElement(name = "Origin_Record_Nbr")
    protected String originRecordNbr;
    @XmlElement(name = "Payroll_Input_ID")
    protected String payrollInputID;
    @XmlElement(name = "Batch_ID")
    protected String batchID;
    @XmlElement(name = "Source_Reference")
    protected IntegrationSystemAuditedObjectType sourceReference;
    @XmlElement(name = "Ongoing_Input")
    protected Boolean ongoingInput;
    @XmlElement(name = "Match_Existing_Record")
    protected MatchExistingRecordObjectType matchExistingRecord;
    @XmlElement(name = "Start_Date_Lookup")
    protected String startDateLookup;
    @XmlElement(name = "Start_Date")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar startDate;
    @XmlElement(name = "End_Date_Lookup")
    protected String endDateLookup;
    @XmlElement(name = "End_Date")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar endDate;
    @XmlElement(name = "Run_Category_Reference")
    protected RunCategoryObjectType runCategoryReference;
    @XmlElement(name = "Worker_Reference", required = true)
    protected WorkerObjectType workerReference;
    @XmlElement(name = "Position_Reference")
    protected PositionElementObjectType positionReference;
    @XmlElement(name = "Earning_Reference")
    protected EarningAllObjectType earningReference;
    @XmlElement(name = "Deduction_Reference")
    protected DeductionAllObjectType deductionReference;
    @XmlElement(name = "Amount")
    protected BigDecimal amount;
    @XmlElement(name = "Hours")
    protected BigDecimal hours;
    @XmlElement(name = "Rate")
    protected BigDecimal rate;
    @XmlElement(name = "Adjustment")
    protected Boolean adjustment;
    @XmlElement(name = "Worktag_Data")
    protected PayrollInputWorktagsDataType worktagData;
    @XmlElement(name = "Additional_Input_Details_Data")
    protected List<AdditionalInputDetailsType> additionalInputDetailsData;
    @XmlElement(name = "Comment")
    protected String comment;
    @XmlElement(name = "Currency_Reference")
    protected CurrencyObjectType currencyReference;
    @XmlElement(name = "Company_Reference")
    protected CompanyObjectType companyReference;
    @XmlElement(name = "Costing_Company_Reference")
    protected CompanyObjectType costingCompanyReference;
    @XmlElement(name = "Coverage_Start_Date")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar coverageStartDate;
    @XmlElement(name = "Coverage_End_Date")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar coverageEndDate;
    @XmlAttribute(name = "Last_Period_End_Date", namespace = "urn:com.workday/bsvc")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar lastPeriodEndDate;

    /**
     * Gets the value of the originRecordNbr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginRecordNbr() {
        return originRecordNbr;
    }

    /**
     * Sets the value of the originRecordNbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginRecordNbr(String value) {
        this.originRecordNbr = value;
    }

    /**
     * Gets the value of the payrollInputID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayrollInputID() {
        return payrollInputID;
    }

    /**
     * Sets the value of the payrollInputID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayrollInputID(String value) {
        this.payrollInputID = value;
    }

    /**
     * Gets the value of the batchID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatchID() {
        return batchID;
    }

    /**
     * Sets the value of the batchID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatchID(String value) {
        this.batchID = value;
    }

    /**
     * Gets the value of the sourceReference property.
     * 
     * @return
     *     possible object is
     *     {@link IntegrationSystemAuditedObjectType }
     *     
     */
    public IntegrationSystemAuditedObjectType getSourceReference() {
        return sourceReference;
    }

    /**
     * Sets the value of the sourceReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link IntegrationSystemAuditedObjectType }
     *     
     */
    public void setSourceReference(IntegrationSystemAuditedObjectType value) {
        this.sourceReference = value;
    }

    /**
     * Gets the value of the ongoingInput property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isOngoingInput() {
        return ongoingInput;
    }

    /**
     * Sets the value of the ongoingInput property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOngoingInput(Boolean value) {
        this.ongoingInput = value;
    }

    /**
     * Gets the value of the matchExistingRecord property.
     * 
     * @return
     *     possible object is
     *     {@link MatchExistingRecordObjectType }
     *     
     */
    public MatchExistingRecordObjectType getMatchExistingRecord() {
        return matchExistingRecord;
    }

    /**
     * Sets the value of the matchExistingRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link MatchExistingRecordObjectType }
     *     
     */
    public void setMatchExistingRecord(MatchExistingRecordObjectType value) {
        this.matchExistingRecord = value;
    }

    /**
     * Gets the value of the startDateLookup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartDateLookup() {
        return startDateLookup;
    }

    /**
     * Sets the value of the startDateLookup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDateLookup(String value) {
        this.startDateLookup = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStartDate(XMLGregorianCalendar value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the endDateLookup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndDateLookup() {
        return endDateLookup;
    }

    /**
     * Sets the value of the endDateLookup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDateLookup(String value) {
        this.endDateLookup = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEndDate(XMLGregorianCalendar value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the runCategoryReference property.
     * 
     * @return
     *     possible object is
     *     {@link RunCategoryObjectType }
     *     
     */
    public RunCategoryObjectType getRunCategoryReference() {
        return runCategoryReference;
    }

    /**
     * Sets the value of the runCategoryReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link RunCategoryObjectType }
     *     
     */
    public void setRunCategoryReference(RunCategoryObjectType value) {
        this.runCategoryReference = value;
    }

    /**
     * Gets the value of the workerReference property.
     * 
     * @return
     *     possible object is
     *     {@link WorkerObjectType }
     *     
     */
    public WorkerObjectType getWorkerReference() {
        return workerReference;
    }

    /**
     * Sets the value of the workerReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link WorkerObjectType }
     *     
     */
    public void setWorkerReference(WorkerObjectType value) {
        this.workerReference = value;
    }

    /**
     * Gets the value of the positionReference property.
     * 
     * @return
     *     possible object is
     *     {@link PositionElementObjectType }
     *     
     */
    public PositionElementObjectType getPositionReference() {
        return positionReference;
    }

    /**
     * Sets the value of the positionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link PositionElementObjectType }
     *     
     */
    public void setPositionReference(PositionElementObjectType value) {
        this.positionReference = value;
    }

    /**
     * Gets the value of the earningReference property.
     * 
     * @return
     *     possible object is
     *     {@link EarningAllObjectType }
     *     
     */
    public EarningAllObjectType getEarningReference() {
        return earningReference;
    }

    /**
     * Sets the value of the earningReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link EarningAllObjectType }
     *     
     */
    public void setEarningReference(EarningAllObjectType value) {
        this.earningReference = value;
    }

    /**
     * Gets the value of the deductionReference property.
     * 
     * @return
     *     possible object is
     *     {@link DeductionAllObjectType }
     *     
     */
    public DeductionAllObjectType getDeductionReference() {
        return deductionReference;
    }

    /**
     * Sets the value of the deductionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeductionAllObjectType }
     *     
     */
    public void setDeductionReference(DeductionAllObjectType value) {
        this.deductionReference = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmount(BigDecimal value) {
        this.amount = value;
    }

    /**
     * Gets the value of the hours property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHours() {
        return hours;
    }

    /**
     * Sets the value of the hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHours(BigDecimal value) {
        this.hours = value;
    }

    /**
     * Gets the value of the rate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getRate() {
        return rate;
    }

    /**
     * Sets the value of the rate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setRate(BigDecimal value) {
        this.rate = value;
    }

    /**
     * Gets the value of the adjustment property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAdjustment() {
        return adjustment;
    }

    /**
     * Sets the value of the adjustment property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAdjustment(Boolean value) {
        this.adjustment = value;
    }

    /**
     * Gets the value of the worktagData property.
     * 
     * @return
     *     possible object is
     *     {@link PayrollInputWorktagsDataType }
     *     
     */
    public PayrollInputWorktagsDataType getWorktagData() {
        return worktagData;
    }

    /**
     * Sets the value of the worktagData property.
     * 
     * @param value
     *     allowed object is
     *     {@link PayrollInputWorktagsDataType }
     *     
     */
    public void setWorktagData(PayrollInputWorktagsDataType value) {
        this.worktagData = value;
    }

    /**
     * Gets the value of the additionalInputDetailsData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalInputDetailsData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalInputDetailsData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalInputDetailsType }
     * 
     * 
     */
    public List<AdditionalInputDetailsType> getAdditionalInputDetailsData() {
        if (additionalInputDetailsData == null) {
            additionalInputDetailsData = new ArrayList<AdditionalInputDetailsType>();
        }
        return this.additionalInputDetailsData;
    }

    /**
     * Gets the value of the comment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the value of the comment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComment(String value) {
        this.comment = value;
    }

    /**
     * Gets the value of the currencyReference property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyObjectType }
     *     
     */
    public CurrencyObjectType getCurrencyReference() {
        return currencyReference;
    }

    /**
     * Sets the value of the currencyReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyObjectType }
     *     
     */
    public void setCurrencyReference(CurrencyObjectType value) {
        this.currencyReference = value;
    }

    /**
     * Gets the value of the companyReference property.
     * 
     * @return
     *     possible object is
     *     {@link CompanyObjectType }
     *     
     */
    public CompanyObjectType getCompanyReference() {
        return companyReference;
    }

    /**
     * Sets the value of the companyReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CompanyObjectType }
     *     
     */
    public void setCompanyReference(CompanyObjectType value) {
        this.companyReference = value;
    }

    /**
     * Gets the value of the costingCompanyReference property.
     * 
     * @return
     *     possible object is
     *     {@link CompanyObjectType }
     *     
     */
    public CompanyObjectType getCostingCompanyReference() {
        return costingCompanyReference;
    }

    /**
     * Sets the value of the costingCompanyReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CompanyObjectType }
     *     
     */
    public void setCostingCompanyReference(CompanyObjectType value) {
        this.costingCompanyReference = value;
    }

    /**
     * Gets the value of the coverageStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCoverageStartDate() {
        return coverageStartDate;
    }

    /**
     * Sets the value of the coverageStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCoverageStartDate(XMLGregorianCalendar value) {
        this.coverageStartDate = value;
    }

    /**
     * Gets the value of the coverageEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCoverageEndDate() {
        return coverageEndDate;
    }

    /**
     * Sets the value of the coverageEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCoverageEndDate(XMLGregorianCalendar value) {
        this.coverageEndDate = value;
    }

    /**
     * Gets the value of the lastPeriodEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastPeriodEndDate() {
        return lastPeriodEndDate;
    }

    /**
     * Sets the value of the lastPeriodEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastPeriodEndDate(XMLGregorianCalendar value) {
        this.lastPeriodEndDate = value;
    }

}

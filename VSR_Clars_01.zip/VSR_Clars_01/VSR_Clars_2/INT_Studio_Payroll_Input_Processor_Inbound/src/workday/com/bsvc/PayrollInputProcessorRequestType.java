
package workday.com.bsvc;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Payroll Input Processor Request
 * 
 * <p>Java class for Payroll_Input_Processor_RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Payroll_Input_Processor_RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Default_Batch_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Force_Primary_Position_When_Empty" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Minimize_Sub_Period_For_Terminated_Workers" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Payroll_Input_Data" type="{urn:com.workday/bsvc}Submit_Payroll_Input_DataType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Payroll_Input_Processor_RequestType", propOrder = {
    "defaultBatchID",
    "forcePrimaryPositionWhenEmpty",
    "minimizeSubPeriodForTerminatedWorkers",
    "payrollInputData"
})
public class PayrollInputProcessorRequestType {

    @XmlElement(name = "Default_Batch_ID", required = true)
    protected String defaultBatchID;
    @XmlElement(name = "Force_Primary_Position_When_Empty")
    protected Boolean forcePrimaryPositionWhenEmpty;
    @XmlElement(name = "Minimize_Sub_Period_For_Terminated_Workers")
    protected Boolean minimizeSubPeriodForTerminatedWorkers;
    @XmlElement(name = "Payroll_Input_Data")
    protected List<SubmitPayrollInputDataType> payrollInputData;

    /**
     * Gets the value of the defaultBatchID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultBatchID() {
        return defaultBatchID;
    }

    /**
     * Sets the value of the defaultBatchID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultBatchID(String value) {
        this.defaultBatchID = value;
    }

    /**
     * Gets the value of the forcePrimaryPositionWhenEmpty property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isForcePrimaryPositionWhenEmpty() {
        return forcePrimaryPositionWhenEmpty;
    }

    /**
     * Sets the value of the forcePrimaryPositionWhenEmpty property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setForcePrimaryPositionWhenEmpty(Boolean value) {
        this.forcePrimaryPositionWhenEmpty = value;
    }

    /**
     * Gets the value of the minimizeSubPeriodForTerminatedWorkers property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMinimizeSubPeriodForTerminatedWorkers() {
        return minimizeSubPeriodForTerminatedWorkers;
    }

    /**
     * Sets the value of the minimizeSubPeriodForTerminatedWorkers property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMinimizeSubPeriodForTerminatedWorkers(Boolean value) {
        this.minimizeSubPeriodForTerminatedWorkers = value;
    }

    /**
     * Gets the value of the payrollInputData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the payrollInputData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPayrollInputData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SubmitPayrollInputDataType }
     * 
     * 
     */
    public List<SubmitPayrollInputDataType> getPayrollInputData() {
        if (payrollInputData == null) {
            payrollInputData = new ArrayList<SubmitPayrollInputDataType>();
        }
        return this.payrollInputData;
    }
    
    /* MODIFIED */
    public void setPayrollInputData(ArrayList<SubmitPayrollInputDataType> value) {
    	this.payrollInputData = value;
    }

}

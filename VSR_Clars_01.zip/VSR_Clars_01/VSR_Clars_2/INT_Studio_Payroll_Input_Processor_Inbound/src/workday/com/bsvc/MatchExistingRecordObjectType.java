
package workday.com.bsvc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Payroll Input Processor Match Existing Record Element
 * 
 * <p>Java class for Match_Existing_RecordObjectType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Match_Existing_RecordObjectType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="End_Only" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;choice>
 *           &lt;element name="End_Date_Lookup" type="{urn:com.workday/bsvc}StartEnd_DateTypeEnumeration" minOccurs="0"/>
 *           &lt;element name="End_Date" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;/choice>
 *         &lt;element name="Minimize_Updates_When_Matching_Amount" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Match_On_Worktags" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Match_Does_Not_Exist_Log_Level" type="{urn:com.workday/bsvc}LogLevelTypeEnumeration" minOccurs="0"/>
 *         &lt;element name="Match_Multiple_Exist_Log_Level" type="{urn:com.workday/bsvc}LogLevelTypeEnumeration" minOccurs="0"/>
 *         &lt;element name="End_All_Matches" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Replace_Existing_Batch_ID" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Match_Existing_RecordObjectType", propOrder = {
    "endOnly",
    "endDateLookup",
    "endDate",
    "minimizeUpdatesWhenMatchingAmount",
    "matchOnWorktags",
    "matchDoesNotExistLogLevel",
    "matchMultipleExistLogLevel",
    "endAllMatches",
    "replaceExistingBatchID"
})
public class MatchExistingRecordObjectType {

    @XmlElement(name = "End_Only")
    protected Boolean endOnly;
    @XmlElement(name = "End_Date_Lookup")
    protected String endDateLookup;
    @XmlElement(name = "End_Date")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar endDate;
    @XmlElement(name = "Minimize_Updates_When_Matching_Amount")
    protected Boolean minimizeUpdatesWhenMatchingAmount;
    @XmlElement(name = "Match_On_Worktags")
    protected Boolean matchOnWorktags;
    @XmlElement(name = "Match_Does_Not_Exist_Log_Level")
    protected String matchDoesNotExistLogLevel;
    @XmlElement(name = "Match_Multiple_Exist_Log_Level")
    protected String matchMultipleExistLogLevel;
    @XmlElement(name = "End_All_Matches")
    protected Boolean endAllMatches;
    @XmlElement(name = "Replace_Existing_Batch_ID")
    protected Boolean replaceExistingBatchID;

    /**
     * Gets the value of the endOnly property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEndOnly() {
        return endOnly;
    }

    /**
     * Sets the value of the endOnly property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEndOnly(Boolean value) {
        this.endOnly = value;
    }

    /**
     * Gets the value of the endDateLookup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndDateLookup() {
        return endDateLookup;
    }

    /**
     * Sets the value of the endDateLookup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDateLookup(String value) {
        this.endDateLookup = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEndDate(XMLGregorianCalendar value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the minimizeUpdatesWhenMatchingQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMinimizeUpdatesWhenMatchingAmount() {
        return minimizeUpdatesWhenMatchingAmount;
    }

    /**
     * Sets the value of the minimizeUpdatesWhenMatchingQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMinimizeUpdatesWhenMatchingAmount(Boolean value) {
        this.minimizeUpdatesWhenMatchingAmount = value;
    }
    
    /**
     * Gets the value of the matchOnWorktags property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMatchOnWorktags() {
        return matchOnWorktags;
    }

    /**
     * Sets the value of the matchOnWorktags property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMatchOnWorktags(Boolean value) {
        this.matchOnWorktags = value;
    }

    /**
     * Gets the value of the matchDoesNotExistLogLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMatchDoesNotExistLogLevel() {
        return matchDoesNotExistLogLevel;
    }

    /**
     * Sets the value of the matchDoesNotExistLogLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMatchDoesNotExistLogLevel(String value) {
        this.matchDoesNotExistLogLevel = value;
    }

    /**
     * Gets the value of the matchMultipleExistLogLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMatchMultipleExistLogLevel() {
        return matchMultipleExistLogLevel;
    }

    /**
     * Sets the value of the matchMultipleExistLogLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMatchMultipleExistLogLevel(String value) {
        this.matchMultipleExistLogLevel = value;
    }

    /**
     * Gets the value of the endAllMatches property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEndAllMatches() {
        return endAllMatches;
    }

    /**
     * Sets the value of the endAllMatches property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEndAllMatches(Boolean value) {
        this.endAllMatches = value;
    }
    
    /**
     * Gets the value of the replaceExistingBatchID property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReplaceExistingBatchID() {
        return replaceExistingBatchID;
    }

    /**
     * Sets the value of the replaceExistingBatchID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReplaceExistingBatchID(Boolean value) {
        this.replaceExistingBatchID = value;
    }

}

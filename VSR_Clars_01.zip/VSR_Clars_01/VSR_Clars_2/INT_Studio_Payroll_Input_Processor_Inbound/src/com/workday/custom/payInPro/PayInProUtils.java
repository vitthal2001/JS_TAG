package com.workday.custom.payInPro;

import java.io.InputStream;
import java.io.InputStreamReader;

import javax.xml.transform.dom.DOMSource;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.capeclear.logger.Logger;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.DataHandlerSource;
import com.capeclear.mediation.impl.mediators.utils.XPath;
import com.capeclear.xml.utils.DOMUtils;

public final class PayInProUtils {
	public static boolean isVariableNullOrUndefined(MediationContext mc, String variableName) throws Exception {
		return (!mc.getVariables().containsKey(variableName)) || mc.getVariables().getVariable(variableName) == null;
	}
	
	public static InputStream getVariableInputStream(MediationContext mc, String variableName) throws Exception {
		return ((DataHandlerSource)mc.getVariables().getVariable(variableName)).getInputStream();
	}
	
	public static InputStream getMessageInputStream(MediationContext mc) throws Exception {
		return (InputStream)mc.getMessage().getMessagePart(0, InputStream.class);
	}
	
	public static Document getVariableAsXmlDocument(MediationContext mc, String variableName) throws Exception {
		return DOMUtils.parseToDOM(new InputSource(new InputStreamReader(((DataHandlerSource)mc.getVariables().getVariable(variableName)).getInputStream(), "UTF-8")));
	}
	
	public static Document getMessageAsXmlDocument(MediationContext mc) throws Exception {
		return mc.getMessage().isNullPart(0) ? null : DOMUtils.parseToDOM(new InputSource(new InputStreamReader(getMessageInputStream(mc), "UTF-8")));
	}
	
	@SuppressWarnings("unchecked")
	public static DOMSource getMessageAsDOMSource(MediationContext mc) throws Exception {
		return mc.getMessage().isNullPart(0) ? null : (DOMSource)mc.getMessage().getMessage(new Class[] {DOMSource.class});
	}
	
	public static Node getDocumentRootNode(DOMSource source) {
		return (source == null) ? null : source.getNode();
	}

	public static void logErrorAndThrowRuntimeException(Logger log, String message, Throwable t) throws Throwable {
		log.error(message, t);
		throw new RuntimeException(message, t);
	}
	
	public static String getValueFromVariableXml(MediationContext mc, String variableName, String xpathToValue) throws Exception {
    	return new XPath(xpathToValue, MediationConstants.ASSEMBLY_VERSION, mc).stringValueOf(getVariableAsXmlDocument(mc, variableName));
	}
}

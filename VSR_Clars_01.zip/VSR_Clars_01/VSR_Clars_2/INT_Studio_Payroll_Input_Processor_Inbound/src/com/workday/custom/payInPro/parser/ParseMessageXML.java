/* 	
 * The schema defined by this Studio has the same root element as the Import_Payroll_Input and Get_Submit_Payroll_Input web services.
 * However, the custom schema has additional elements and attributes.
 * This class is used to parse a generic payroll input object including the custom elements and attributes.
 */

package com.workday.custom.payInPro.parser;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
import com.capeclear.xml.utils.XmlUtils;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;

/**
 * @author aaron.mazek
 *	This class has been created as a base for parsing and processing mediation message XML in a streaming manner.
 *	Extend this class to build functionality based on your requirements.  
 */
@Component(name = "ParseMessageXML", type = mediation, toolTip = "", scope = "prototype", smallIconPath = "icons/ParseMessageXML_16.png", largeIconPath = "icons/ParseMessageXML_24.png")
public abstract class ParseMessageXML {
	// Required entry tag name
	public String entryTagName;

	// Mediation Context
	public MediationContext ctx;

	//
	public HashMap<String, String> attributeMap;

	/**
	 * This method is called by the Assembly framework.
	 *
	 * Use the <code>MediationContext</code> to access objects in the context, such
	 * as the message, properties and variables e.g.
	 * <ul>
	 * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
	 * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
	 * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
	 * </ul>
	 */
	@ComponentMethod
	public void process(java.io.InputStream input, java.io.OutputStream output) {

		// Must be first in this method to instantiate the current Mediation Context.
		ctx = MediationTube.getCurrentMediationContext();

		// getEntryTagName must be implemented and should return the entryTagName value.
		// The returned values is then used throughout the processing of the XML.
		entryTagName = this.getEntryTagName();

		// Gets all of the custom Mediation Context properties and values.
		getCustomMediationContextProperties();

		String lastElement = entryTagName;
		int lastNodeLength = 0;

		// Clean-up entry tag element name.
		if (lastElement.contains("/")) {
			lastNodeLength = lastElement.split("/").length;
			lastElement = lastElement.split("/")[lastNodeLength - 1];
		}

		if (lastElement.contains("\\")) {
			lastNodeLength = lastElement.split("\\\\").length;
			lastElement = lastElement.split("\\\\")[lastNodeLength - 1];
		}

		// Create the XMLInputFactory. The factory is a class that is used to create the
		// XMLReader.
		XMLInputFactory inputFactory = XmlUtils.getXMLInputFactory();

		// Create the XMLReader
		XMLEventReader xmlReader;

		// Try to create the reader from the factory
		try {
			// input is from the parameters passed in to the process method
			xmlReader = inputFactory.createXMLEventReader(input);
		} catch (XMLStreamException e) {
			// If the message passed in is not XML, then the error below is likely.
			throw new RuntimeException(
					"XML reader was unable to be created based on the input. Please confirm that the message and input is XML.",
					e);
		}

		try {
			// Initialize variables used through-out the XML parsing process.

			// curr: the current element that the xml reader is on.
			XMLEvent curr = null;

			// lastChars: the characters or value of the element.
			String lastChars = "";
			// lastStartTags: element tracking by name.
			ArrayDeque<String> lastStartTags = new ArrayDeque<String>();
			// lastStartTag: the start tag or element name.
			String lastStartTag = "";
			// lastPath: the last fully qualified path.
			String lastPath = "";
			// tagName: the tag name the reader is currently processing.
			String tagName = "";
			
			// processInput: is the reader logic processing the current element.
			boolean processInput = false;

			// Loops through all nodes of the XML document.
			do {
				// If the current element is null, get the next one (first record only)
				if (curr == null) {
					// Gets the next event from the stream (whitespace included)
					curr = xmlReader.nextEvent();
				}

				// Check if cursor is at a Start element
				if (curr.isStartElement()) {
					// Gets the tag name.
					tagName = getTagNameFromStart(curr.asStartElement());
					
					// If tagName matches entryTagName, then a new iteration is starting.
					if (tagName.equals(entryTagName)) {
						// Process from this tag onward.
						processInput = true;

						processEntryTagStart();
					}

					if (processInput) {
						// Push the tag into the start tags ArrayDeque
						lastStartTags.push(tagName);

						// Store the last start node
						lastPath = buildLastPath(lastPath, tagName);

						attributeMap = getAttributesAsMap(curr.asStartElement());
						
						//Processes the attributes.
						processStartElement(lastPath, attributeMap);
					}

				} else if (curr.isEndElement()) {
					// Only look at the end element when we are processing the record
					if (processInput) {
						// Get the tag name of the end element
						tagName = getTagNameFromEnd(curr.asEndElement());
						
						if (tagName.equals(entryTagName)) {
							// If the tag name equals the processing node.
							processEntryTagEnd();
							
							processInput = false;

							lastStartTag = lastStartTags.pop();
							lastPath = removeLastStartTagFromLastPath(lastPath, lastStartTag);

						} else if (tagName.equals(lastStartTags.peek())) {
							// If we are in the element that we are looking for
							// Pop the last start tag name
							lastStartTag = lastStartTags.pop();

							processEndElement(lastPath, lastChars);
							
							lastPath = removeLastStartTagFromLastPath(lastPath, lastStartTag);

							// Reset values
							lastStartTag = "";
							lastChars = "";
						}
					}

				} else if (curr.isCharacters()) {// Check if the node is characters
					// If whitespace, skip
					if (curr.asCharacters().isWhiteSpace()) {
						// Do nothing (skip)

						// If CDATA or ignorable whitespace, skip
					} else if (curr.asCharacters().isIgnorableWhiteSpace() || curr.asCharacters().isCData()) {
						// Do nothing (skip)

						// Otherwise, store the last data value Process Chars
					} else {
						if (processInput) {
							// xmlText = curr.asCharacters().getData();
							// lastChars = xmlText;
							lastChars = curr.asCharacters().getData();
						}
					}
				}

				// Gets next event from the stream (whitespace included)
				curr = xmlReader.nextEvent();

				// End of loop - keeps going until curr is the end of the document
			} while (!curr.isEndDocument());
			// Sets the custom mediation context properties.
			setCustomMediationContextProperties();

			// End try
		} catch (XMLStreamException e) {
			// Throw this error if a problem happens while looping through the records
			throw new RuntimeException("XML reader had a problem reading the nextEvent", e);
		}

	}

	/**
	 * Helper function to build and concatenate the current path with the in path.
	 * 
	 * @param currentPath - Current element path in the XML document.
	 * @param addTag - Element path to add to the overall path.
	 * @return
	 * Blank if either parameter is null
	 * addTag if currentPath is empty
	 * currentPath if currentPath already ends with addTag
	 * else a concatenation of {currentPath}/{addTag}. 
	 */
	private String buildLastPath(String currentPath, String addTag) {
		if (addTag == null || currentPath == null) {
			return "";
		}

		if (currentPath.equals("")) {
			return addTag;
		} else if (currentPath.endsWith(addTag)) {
			return currentPath;
		} else {
			return currentPath + "/" + addTag;
		}
	}

	
	/**
	 * Helper method to remove the last start tag from the last path variable.
	 * 
	 * @param currentPath - Current element path in the XML document.
	 * @param startTag - 
	 * @return
	 * Blank if either parameter is null or parameters equal each other
	 * Removes startTag from currentPath including the trailing /
	 */
	private String removeLastStartTagFromLastPath(String currentPath, String startTag) {
		if (currentPath == null || startTag == null) {
			return "";
		}

		if (currentPath.equals(startTag)) {
			return "";
		} else if (currentPath.endsWith(startTag)) {
			int index = currentPath.lastIndexOf(startTag);

			return currentPath.substring(0, index - 1);
		} else {
			return currentPath;
		}
	}


	/**
	 * Helper method to get the tag name from an end element
	 * 
	 * @param end
	 * @return
	 */
	private String getTagNameFromEnd(EndElement end) {
		if (end.getName().getPrefix() != "") {
			return end.getName().getPrefix() + ":" + end.getName().getLocalPart();
		}

		return end.getName().getLocalPart();
	}

	private HashMap<String, String> getAttributesAsMap(StartElement start) {
		HashMap<String, String> tempMap = new HashMap<String, String>();

		@SuppressWarnings("unchecked")
		Iterator<javax.xml.stream.events.Attribute> attrIter = start.getAttributes();

		while (attrIter.hasNext()) {
			javax.xml.stream.events.Attribute currAttr = attrIter.next();

			tempMap.put(currAttr.getName().getLocalPart(), currAttr.getValue());
		}

		return tempMap;
	}

	
	/**
	 * Helper method to get the tag name from a start element
	 * 
	 * @param start
	 * @return
	 */
	private String getTagNameFromStart(StartElement start) {
		if (start.getName().getPrefix() != "") {
			return start.getName().getPrefix() + ":" + start.getName().getLocalPart();
		}

		return start.getName().getLocalPart();
	}

	// Convert String to Int
	public int stringToInt(String text) {
		try {
			return Integer.parseInt(text);
		} catch (Exception ex) {
			return 0;
		}
	}

	// Convert String to Boolean
	public Boolean stringToBoolean(String text) {
		try {
			if (text.toUpperCase().contains("TRUE") || text.toUpperCase().contains("1")) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * 
	 */
	public abstract String getEntryTagName();

	/**
	 * Gets Mediation Context and any properties or other values which are required
	 * for processing custom records.
	 */
	public abstract void getCustomMediationContextProperties();

	/**
	 * Sets custom Mediation Context properties and values according to
	 * requirements.
	 * 
	 * This is run at the end of processing the XML document to ensure values are
	 * available for downstream Studio components.
	 */
	public abstract void setCustomMediationContextProperties();

	public abstract void processEntryTagStart();
	public abstract void processEntryTagEnd();
	public abstract void processStartElement(String fullPath,  HashMap<String, String> attributeMap);
	public abstract void processEndElement(String fullPath, String value);

}
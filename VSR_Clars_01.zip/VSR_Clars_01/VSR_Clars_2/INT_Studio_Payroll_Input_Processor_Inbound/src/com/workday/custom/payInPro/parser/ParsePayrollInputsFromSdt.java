package com.workday.custom.payInPro.parser;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
import com.workday.custom.payInPro.dto.CustomDateTypes;
import com.workday.custom.payInPro.dto.PayGroupDTO;
import com.workday.custom.payInPro.dto.ReferenceDTO;
import com.workday.custom.payInPro.dto.WorkerDTO;

import workday.com.bsvc.DeductionAllObjectType;
import workday.com.bsvc.EarningAllObjectType;
import workday.com.bsvc.MatchExistingRecordObjectType;
import workday.com.bsvc.PayrollInputProcessorRequestType;
import workday.com.bsvc.PositionElementObjectIDType;
import workday.com.bsvc.PositionElementObjectType;
import workday.com.bsvc.RunCategoryObjectType;
import workday.com.bsvc.SubmitPayrollInputDataType;
import workday.com.bsvc.WorkerObjectIDType;
import workday.com.bsvc.WorkerObjectType;
import workday.com.logmessages.LogMessageType;
import workday.com.logmessages.LogMessagesType;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.ListIterator;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(name = "ParsePayrollInputsFromSdt", type = mediation, toolTip = "", scope = "prototype", smallIconPath = "icons/ParsePayrollInputsFromSdt_16.png", largeIconPath = "icons/ParsePayrollInputsFromSdt_24.png")
public class ParsePayrollInputsFromSdt {
	public MediationContext ctx;
	private ArrayList<LogMessageType> logMessageList;
	
	
	/**
	 * This method is called by the Assembly framework.
	 *
	 * Use the <code>MediationContext</code> to access objects in the context, such
	 * as the message, properties and variables e.g.
	 * <ul>
	 * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
	 * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
	 * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
	 * </ul>
	 */
	@ComponentMethod
	public void process(com.capeclear.mediation.MediationContext arg0) {
		// Must be first in this method to instantiate the current Mediation Context.
		ctx = MediationTube.getCurrentMediationContext();

		getCustomMediationContextProperties();

		logMessageList = new ArrayList<LogMessageType>();
		
		ListIterator<SubmitPayrollInputDataType> iterPayInputData = payInputReq.getPayrollInputData().listIterator();
		
		Boolean isForcePrimaryPosition_Batch = payInputReq.isForcePrimaryPositionWhenEmpty() == null ? false
				: payInputReq.isForcePrimaryPositionWhenEmpty();
		Boolean isMinimizeSubPeriod_Batch = payInputReq.isMinimizeSubPeriodForTerminatedWorkers() == null ? false
				: payInputReq.isMinimizeSubPeriodForTerminatedWorkers();
		String defaultBatchId = payInputReq.getDefaultBatchID();

		while (iterPayInputData.hasNext()) {
			Boolean hasErrors = false;
			WorkerDTO customWorkerDto;

			SubmitPayrollInputDataType payInputData = iterPayInputData.next();

			String originalRecordNbr = payInputData.getOriginRecordNbr();
			String recordNumber = (originalRecordNbr == null) ? String.valueOf(iterPayInputData.previousIndex())
					: originalRecordNbr;

			try {

				String inputId = (payInputData.getPayrollInputID() != null) ? payInputData.getPayrollInputID()
						: ((originalRecordNbr == null) ? null : (defaultBatchId + "_" + originalRecordNbr));

				payInputData.setPayrollInputID(inputId);
				
				if (payInputData.getWorkerReference() == null) {
					hasErrors = true;
					addLogMessage("error", "No worker reference found on pay input", null, payInputData.getPayrollInputID(),
							"ParsePayrollInputsFromSdt", recordNumber, null, null, null, null, null);
				} else {
					//Basics used for logging
					String workerType = payInputData.getWorkerReference().getID().getType();
					String workerId = payInputData.getWorkerReference().getID().getValue();
					String payComponentType = (payInputData.getEarningReference() == null) ? payInputData.getDeductionReference().getID().getType() : payInputData.getEarningReference().getID().getType();
					String payComponentId = (payInputData.getEarningReference() == null) ? payInputData.getDeductionReference().getID().getValue() : payInputData.getEarningReference().getID().getValue();
					
					String workerKey = workerType + "|" + workerId;

					if (!workerHash.containsKey(workerKey)) {
						hasErrors = true;
						addLogMessage("error", String.format("Worker with [%1$s] [%2$s] not found in the tenant.",workerType, workerId), null, payInputData.getPayrollInputID(),
								"ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
					} else {
						customWorkerDto = workerHash.get(workerKey);

						// Run Category is required when any of the following enrichment elements are
						// used
						// Start Date Lookup, End Date Lookup or Match Existing End Date Lookup
						String startDateLookup = payInputData.getStartDateLookup();
						String endDateLookup = payInputData.getEndDateLookup();
						MatchExistingRecordObjectType matchExistingObj = payInputData.getMatchExistingRecord();
						String matchExistingEndDateLookup = (matchExistingObj == null) ? null
								: matchExistingObj.getEndDateLookup();

						RunCategoryObjectType runCategoryRef = payInputData.getRunCategoryReference();
						String runCategoryType = (runCategoryRef == null) ? null : runCategoryRef.getID().getType();
						String runCategoryId = (runCategoryRef == null) ? null : runCategoryRef.getID().getValue();

						ReferenceDTO payGroupRef = customWorkerDto.getPayGroupReference();
						String payGroupType = (payGroupRef == null) ? null : payGroupRef.getType();
						String payGroupId = (payGroupRef == null) ? null : payGroupRef.getID();

						String payGroupKey = (runCategoryType == null || payGroupType == null) ? ""
								: (payGroupType + "|" + payGroupId + "|" + runCategoryType + "|" + runCategoryId);
						PayGroupDTO payGroup = payGroupHash.get(payGroupKey);

						// Enrichment: Start Date Lookup
						if (startDateLookup != null && !startDateLookup.equalsIgnoreCase(CustomDateTypes.Default.toString())) {
							if (runCategoryType == null || payGroupType == null || payGroup == null) {
								hasErrors = true;
								addLogMessage("error", "Unable to perform Start Date Lookup",
										String.format("Prerequisite data was not found. Please confirm the tenant has a period containing run category ([%1$s]) and pay group ([%2$s]).",runCategoryType,payGroupType),
										payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
							} else {
								XMLGregorianCalendar tmpCal = createXmlGregorianCalendar(
										payGroup.getDateByType(startDateLookup).toString(),recordNumber, workerType, workerId, payComponentType, payComponentId);
								
								if (tmpCal == null) {
									hasErrors = true;
								} else {
									payInputData.setStartDate(tmpCal);
								}
							}
						}

						// Enrichment: End Date Lookup
						if (endDateLookup != null && !endDateLookup.equalsIgnoreCase(CustomDateTypes.Default.toString())) {
							if (runCategoryType == null || payGroupType == null || payGroup == null) {
								hasErrors = true;
								addLogMessage("error", "Unable to perform End Date Lookup",
										String.format("Prerequisite data was not found. Please confirm the tenant has a period containing run category ([%1$s]) and pay group ([%2$s]).",runCategoryType,payGroupType),
										payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
							} else {
								XMLGregorianCalendar tmpCal = createXmlGregorianCalendar(
										payGroup.getDateByType(endDateLookup).toString(),recordNumber, workerType, workerId, payComponentType, payComponentId);
								
								if (tmpCal == null) {
									hasErrors = true;
								} else {
									payInputData.setEndDate(tmpCal);
								}
							}
						}
						
						// Enrichment: Match Existing End Date Lookup
						if (matchExistingEndDateLookup != null && !matchExistingEndDateLookup.equalsIgnoreCase(CustomDateTypes.Default.toString())) {
							if (runCategoryType == null || payGroupType == null || payGroup == null) {
								hasErrors = true;
								addLogMessage("error",
										"Unable to perform Match Existing End Date Lookup",
										"Prerequisite data was not found. Please confirm pay input has run category and the worker data has the pay group.",
										payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
							} else {
								XMLGregorianCalendar tmpCal = createXmlGregorianCalendar(
										payGroup.getDateByType(matchExistingEndDateLookup).toString(),recordNumber, workerType, workerId, payComponentType, payComponentId);
								
								if (tmpCal == null) {
									hasErrors = true;
								} else {
									matchExistingObj.setEndDate(tmpCal);
									payInputData.setMatchExistingRecord(matchExistingObj);	
								}
							}
						}
						
						if (matchExistingObj != null) {
							if (matchExistingObj.isMatchOnWorktags() != null && matchExistingObj.isMatchOnWorktags() == true) {
								hasErrors = true;
								addLogMessage("error",
										"Match On Worktags is not yet supported",
										"The feature 'Match On Worktags' is not code-complete and therefore, not supported. If worktag matching is required, custom build work will be necessary in the Source Data Transformation.",
										payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
							}
							
							if (matchExistingObj.isEndAllMatches() != null && matchExistingObj.isEndAllMatches() == true) {
								if (matchExistingObj.getMatchMultipleExistLogLevel() != null && !matchExistingObj.getMatchMultipleExistLogLevel().equalsIgnoreCase("ignore") && !matchExistingObj.getMatchMultipleExistLogLevel().equalsIgnoreCase("info")) {
									hasErrors = true;
									addLogMessage("error",
											"Incorrect configuration of Match_Existing_Records",
											String.format("If you want to End_All_Match, log level when matching multiple records must be 'ignore' or 'info'. Record's log level was [%1$s].  Please correct in XML from the source integration.",matchExistingObj.getMatchMultipleExistLogLevel()),
											payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
								}
							}
						
							if (payInputData.getMatchExistingRecord().getEndDate() != null && (payInputData.getMatchExistingRecord().isEndOnly() == null || payInputData.getMatchExistingRecord().isEndOnly() == false)) {
								LocalDate matchExistingEndDate = LocalDate.of(payInputData.getMatchExistingRecord().getEndDate().getYear(), payInputData.getMatchExistingRecord().getEndDate().getMonth(), payInputData.getMatchExistingRecord().getEndDate().getDay());
								LocalDate newRecordStart = LocalDate.of(payInputData.getStartDate().getYear(), payInputData.getStartDate().getMonth(), payInputData.getStartDate().getDay());
								
								if (!newRecordStart.isAfter(matchExistingEndDate)) {
									hasErrors = true;
									
									addLogMessage("error",
											"Incorrect configuration of Match_Existing_Records",
											String.format("Payroll Input Processor does not support ending AND updating in a single payroll input record where the Start Date ([%1$s]) is after the Match Existing Record End Date ([%2$s]). If you want dates to overlap, please create two records. The first record should End_Only existing records and the second would be to create the new input without the Match_Existing_Records element.",newRecordStart.toString(),matchExistingEndDate.toString()),
											payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
								}
							}
							
						}
						
						// Enrichment: SSN Lookup
						if (workerType.equals("SSN")) {
							WorkerObjectType workerObj = new WorkerObjectType();
							WorkerObjectIDType workerIdObj = new WorkerObjectIDType();

							// Because Worker Object found and SSN look is requested,
							// update the workerType/Id/Key
							ReferenceDTO customWorkerRef = customWorkerDto.getWorkerReference();
							if (customWorkerRef == null) {
								hasErrors = true;
								addLogMessage("error", "Unable to perform SSN Worker Lookup",
										"The worker data hashed does not contain a worker element.", payInputData.getPayrollInputID(),
										"ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
							} else {
								workerType = customWorkerDto.getWorkerReference().getType();
								workerId = customWorkerDto.getWorkerReference().getID();
								workerKey = workerType + "|" + workerId;

								// Now update the pay input data
								workerIdObj.setType(workerType);
								workerIdObj.setValue(workerId);
								workerObj.setID(workerIdObj);

								payInputData.setWorkerReference(workerObj);
							}

						}

						// Enrichment: Force Primary Position
						if (payInputData.getPositionReference() == null && isForcePrimaryPosition_Batch) {
							ReferenceDTO posRef = customWorkerDto.getPrimaryPositionReference();

							if (posRef == null || posRef.getID().isEmpty() || posRef.getType().isEmpty()) {
								hasErrors = true;
								addLogMessage("error", "Unable to Set Primary Position",
										"The worker data hashed does not contain a primary position element.",
										payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
							} else {
								PositionElementObjectType positionObj = new PositionElementObjectType();
								PositionElementObjectIDType positionIdObj = new PositionElementObjectIDType();

								positionIdObj.setType(posRef.getType());
								positionIdObj.setValue(posRef.getID());
								positionObj.setID(positionIdObj);

								payInputData.setPositionReference(positionObj);
							}
						}

						if (customWorkerDto.getTerminated() && isMinimizeSubPeriod_Batch) {
							
							XMLGregorianCalendar termDateCal;
							
							if (customWorkerDto.getTerminationDate() == null) {
								hasErrors = true;
								addLogMessage("error", "Unable to Minimize Sub Period",
										"The worker data hashed does not contain a termination date.", payInputData.getPayrollInputID(),
										"ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);

							} else {
								termDateCal = createXmlGregorianCalendar(
										customWorkerDto.getTerminationDate().toString(), recordNumber, workerType, workerId, payComponentType, payComponentId);

								if (payInputData.getEndDate() == null) {
									payInputData.setEndDate(termDateCal);
								} else {
									if (termDateCal == null) {
										hasErrors = true;
									} else {
										LocalDate existingEndDate, existingStartDate;
										existingEndDate = (payInputData.getEndDate() == null) ? null : LocalDate.of(payInputData.getEndDate().getYear(), payInputData.getEndDate().getMonth(), payInputData.getEndDate().getDay());
										existingStartDate = (payInputData.getStartDate() == null) ? null : LocalDate.of(payInputData.getStartDate().getYear(), payInputData.getStartDate().getMonth(), payInputData.getStartDate().getDay());
										
										//Termination date must be between the Start and End Dates
										if (existingStartDate.isAfter(customWorkerDto.getTerminationDate())) {
											addLogMessage("warn", "Unable to Minimize Sub Period",
													String.format("Termination Date [%1$s] is before the current Start Date [%2$s]. The End Date was not changed.",termDateCal.toString(), payInputData.getStartDate().toString()),
													payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
										} else if (existingEndDate == null) {
											payInputData.setEndDate(termDateCal);
										} else if (existingEndDate.isBefore(customWorkerDto.getTerminationDate())) {
											addLogMessage("warn", "Unable to Minimize Sub Period",
													String.format("Termination Date [%1$s] is after the current End Date [%2$s]. The End Date was not changed.",termDateCal.toString(), payInputData.getEndDate().toString()),
													payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
										} else {
											payInputData.setEndDate(termDateCal);
										}
									}
								}
							}
						}

						// Do not add the earning/deduction for lookup if there is no request for matching existing or if the record is already in error.
						if (matchExistingObj != null && !hasErrors) {
							EarningAllObjectType earningRef = payInputData.getEarningReference();
							DeductionAllObjectType deductionRef = payInputData.getDeductionReference();
							String key, keyLookupList;

							// Set workers to lookup in existing Pay Input RaaS
							key = "<wd:ID wd:type='" + workerType + "'>" + workerId + "</wd:ID>";
							if (!workerLookupList.contains(key)) {
								workerLookupList.add(key);
							}
							
							// Set earliest date to use in existing Pay Input RaaS
							if (payInputData.getStartDate() != null) {
								LocalDate tmpDate = LocalDate.of(payInputData.getStartDate().getYear(), payInputData.getStartDate().getMonth(), payInputData.getStartDate().getDay());
								
								if (earliestStartDate.isEmpty()) {
									earliestStartDate = tmpDate.toString();	
								} else {
									LocalDate earlyStartDate = LocalDate.parse(earliestStartDate, DateTimeFormatter.ISO_DATE);
									
									if (earlyStartDate.isAfter(tmpDate)) {
										earliestStartDate = tmpDate.toString();
									}
								}
							};
							
							// Set earnings to lookup in existing Pay Input RaaS
							if (earningRef != null) {
								String earningType = earningRef.getID().getType();
								String earningId = earningRef.getID().getValue();

								key = earningType + "|" + earningId;
								keyLookupList = "<wd:ID wd:type='" + earningType + "'>" + earningId + "</wd:ID>";
								if (payCompList.contains(key) && !earningLookupList.contains(keyLookupList)) {
									earningLookupList.add(keyLookupList);
								}
							}

							// Set deductions to lookup in existing Pay Input RaaS
							if (deductionRef != null) {
								String deductionType = deductionRef.getID().getType();
								String deductionId = deductionRef.getID().getValue();

								key = deductionType + "|" + deductionId;
								keyLookupList = "<wd:ID wd:type='" + deductionType + "'>" + deductionId + "</wd:ID>";
								if (payCompList.contains(key) && !deductionLookupList.contains(keyLookupList)) {
									deductionLookupList.add(keyLookupList);
								}
							}
						}
					}					
				}
				
				// Record has been enriched, make sure it is set.
				if (hasErrors) {
					iterPayInputData.remove();
				} else {
					iterPayInputData.set(payInputData);
				}
				
			} catch (Exception e) {
				addLogMessage("error", "Unhandled error in ParsePayrolLInputsFromSdt", e.toString(),
						payInputData.getPayrollInputID(), "ParsePayrollInputsFromSdt", recordNumber, null, null, null, null, org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(e));

			}
		}
		
		setCustomMediationContextProperties();

	}

	private void addLogMessage(String inLogLevel, String inMessage, String inMessageDetail, String inReferenceID, String inLocalIn, String inRecordNumber, String inWorkerType, String inWorkerId, String inPayComponentType, String inPayComponentID, String inSupportData) {
		LogMessageType lm = new LogMessageType();
		
		XMLGregorianCalendar tmpXmlCal = null;
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTimeInMillis(System.currentTimeMillis());
		try {
			tmpXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		lm.setTimestamp(tmpXmlCal);
		lm.setLogLevel(inLogLevel);
		lm.setMessage(inMessage);
		lm.setMessageDetail(inMessageDetail);
		lm.setRecordNumber(inRecordNumber);
		lm.setReferenceID(inReferenceID);
		lm.setSupportData(inSupportData);
		lm.setLocalIn(inLocalIn);
		lm.setWorkerID(inWorkerId);
		lm.setWorkerType(inWorkerType);
		lm.setPayComponentID(inPayComponentID);
		lm.setPayComponentType(inPayComponentType);
		
		logMessageList.add(lm);
	}

	private XMLGregorianCalendar createXmlGregorianCalendar(String value, String recordNumber, String inWorkerType, String inWorkerId, String inPayComponentType, String inPayComponentID) {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date;
		XMLGregorianCalendar tmpXmlCal = null;

		try {
			date = format.parse(value);

			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);

			tmpXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			addLogMessage("error",
					e.toString(),
					e.getMessage(),
					null, "ParsePayrollInputsFromSdt", recordNumber, inWorkerType, inWorkerId, inPayComponentType, inPayComponentID, org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(e));
			return null;
		} catch (ParseException e) {
			addLogMessage("error",
					e.toString(),
					e.getMessage(),
					null, "ParsePayrollInputsFromSdt", recordNumber, inWorkerType, inWorkerId, inPayComponentType, inPayComponentID, org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(e));
			return null;
		}

		return tmpXmlCal;

	}

	private final String payInputReq_prop = "globalPayInputs_Inbound";
	private PayrollInputProcessorRequestType payInputReq;

	private final String workerHash_prop = "global_hash_worker";
	private HashMap<String, WorkerDTO> workerHash;

	private String payCompList_prop = "globalListPayComponents";
	private ArrayList<String> payCompList;
	
	private String earningLookupList_prop = "globalListLookupEarnings";
	private ArrayList<String> earningLookupList;
	
	private String deductionLookupList_prop = "globalListLookupDeductions";
	private ArrayList<String> deductionLookupList;

	private String workerLookupList_prop = "global_list_lookup_workers";
	private ArrayList<String> workerLookupList;

	private String payGroupHash_prop = "global_hash_pay_groups";
	private HashMap<String, PayGroupDTO> payGroupHash;

	private String logMessages_prop = "global_list_log_messages";
	private LogMessagesType logMessages;
	
	private String earliestStartDate_prop = "globalEarliestStartDate";
	private String earliestStartDate;

	@SuppressWarnings("unchecked")
	public void getCustomMediationContextProperties() {
		earliestStartDate = "";
		
		Object tmpPayInputReq;
		tmpPayInputReq = ctx.getProperty(payInputReq_prop);
		if (tmpPayInputReq == null) {
			payInputReq = null;
		} else {
			payInputReq = (PayrollInputProcessorRequestType) tmpPayInputReq;
		}

		Object tmpWorkerHash;
		tmpWorkerHash = ctx.getProperty(workerHash_prop);
		if (tmpWorkerHash == null) {
			workerHash = new HashMap<String, WorkerDTO>();
		} else {
			workerHash = (HashMap<String, WorkerDTO>) tmpWorkerHash;
		}

		Object tmpPayGroupHash;
		tmpPayGroupHash = ctx.getProperty(payGroupHash_prop);
		if (tmpPayGroupHash == null) {
			payGroupHash = new HashMap<String, PayGroupDTO>();
		} else {
			payGroupHash = (HashMap<String, PayGroupDTO>) tmpPayGroupHash;
		}

		Object tmpPayCompList;
		tmpPayCompList = ctx.getProperty(payCompList_prop);
		if (tmpPayCompList == null) {
			payCompList = new ArrayList<String>();
		} else {
			payCompList = (ArrayList<String>) tmpPayCompList;
		}
		
		Object tmpEarningList;
		tmpEarningList = ctx.getProperty(earningLookupList_prop);
		if (tmpEarningList == null) {
			earningLookupList = new ArrayList<String>();
		} else {
			earningLookupList = (ArrayList<String>) tmpEarningList;
		}
		
		Object tmpDeductionList;
		tmpDeductionList = ctx.getProperty(deductionLookupList_prop);
		if (tmpDeductionList == null) {
			deductionLookupList = new ArrayList<String>();
		} else {
			deductionLookupList = (ArrayList<String>) tmpDeductionList;
		}

		Object tmpWorkerList;
		tmpWorkerList = ctx.getProperty(workerLookupList_prop);
		if (tmpWorkerList == null) {
			workerLookupList = new ArrayList<String>();
		} else {
			workerLookupList = (ArrayList<String>) tmpWorkerList;
		}
	}

	public void setCustomMediationContextProperties() {
		logMessages = new LogMessagesType();
		logMessages.setLogMessage(logMessageList);
		
		if (earliestStartDate.isEmpty()) {
			//Set an earliest Start Date for looking up existing inputs when no valid start dates are found from Source Transformation.
			earliestStartDate = LocalDate.now().toString();
		}
		
		// Sets the HashMap of stored custom data.
		ctx.setProperty(payInputReq_prop, payInputReq);
		ctx.setProperty(workerLookupList_prop, workerLookupList);
		ctx.setProperty(earningLookupList_prop, earningLookupList);
		ctx.setProperty(deductionLookupList_prop, deductionLookupList);
		ctx.setProperty(logMessages_prop, logMessages);
		ctx.setProperty(earliestStartDate_prop, earliestStartDate);
		
		//ctx.setMessage(ctx.getMessage());
	}
}

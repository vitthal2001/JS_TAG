package com.workday.custom.payInPro.dto;

public enum CustomLogLevelTypes {
	ignore,
	debug,
	info,
	warn,
	error,
	fatal
}
/*	
 * The schema defined by this Studio has the same root element as the Import_Payroll_Input and Get_Submit_Payroll_Input web services.
 * However, the custom schema has additional elements and attributes.
 * This class is used to parse a generic payroll input object including the custom elements and attributes.
 */

package com.workday.custom.payInPro.parser;

import com.capeclear.assembly.annotation.Component;
import com.workday.custom.payInPro.dto.ReferenceDTO;
import com.workday.custom.payInPro.dto.WorkerDTO;

import static com.capeclear.assembly.annotation.Component.Type.*;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(name = "ParsePayrollInput", type = mediation, toolTip = "", scope = "prototype", smallIconPath = "icons/ParsePayrollInput_16.png", largeIconPath = "icons/ParsePayrollInput_24.png")
public class ParseDISWorker extends ParseMessageXML {

	private final String entryTagName = "tdf:workerData";
	
	private final String workerIdElementPath = entryTagName + "/tdf:refId";
	private final String workerTypeElementPath = entryTagName + "/tdf:refType";
	private final String ssnElementPath = entryTagName + "/tdf:SSN";
	private final String isTerminatedElementPath = entryTagName + "/tdf:Terminated";
	private final String terminationDateElementPath = entryTagName + "/tdf:TerminationDate";
	
	private final String payGroupElementPath = entryTagName + "/tdf:PayGroup";
	private final String payGroupRefIdElementPath = payGroupElementPath + "/tdf:Organization_Reference_ID";
	
	private final String positionElementPath = entryTagName + "/tdf:PrimaryPosition";
	private final String positionRefIdElementPath = positionElementPath + "/tdf:refId";
	private final String positionRefTypeElementPath = positionElementPath + "/tdf:refType";

	private WorkerDTO worker;
	private String workerId;
	private String workerType;
	private String posId;
	private String posType;
	
	//private WorktagDTO worktags;
	//private AdditionalInputDetailDTO additionalDetail;

	@Override
	public String getEntryTagName() {
		return entryTagName;
	}

	@Override
	public void processEntryTagStart() {
		worker = new WorkerDTO();
		
		workerId = "";
		workerType = "";
		posId = "";
		posType = "";
	}

	@Override
	public void processEntryTagEnd() {
		worker.setWorkerReference(new ReferenceDTO(workerType, workerId));
		worker.setPrimaryPositionReference(new ReferenceDTO(posType,posId));
		
		processCustomData(worker);
	}

	@Override
	public void processStartElement(String fullPath, HashMap<String, String> attributeMap) {
		switch (fullPath) {
		
		default:
			/* Processes additional values as defined via field overrides. */
			break;

		}
	}

	
	
	@Override
	public void processEndElement(String fullPath, String value) {
		
		switch (fullPath) {
		
		case workerIdElementPath:
			workerId = value;
			break;

		case workerTypeElementPath:
			workerType = value;
			break;
			
		case ssnElementPath:
			worker.setSSN(value);
			break;
			
		case isTerminatedElementPath:
			worker.setTerminated(stringToBoolean(value));
			break;
			
		case terminationDateElementPath:
			worker.setTerminationDate(value, DateTimeFormatter.ISO_DATE);
			break;
			
		case payGroupRefIdElementPath:
			worker.setPayGroupReference(new ReferenceDTO("Organization_Reference_ID", value));
			break;
			
		case positionRefIdElementPath:
			posId = value;
			break;
		
		case positionRefTypeElementPath:
			posType = value;
			break;
			
		default:
			/* Processes additional values as defined via field overrides. */
			break;

		}
	}

	private String hashWorkerPropertyName = "global_hash_worker";
	private HashMap<String, WorkerDTO> hashWorkers;
	
	@SuppressWarnings("unchecked")
	@Override
	public void getCustomMediationContextProperties() {
		Object tmpWorkerHash;
		tmpWorkerHash = ctx.getProperty(hashWorkerPropertyName);
		if (tmpWorkerHash == null) {
			hashWorkers =  new HashMap<String, WorkerDTO>();
		} else {
			hashWorkers = (HashMap<String, WorkerDTO>) tmpWorkerHash;
		}	
		
	}

	@Override
	public void setCustomMediationContextProperties() {
		//Sets the HashMap of stored custom data.
		ctx.setProperty(hashWorkerPropertyName, hashWorkers);
	}

	public void processCustomData(WorkerDTO worker) {
		String key = "";
		
		
		if (worker.getWorkerReference() != null) {
			key = worker.getWorkerReference().asHashKey();
			
			hashWorkers.put(key, worker);
		}
				
		//Add By SSN if not Blank
		if (worker.getSSN() != null && !worker.getSSN().isEmpty()) {
			key = "SSN|" + worker.getSSN();
			
			hashWorkers.put(key, worker);
		}

	}
}
package com.workday.custom.payInPro.dto;

public class ReferenceDTO {
	private String _type;
	private String _id;
	
	public ReferenceDTO() {
	}
	
	public ReferenceDTO(String type, String id) {
		this._type = type;
		this._id = id;
	}
	
	public String getType() {
		return this._type;
	}
	
	public void setType(String type) {
		this._type = type;
	}
	
	public String getID() {
		return this._id;
	}
	
	public void setID(String id) {
		this._id = id;
	}
	
	public String asHashKey() {
		String tmpType = "";
		String tmpId = "";
		
		if (this.getType() != null) { tmpType = this.getType();	}
		if (this.getID() != null) { tmpId = this.getID();	}
		
		return tmpType + "|" + tmpId;
	}
	
	public boolean isEmpty() {
		if ((this.getType() == null || this.getType() == "") &&
			(this.getID() == null || this.getID() == "")) {
			return true;
		} else {
			return false;
		}
	}
	
	public Object clone() {
		ReferenceDTO dtoClone = new ReferenceDTO();
		
		dtoClone.setType(this._type);
		dtoClone.setID(this._id);
		return dtoClone;
	}
}

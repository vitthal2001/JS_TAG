package com.workday.custom.payInPro.dto;

public enum CustomDateTypes {
	Default,
	Prior_Period_Start,
	Prior_Period_End,
	Prior_Period_Payment,
	Current_Period_Start,
	Current_Period_End,
	Current_Period_Payment,
	Next_Period_Start,
	Next_Period_End,
	Next_Period_Payment
}
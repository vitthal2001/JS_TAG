/*	
 * The schema defined by this Studio has the same root element as the Import_Payroll_Input and Get_Submit_Payroll_Input web services.
 * However, the custom schema has additional elements and attributes.
 * This class is used to parse a generic payroll input object including the custom elements and attributes.
 */

package com.workday.custom.payInPro.parser;

import com.capeclear.assembly.annotation.Component;
import com.workday.custom.payInPro.dto.PayGroupDTO;
import com.workday.custom.payInPro.dto.ReferenceDTO;

import static com.capeclear.assembly.annotation.Component.Type.*;
import java.util.HashMap;

/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(name = "ParseDISPayGroup", type = mediation, toolTip = "", scope = "prototype", smallIconPath = "icons/ParseDISPayGroup_16.png", largeIconPath = "icons/ParseDISPayGroup_24.png")
public class ParseDISPayGroup extends ParseMessageXML {

	private final String entryTagName = "tdf:payGroupData";
	
	private final String refIdElementPath = entryTagName + "/tdf:refId";
	private final String refTypeElementPath = entryTagName + "/tdf:refType";
	
	private final String payGroupDetailElementPath = entryTagName + "/tdf:PayGroupDetail";
	
	private final String runCategoryElementPath = payGroupDetailElementPath + "/tdf:RunCategory";
	private final String runCategoryRefIdElementPath = runCategoryElementPath + "/tdf:Run_Category_ID";
	private final String lastPeriodElementPath = payGroupDetailElementPath + "/tdf:LastPeriod";
	private final String currentPeriodElementPath = payGroupDetailElementPath + "/tdf:CurrentPeriod";
	private final String nextPeriodElementPath = payGroupDetailElementPath + "/tdf:NextPeriod";
	
	private final String lastStartDateElementPath = lastPeriodElementPath + "/tdf:StartDate";
	private final String lastEndDateElementPath = lastPeriodElementPath + "/tdf:EndDate";
	private final String lastPaymentDateElementPath = lastPeriodElementPath + "/tdf:PaymentDate";
	
	private final String currentStartDateElementPath = currentPeriodElementPath + "/tdf:StartDate";
	private final String currentEndDateElementPath = currentPeriodElementPath + "/tdf:EndDate";
	private final String currentPaymentDateElementPath = currentPeriodElementPath + "/tdf:PaymentDate";
	
	private final String nextStartDateElementPath = nextPeriodElementPath + "/tdf:StartDate";
	private final String nextEndDateElementPath = nextPeriodElementPath + "/tdf:EndDate";
	private final String nextPaymentDateElementPath = nextPeriodElementPath + "/tdf:PaymentDate";
	
	private String payGroupRefId, payGroupRefType, runCategoryRefId;
	private PayGroupDTO period;
	
	@Override
	public String getEntryTagName() {
		return entryTagName;
	}

	@Override
	public void processEntryTagStart() {
		payGroupRefId = "";
		payGroupRefType = "";
		runCategoryRefId = "";
		
		period = new PayGroupDTO();
	}

	@Override
	public void processEntryTagEnd() {
		//Do nothing for this implementation
	}

	@Override
	public void processStartElement(String fullPath, HashMap<String, String> attributeMap) {
		switch (fullPath) {
		
		case payGroupDetailElementPath:
			//Starts a new pay group detail which means we reset all details except those items at the pay group level.
			period = new PayGroupDTO();
			
			runCategoryRefId = "";
			break;
		
		default:
			/* Processes additional values as defined via field overrides. */
			break;

		}
	}
	
	@Override
	public void processEndElement(String fullPath, String value) {
		switch (fullPath) {
		
		case payGroupDetailElementPath:
			period.setPayGroupReference(new ReferenceDTO(payGroupRefType, payGroupRefId));
			period.setRunCategoryReference(new ReferenceDTO("Run_Category_ID", runCategoryRefId));
			
			processCustomData(period);
			break;
			
		case refIdElementPath:
			payGroupRefId = value;
			break;

		case refTypeElementPath:
			payGroupRefType = value;
			break;
		
		case runCategoryRefIdElementPath:
			runCategoryRefId = value;
			break;
			
		case lastStartDateElementPath:
			period.setLastPeriodStartDate(value, java.time.format.DateTimeFormatter.ISO_DATE);
			break;
		case lastEndDateElementPath:
			period.setLastPeriodEndDate(value, java.time.format.DateTimeFormatter.ISO_DATE);
			break;
		case lastPaymentDateElementPath:
			period.setLastPeriodPaymentDate(value, java.time.format.DateTimeFormatter.ISO_DATE);
			break;

		case currentStartDateElementPath:
			period.setCurrentPeriodStartDate(value, java.time.format.DateTimeFormatter.ISO_DATE);
			break;
		case currentEndDateElementPath:
			period.setCurrentPeriodEndDate(value, java.time.format.DateTimeFormatter.ISO_DATE);
			break;
		case currentPaymentDateElementPath:
			period.setCurrentPeriodPaymentDate(value, java.time.format.DateTimeFormatter.ISO_DATE);
			break;

		case nextStartDateElementPath:
			period.setNextPeriodStartDate(value, java.time.format.DateTimeFormatter.ISO_DATE);
			break;
		case nextEndDateElementPath:
			period.setNextPeriodEndDate(value, java.time.format.DateTimeFormatter.ISO_DATE);
			break;
		case nextPaymentDateElementPath:
			period.setNextPeriodPaymentDate(value, java.time.format.DateTimeFormatter.ISO_DATE);
			break;
		default:
			/* Processes additional values as defined via field overrides. */
			break;

		}
	}

	private String hashPayGroupsPropertyName = "global_hash_pay_groups";
	private HashMap<String, PayGroupDTO> hashPayGroups;
	
	@SuppressWarnings("unchecked")
	@Override
	public void getCustomMediationContextProperties() {
		Object tmpPayGroupsHash;
		tmpPayGroupsHash = ctx.getProperty(hashPayGroupsPropertyName);
		if (tmpPayGroupsHash == null) {
			hashPayGroups =  new HashMap<String, PayGroupDTO>();
		} else {
			hashPayGroups = (HashMap<String, PayGroupDTO>) tmpPayGroupsHash;
		}	
	}

	@Override
	public void setCustomMediationContextProperties() {
		//Sets the HashMap of stored custom data.
		ctx.setProperty(hashPayGroupsPropertyName, hashPayGroups);
	}

	public void processCustomData(PayGroupDTO periodProcessed) {
		String key = periodProcessed.getPayGroupReference().getType() + "|" + periodProcessed.getPayGroupReference().getID() + "|" + periodProcessed.getRunCategoryReference().getType() + "|" + periodProcessed.getRunCategoryReference().getID();
		hashPayGroups.put(key, periodProcessed);
	}
}
package com.workday.custom.payInPro;

public class MediationConstants {
	
	public static final String ASSEMBLY_VERSION = "2020.9";

	// Names of Workday Studio built-in properties
	public static final String STUDIO_PROPERTY_TOKEN_USERNAME = "wss.usernametoken.username";
	public static final String STUDIO_PROPERTY_TOKEN_PASSWORD = "wss.usernametoken.password";
	public static final String STUDIO_PROPERTY_TENANT_ID = "cc.customer.id";

	// Names of PayInPro-provided Integration Services
	public static final String ATTRIBUTE_SERVICE_GENERAL = "INT Studio Payroll Input Processor Inbound - Attribute and Map Service - General";
	public static final String REPORT_SERVICE = "INT Studio Payroll Input Processor Inbound - Report Service";
	public static final String DIS_WORKER = "INT Studio Payroll Input Processor Inbound - Data Initialization Service - Worker";
	public static final String DIS_DEDUCTION = "INT Studio Payroll Input Processor Inbound - Data Initialization Service - Deduction";
	public static final String DIS_EARNING = "INT Studio Payroll Input Processor Inbound - Data Initialization Service - Earning";
	public static final String DIS_PAY_GROUP = "INT Studio Payroll Input Processor Inbound - Data Initialization Service - Pay Group";
	
	
	// Names of PayInPro-provided Integration Attributes
	public static final String ATTRIBUTE_DOCUMENT_RETENTION = "Document Retention in Days";
	public static final String ATTRIBUTE_LOG_RETENTION = "Log Retention in Days";
	
	// Names of PayInPro-provided Launch Parameters
	public static final String LAUNCH_PARAMETER_VALIDATION_MODE = "Run in Validation Mode";
	public static final String LAUNCH_PARAMETER_DEBUG_MODE = "Run with Debug Logging";
	public static final String LAUNCH_PARAMETER_SOURCE_EVENT_WID = "Source Integration Event WID";
	public static final String LAUNCH_PARAMETER_INPUT_DOCUMENT_LABEL = "Input Document Label";

	// PayInPro Properties that have meta-level influence on framework behavior
	public static final String PROPERTY_PayInPro_VERSION = "PayInProVersion";
	public static final String PROPERTY_PayInPro_DEDUPLICATOR = "PayInProStringDeduplicator";
	public static final String PROPERTY_PayInPro_DEBUG_TARGET_TYPE_VALIDATION = "PayInProDebugTargetTypeValidation";
	public static final String PROPERTY_PayInPro_DEBUG_TARGET_NAME_VALIDATION = "PayInProDebugTargetNameValidation";
	public static final String PROPERTY_PayInPro_STATIC_ANALYSIS_EXEMPTIONS = "PayInProStaticCodeAnalysisExemptionList";
	public static final String PROPERTY_PayInPro_DEBUG_LIST = "PayInProDebugPropertyList";
	public static final String PROPERTY_PayInPro_DEBUG_ARCHIVE = "PayInProDebugArchiveFilename";

	// PayInPro Properties populated from Launch Parameters
	public static final String PROPERTY_PayInPro_IS_DEBUG_MODE = "PayInProIsDebugMode";
	public static final String PROPERTY_PayInPro_IS_VALIDATION_MODE = "PayInProIsValidationMode";
	public static final String PROPERTY_PayInPro_DEBUG_EVENT_WID = "PayInProDebugWID";
	public static final String PROPERTY_PayInPro_EVENT_WID = "PayInProEventWID";
	
	// PayInPro Properties populated from Integration Attributes
	public static final String PROPERTY_PayInPro_DOCUMENT_RETENTION_PERIOD = "PayInProDocumentRetentionPeriod";
	public static final String PROPERTY_PayInPro_RETRIEVAL_DOCUMENT_TAG = "PayInProRetrievalDocTag";
	public static final String PROPERTY_PayInPro_OUTPUT_FILENAME = "PayInProOutputFilename";
	public static final String PROPERTY_PayInPro_DELIVERY_DOCUMENT_TAG = "PayInProDeliveryDocTag";
	public static final String PROPERTY_PayInPro_QUEUE_ENDPOINT = "PayInProQueueEndpoint";
	public static final String PROPERTY_PayInPro_QUEUE_USERNAME = "PayInProQueueUsername";
	public static final String PROPERTY_PayInPro_QUEUE_PASSWORD = "PayInProQueuePassword";
	public static final String PROPERTY_PayInPro_QUEUE_NAME = "PayInProQueueName";
	
	// PayInPro Properties used globally, but not derived from Attributes or Launch Parameters
	public static final String PROPERTY_GLOBAL_API_VERSION = "globalApiVersion";

	// PayInPro Properties related to Primary Log
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_FILENAME = "PayInProPrimaryLogFilename";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_RETENTION = "PayInProPrimaryLogExpires";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_MAX_SIZE = "PayInProPrimaryLogMaxCountPerFile";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_FORMAT = "PayInProPrimaryLogFileFormat";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_COUNT_BY_FILE = "PayInProPrimaryLogCountByLogFile";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_COUNT_DEBUG = "PayInProPrimaryLogCountDebug";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_COUNT_INFO = "PayInProPrimaryLogCountInfo";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_COUNT_WARN = "PayInProPrimaryLogCountWarn";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_COUNT_ERROR = "PayInProPrimaryLogCountError";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_COUNT_FATAL = "PayInProPrimaryLogCountFatal";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_COUNT_TOTAL = "PayInProPrimaryLogCountTotal";
	public static final String PROPERTY_PayInPro_PRIMARY_LOG_FILES_STORED = "PayInProPrimaryLogFilesStored";

	// PayInPro Variables related to Primary Log
	public static final String VARIABLE_PayInPro_CLOUD_LOG_PRIMARY = "cloud-log-primary";

	// PayInPro Properties related to Secondary Log
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_IS_ENABLED = "PayInProIsSecondaryLogEnabled";
	
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_FILENAME = "PayInProSecondaryLogFilename";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_RETENTION = "PayInProSecondaryLogExpires";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_MAX_SIZE = "PayInProSecondaryLogMaxCountPerFile";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_FORMAT = "PayInProSecondaryLogFileFormat";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_COUNT_BY_FILE = "PayInProSecondaryLogCountByLogFile";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_COUNT_DEBUG = "PayInProSecondaryLogCountDebug";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_COUNT_INFO = "PayInProSecondaryLogCountInfo";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_COUNT_WARN = "PayInProSecondaryLogCountWarn";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_COUNT_ERROR = "PayInProSecondaryLogCountError";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_COUNT_FATAL = "PayInProSecondaryLogCountFatal";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_COUNT_TOTAL = "PayInProSecondaryLogCountTotal";
	public static final String PROPERTY_PayInPro_SECONDARY_LOG_FILES_STORED = "PayInProSecondaryLogFilesStored";
	
	// PayInPro Variables related to Secondary Log
	public static final String VARIABLE_PayInPro_CLOUD_LOG_SECONDARY = "cloud-log-secondary";

	// Cloud Log format enumeration values
	public static final String PROPERTY_PayInPro_CLOUD_LOG_FORMAT_HTML = "HTML";
	public static final String PROPERTY_PayInPro_CLOUD_LOG_FORMAT_CSV = "CSV";
	public static final String PROPERTY_PayInPro_CLOUD_LOG_FORMAT_XLSX = "XLSX";
	
	// PayInPro Input Parameters related to General Cloud Logging
	public static final String PARAMETER_IN_PayInPro_CLOUD_LOG_LEVEL = "inLogLevel";
	public static final String PARAMETER_IN_PayInPro_CLOUD_LOG_FINALIZE = "inLogFinalize";
	
	// PayInPro102 Input Parameters used in custom Java
	public static final String PROP_PARAMETER_IN_PROMPT_MAP = "inPropertyNameReportPromptMap";

}
/*	
 * The schema defined by this Studio has the same root element as the Import_Payroll_Input and Get_Submit_Payroll_Input web services.
 * However, the custom schema has additional elements and attributes.
 * This class is used to parse a generic payroll input object including the custom elements and attributes.
 */

package com.workday.custom.payInPro.parser;

import com.capeclear.assembly.annotation.Component;

import static com.capeclear.assembly.annotation.Component.Type.*;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(name = "ParsePayrollInput", type = mediation, toolTip = "", scope = "prototype", smallIconPath = "icons/ParsePayrollInput_16.png", largeIconPath = "icons/ParsePayrollInput_24.png")
public class ParseDISDeduction extends ParseMessageXML {

	private final String entryTagName = "tdf:deductionData";
	
	private final String refIdElementPath = entryTagName + "/tdf:refId";
	private final String refTypeElementPath = entryTagName + "/tdf:refType";
	
	private String refId, refType;
	
	@Override
	public String getEntryTagName() {
		return entryTagName;
	}

	@Override
	public void processEntryTagStart() {
		refId = "";
		refType = "";
	}

	@Override
	public void processEntryTagEnd() {
		processCustomData(refType, refId);
	}

	@Override
	public void processStartElement(String fullPath, HashMap<String, String> attributeMap) {
		switch (fullPath) {
		
		default:
			/* Processes additional values as defined via field overrides. */
			break;

		}
	}

	
	
	@Override
	public void processEndElement(String fullPath, String value) {
		switch (fullPath) {
		
		case refIdElementPath:
			refId = value;
			break;

		case refTypeElementPath:
			refType = value;
			break;
		
		default:
			/* Processes additional values as defined via field overrides. */
			break;

		}
	}

	private String listPayComponentPropertyName = "globalListPayComponents";
	private ArrayList<String> listPayComponents;
	
	@SuppressWarnings("unchecked")
	@Override
	public void getCustomMediationContextProperties() {
		Object tmpPayComponentList;
		tmpPayComponentList = ctx.getProperty(listPayComponentPropertyName);
		if (tmpPayComponentList == null) {
			listPayComponents =  new ArrayList<String>();
		} else {
			listPayComponents = (ArrayList<String>) tmpPayComponentList;
		}	
		
	}

	@Override
	public void setCustomMediationContextProperties() {
		//Sets the HashMap of stored custom data.
		ctx.setProperty(listPayComponentPropertyName, listPayComponents);
	}

	public void processCustomData(String refTypeValue, String refIdValue) {
		listPayComponents.add(refTypeValue + "|" + refIdValue);
	}
}
package com.workday.custom.payInPro.parser;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;

import java.math.BigDecimal;
import workday.com.bsvc.DeductionAllObjectType;
import workday.com.bsvc.EarningAllObjectType;
import workday.com.bsvc.MatchExistingRecordObjectType;
import workday.com.bsvc.PayrollInputProcessorRequestType;
import workday.com.bsvc.SubmitPayrollInputDataType;
import workday.com.bsvc.WorkerObjectType;
import workday.com.logmessages.LogMessageType;
import workday.com.logmessages.LogMessagesType;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.ListIterator;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(name = "MergeInputAndExisting", type = mediation, toolTip = "", scope = "prototype", smallIconPath = "icons/MergeInputAndExisting_16.png", largeIconPath = "icons/MergeInputAndExisting_24.png")
public class MergeInputAndExisting {
	public MediationContext ctx;
	private ArrayList<SubmitPayrollInputDataType> payInputFinalList;
	private ArrayList<LogMessageType> logMessageList;
	
	/**
	 * This method is called by the Assembly framework.
	 *
	 * Use the <code>MediationContext</code> to access objects in the context, such
	 * as the message, properties and variables e.g.
	 * <ul>
	 * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
	 * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
	 * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
	 * </ul>
	 */
	@ComponentMethod
	public void process(com.capeclear.mediation.MediationContext arg0) {
		// Must be first in this method to instantiate the current Mediation Context.
		ctx = MediationTube.getCurrentMediationContext();

		getCustomMediationContextProperties();
		
		logMessageList = new ArrayList<LogMessageType>();

		ListIterator<SubmitPayrollInputDataType> iterPayInputData = payInputReq.getPayrollInputData().listIterator();

		payInputFinal.setDefaultBatchID(payInputReq.getDefaultBatchID());
		
		payInputFinalList = new ArrayList<SubmitPayrollInputDataType>();

		while (iterPayInputData.hasNext()) {
			Boolean hasErrors = false;
			Boolean processExisting = false;
			int unprocessedCount = 0;
			Boolean insertNewPayInput = false;
			
			SubmitPayrollInputDataType payInputData = iterPayInputData.next();

			String originalRecordNbr = payInputData.getOriginRecordNbr();
			String recordNumber = (originalRecordNbr == null) ? String.valueOf(iterPayInputData.previousIndex())
					: originalRecordNbr;

			try {
				WorkerObjectType workerRef = payInputData.getWorkerReference();
				EarningAllObjectType earningRef = payInputData.getEarningReference();
				DeductionAllObjectType deductionRef = payInputData.getDeductionReference();
				//PayrollInputWorktagsDataType worktagRef = payInputData.getWorktagData();
				
				String workerKey = (workerRef == null) ? "" : workerRef.getID().getType() + "|" + workerRef.getID().getValue() ;
				String earningKey = (earningRef == null) ? "" : earningRef.getID().getType() + "|" + earningRef.getID().getValue();
				String deductionKey = (deductionRef == null) ? "" : deductionRef.getID().getType() + "|" + deductionRef.getID().getValue();
				
				String workerType = (workerRef == null) ? "" : workerRef.getID().getType();
				String workerId = (workerRef == null) ? "" : workerRef.getID().getValue();
				String payComponentType = (earningRef == null) ? deductionRef.getID().getType() : earningRef.getID().getType();
				String payComponentId = (earningRef == null) ? deductionRef.getID().getValue() : earningRef.getID().getValue();
				
				//String worktagHash = (worktagRef == null) ? "0" : String.valueOf(worktagRef.hashCode());
				
				String finalHashMatchBasic = workerKey + "|" + earningKey + "|" + deductionKey;
				//String finalHashMatchWorktags = workerHash + "|" + earningHash + "|" + deductionHash + "|" + worktagHash;
			
				MatchExistingRecordObjectType matchExistingObj = payInputData.getMatchExistingRecord();
								
				if (matchExistingObj == null) {
					insertNewPayInput = true;
				} else {
					ArrayList<SubmitPayrollInputDataType> existingInputs;
					
					String matchNone = getLogLevel(matchExistingObj.getMatchDoesNotExistLogLevel());
					String matchMultiple = getLogLevel(matchExistingObj.getMatchMultipleExistLogLevel());
					Boolean replaceBatchId = ((matchExistingObj.isReplaceExistingBatchID() == null) ? false : matchExistingObj.isReplaceExistingBatchID());
					Boolean minimizeMatchAmount = ((matchExistingObj.isMinimizeUpdatesWhenMatchingAmount() == null) ? false : matchExistingObj.isMinimizeUpdatesWhenMatchingAmount());
							
					//if (matchExistingObj.isMatchOnWorktags() == null || !matchExistingObj.isMatchOnWorktags()) {
					existingInputs =  payInputExistingHash.get(finalHashMatchBasic);
					//} else {
					//	existingInputs =  payInputExistingHash.get(finalHashMatchWorktags);
					//}
										
					if ((existingInputs == null || existingInputs.size() == 0)) {
						// Zero matches, we should never try processing existing.
						processExisting = false;
						
						if (matchNone.equalsIgnoreCase("ignore")) {
							if (matchExistingObj.isEndOnly() == null || !matchExistingObj.isEndOnly()) {
								insertNewPayInput = true;
							}
						} else {
							if (matchNone.equalsIgnoreCase("info")) {
								hasErrors = false;
								if (matchExistingObj.isEndOnly() == null || !matchExistingObj.isEndOnly()) {
									insertNewPayInput = true;
								}
							} else {
								hasErrors = true;
							}
							

							addLogMessage(matchNone, "No Existing Inputs Found", "No exiting inputs were found for this record. If this should be ignored, please update the Match Does Not Exist Log Level",
									null, "MergeInputAndExisting", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
						}
					}
					
					if (existingInputs != null && existingInputs.size() > 1) {
						if (matchExistingObj.isEndAllMatches() == null || matchExistingObj.isEndAllMatches() == false) {
							if (matchMultiple.equalsIgnoreCase("ignore")) {
								//Do nothing		
							} else {
								if (!matchMultiple.equalsIgnoreCase("info")) {
									hasErrors = true;
								}

								addLogMessage(matchMultiple, "Multiple Existing Inputs Found", "Multiple exiting inputs were found for this record. If this should be ignored, please update the Match Does Not Exist Log Level",
										null, "MergeInputAndExisting", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
							}
							processExisting = false;
						} else {							
							processExisting = true;
						}
					}
					
					if (existingInputs != null && existingInputs.size() == 1) {
						processExisting = true;
					}
						
					if (processExisting) {
						ListIterator<SubmitPayrollInputDataType> existingRecordIterator = existingInputs.listIterator();
						
						ArrayList<SubmitPayrollInputDataType> buildList = new ArrayList<SubmitPayrollInputDataType>();
						
						while (existingRecordIterator.hasNext()) {
							SubmitPayrollInputDataType existingRecord = existingRecordIterator.next();
							Boolean insertExistingPayInput = false;
							Boolean existingIsProcessed = (existingRecord.getLastPeriodEndDate() == null) ? false : true;
							
							// If not processed...
							// - AND "End Only == false", then overwrite the record.  This means a Start Date would be required and a valid error if missing.
							// - And "End Only == true", then try to update the existing record's values/end dates.
							// If processed...
							// - Try to update the existing record's values/end dates.
							if (!existingIsProcessed && (matchExistingObj.isEndOnly()==null || matchExistingObj.isEndOnly()==false)) {
								// Overwrite. Set inbound input id to the existing input id.
								payInputData.setPayrollInputID(existingRecord.getPayrollInputID());
								
								unprocessedCount = unprocessedCount + 1;
								
							} else {
								// Need to determine the end date we want for the existing record
								LocalDate lastPeriodEndDate = (existingRecord.getLastPeriodEndDate() == null) ? null : LocalDate.of(existingRecord.getLastPeriodEndDate().getYear(), existingRecord.getLastPeriodEndDate().getMonth(), existingRecord.getLastPeriodEndDate().getDay());
								LocalDate existingEndDate = (existingRecord.getEndDate() == null) ? null : LocalDate.of(existingRecord.getEndDate().getYear(), existingRecord.getEndDate().getMonth(), existingRecord.getEndDate().getDay());
								LocalDate userEndDate = (payInputData.getMatchExistingRecord().getEndDate() == null) ? null : LocalDate.of(payInputData.getMatchExistingRecord().getEndDate().getYear(), payInputData.getMatchExistingRecord().getEndDate().getMonth(), payInputData.getMatchExistingRecord().getEndDate().getDay());

								Boolean amountsMatch;
								if (minimizeMatchAmount) {
									BigDecimal existingAmount = ((existingRecord.getAmount() == null) ? java.math.BigDecimal.ZERO : existingRecord.getAmount());
									BigDecimal inputAmount = ((payInputData.getAmount() == null) ? java.math.BigDecimal.ZERO : payInputData.getAmount());
									
									amountsMatch = (existingAmount.compareTo(inputAmount) == 0);
								} else {
									amountsMatch = false;
								}
								
								if (amountsMatch) {
									//The goal of this process is to minimize updates in the tenant.
									//When quantities match, we want to update the existing record only
									//unless the existing record dates prevent the process from doing so.
									
									if (userEndDate == null && existingEndDate == null) {
										//Quantities match and both are open ended, do nothing!
										insertNewPayInput = false;
										insertExistingPayInput = false;
									} else if (userEndDate == null && existingEndDate != null && existingEndDate.isAfter(lastPeriodEndDate)) {
										//Since the existing record has an End Date already, we're going to try and remove it.
										//This is only possible if the LPED is before the existing end date.
										existingRecord.setEndDate(null);
										
										insertNewPayInput = false;
										insertExistingPayInput = true;
									} else {
										//LPED and existing end date are the same or end date is in the past.
										//Therefore, we should create a new record for the incoming pay input while
										//also ending the existing.
										insertNewPayInput = true;
										insertExistingPayInput = false;
									}
								} else {
									//Quantities do not match so follow standard date corrections.
									
									if (userEndDate == null && lastPeriodEndDate == null) {
										addLogMessage("warn", "User-provided End Date is Null and record has not been processed by payroll.", "The user-provided end date is null and the record has not been processed by payroll. Integration cannot determine the correct end date to use.",
												existingRecord.getPayrollInputID(), "MergeInputAndExisting", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
									} else if (userEndDate == null) {
										// If User date is null, then use the LPED
										existingRecord.setEndDate(createXmlGregorianCalendar(lastPeriodEndDate.toString(), recordNumber, workerType, workerId, payComponentType, payComponentId));
										insertExistingPayInput = true;
									} else {
										if (lastPeriodEndDate != null && lastPeriodEndDate.isAfter(userEndDate)) {
											// If LPED is after User date, then use the LPED but warn that user date was too early
											existingRecord.setEndDate(createXmlGregorianCalendar(lastPeriodEndDate.toString(), recordNumber, workerType, workerId, payComponentType, payComponentId));
											insertExistingPayInput = true;
											
											addLogMessage("warn", "User-provided End Date is Before Last Period End Date", "The user-provided end date is before the last period end date of the record. The last period end date was used to end the record.",
													existingRecord.getPayrollInputID(), "MergeInputAndExisting", recordNumber, workerType, workerId, payComponentType, payComponentId, null);
											
										} else if (lastPeriodEndDate != null && lastPeriodEndDate.isEqual(userEndDate)) {
											// No worries here, just set the end date to either of these.
											existingRecord.setEndDate(createXmlGregorianCalendar(lastPeriodEndDate.toString(), recordNumber, workerType, workerId, payComponentType, payComponentId));
											insertExistingPayInput = true;
										} else {
											// LPED is before the user's end date, so now we have to check the existing end date.
											// In any situation, whether existing is blank, or populated, we will replace this with
											// the user-provided date.
												existingRecord.setEndDate(createXmlGregorianCalendar(userEndDate.toString(), recordNumber, workerType, workerId, payComponentType, payComponentId));
												insertExistingPayInput = true;
										}
									}	
									
									if (matchExistingObj.isEndOnly()==null || matchExistingObj.isEndOnly()==false) {
										insertNewPayInput = true;
									}
										
								}
								
								if (replaceBatchId) {
									existingRecord.setBatchID(payInputData.getBatchID());
								}
								
								// Add updated records first
								if (insertExistingPayInput) {
									buildList.add(existingRecord);
								}
							}
						}
						
						if (!hasErrors) {
							if (buildList.size() > 0) {
								// First add all of the existing records we're updating	
								payInputFinalList.addAll(buildList);
								
								// Now add the new record, if we're not ending only.
								if (matchExistingObj.isEndOnly() == null || !matchExistingObj.isEndOnly()) {
									insertNewPayInput = true;
								}
							} else {
								// Check for unprocessed records
								if (unprocessedCount <= 1) {
									if (minimizeMatchAmount) {
										//Do Nothing because that sub-logic already handled
									} else {
										//Under normal circumstances, insert new.
										insertNewPayInput = true;
									}
								} else {
									insertNewPayInput = false;
									addLogMessage("error", "Multiple Existing Inputs Not Processed by Payroll", "There are multiple existing inputs which are not part of a payroll result yet. The Payroll Input Procesor does not support multiple unprocessed exsiting inputs. Please manually review the tenant for this worker and pay component.",
											null, "MergeInputAndExisting", recordNumber, workerType, workerId, payComponentType, payComponentId, null);	
								}
							}
						}
					}
				}
				
				if (!hasErrors && insertNewPayInput) {
					cleanAndAddPayInputToList(payInputData);	
				}
				
			} catch (Exception e) {
				addLogMessage("error", "Unhandled error in MergeInputAndExisting", e.toString(),
						null, "MergeInputAndExisting", recordNumber, null, null, null, null, org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(e));

			}
		}
		
		payInputFinal.setPayrollInputData(payInputFinalList);

		setCustomMediationContextProperties();

	}
	
	private String getLogLevel(String value) {
		if (value == null) {
			return "error";
		} else if (value.isEmpty()) {
			return "error";
		} else {
			return value;
		}
	}
	
	private void cleanAndAddPayInputToList(SubmitPayrollInputDataType payInputData) {
		//This method removes any Payroll Input Processor specific data elements so
		//the java-to-xml output is clean for the Import WS.
		payInputData.setOriginRecordNbr(null);
		payInputData.setStartDateLookup(null);
		payInputData.setEndDateLookup(null);
		payInputData.setMatchExistingRecord(null);
		
		payInputFinalList.add(payInputData);
	}

	private void addLogMessage(String inLogLevel, String inMessage, String inMessageDetail, String inReferenceID, String inLocalIn, String inRecordNumber, String inWorkerType, String inWorkerId, String inPayComponentType, String inPayComponentID, String inSupportData) {
		LogMessageType lm = new LogMessageType();
		
		XMLGregorianCalendar tmpXmlCal = null;
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTimeInMillis(System.currentTimeMillis());
		try {
			tmpXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		lm.setTimestamp(tmpXmlCal);
		lm.setLogLevel(inLogLevel);
		lm.setMessage(inMessage);
		lm.setMessageDetail(inMessageDetail);
		lm.setRecordNumber(inRecordNumber);
		lm.setReferenceID(inReferenceID);
		lm.setSupportData(inSupportData);
		lm.setLocalIn(inLocalIn);
		lm.setWorkerID(inWorkerId);
		lm.setWorkerType(inWorkerType);
		lm.setPayComponentID(inPayComponentID);
		lm.setPayComponentType(inPayComponentType);
		
		logMessageList.add(lm);
	}
	
	
	private XMLGregorianCalendar createXmlGregorianCalendar(String value, String recordNumber, String inWorkerType, String inWorkerId, String inPayComponentType, String inPayComponentID) {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date;
		XMLGregorianCalendar tmpXmlCal = null;

		try {
			date = format.parse(value);

			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);

			tmpXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			addLogMessage("error",
					e.toString(),
					e.getMessage(),
					null, "ParsePayrollInputsFromSdt", recordNumber, inWorkerType, inWorkerId, inPayComponentType, inPayComponentID, org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(e));
			return null;
		} catch (ParseException e) {
			addLogMessage("error",
					e.toString(),
					e.getMessage(),
					null, "ParsePayrollInputsFromSdt", recordNumber, inWorkerType, inWorkerId, inPayComponentType, inPayComponentID, org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(e));
			return null;
		}

		return tmpXmlCal;

	}

	private final String payInputReq_prop = "globalPayInputs_Inbound";
	private PayrollInputProcessorRequestType payInputReq;

	private final String payInputExistingHash_prop = "globalPayInputs_Existing_HashMap";
	private HashMap<String, ArrayList<SubmitPayrollInputDataType>> payInputExistingHash;

	private String logMessages_prop = "global_list_log_messages";
	private LogMessagesType logMessages;

	private final String payInputFinal_prop = "globalPayInputs_Final";
	private PayrollInputProcessorRequestType payInputFinal;
	
	@SuppressWarnings("unchecked")
	public void getCustomMediationContextProperties() {
		Object tmpPayInputReq;
		tmpPayInputReq = ctx.getProperty(payInputReq_prop);
		if (tmpPayInputReq == null) {
			payInputReq = null;
		} else {
			payInputReq = (PayrollInputProcessorRequestType) tmpPayInputReq;
		}
		
		Object tmpExistingInputHash;
		tmpExistingInputHash = ctx.getProperty(payInputExistingHash_prop);
		if (tmpExistingInputHash == null) {
			payInputExistingHash = new HashMap<String, ArrayList<SubmitPayrollInputDataType>>();
		} else {
			payInputExistingHash = (HashMap<String, ArrayList<SubmitPayrollInputDataType>>) tmpExistingInputHash;
		}

		Object tmpFinalInputReq;
		tmpFinalInputReq = ctx.getProperty(payInputFinal_prop);
		if (tmpFinalInputReq == null) {
			payInputFinal = new PayrollInputProcessorRequestType();
		} else {
			payInputFinal = (PayrollInputProcessorRequestType) tmpFinalInputReq;
		}
	}

	public void setCustomMediationContextProperties() {
		logMessages = new LogMessagesType();
		logMessages.setLogMessage(logMessageList);
		
		// Sets the HashMap of stored custom data.
		ctx.setProperty(payInputFinal_prop, payInputFinal);
		ctx.setProperty(logMessages_prop, logMessages);

		//ctx.setMessage(ctx.getMessage());
	}
}
package com.workday.custom.payInPro.dto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PayGroupDTO {
	private ReferenceDTO _payGroupReference;
	private ReferenceDTO _runCategoryReference;
	private LocalDate _lastPeriodStartDate;
	private LocalDate _lastPeriodEndDate;
	private LocalDate _lastPeriodPaymentDate;
	private LocalDate _currentPeriodStartDate;
	private LocalDate _currentPeriodEndDate;
	private LocalDate _currentPeriodPaymentDate;
	private LocalDate _nextPeriodStartDate;
	private LocalDate _nextPeriodEndDate;
	private LocalDate _nextPeriodPaymentDate;
	
	public PayGroupDTO() {
		this._payGroupReference = new ReferenceDTO();
		this._runCategoryReference = new ReferenceDTO();
		this._lastPeriodStartDate = null;
		this._lastPeriodEndDate = null;
		this._lastPeriodPaymentDate = null;
		this._currentPeriodStartDate = null;
		this._currentPeriodEndDate = null;
		this._currentPeriodPaymentDate = null;
		this._nextPeriodStartDate = null;
		this._nextPeriodEndDate = null;
		this._nextPeriodPaymentDate = null;
	}
	
	public ReferenceDTO getPayGroupReference() {
		if (this._payGroupReference == null) {
			return null;
		} else {
			return (ReferenceDTO) this._payGroupReference.clone();	
		}
	}

	public void setPayGroupReference(ReferenceDTO value) {
		if (value == null) {
			this._payGroupReference = null;
		} else {
			this._payGroupReference = (ReferenceDTO) value.clone();
		}
	}

	public ReferenceDTO getRunCategoryReference() {
		if (this._runCategoryReference == null) {
			return null;
		} else {
			return (ReferenceDTO) this._runCategoryReference.clone();	
		}
	}

	public void setRunCategoryReference(ReferenceDTO value) {
		if (value == null) {
			this._runCategoryReference = null;
		} else {
			this._runCategoryReference = (ReferenceDTO) value.clone();
		}
	}

	public LocalDate getLastPeriodStartDate() {
		return this._lastPeriodStartDate;
	}

	public void setLastPeriodStartDate(String lastPeriodStartDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._lastPeriodStartDate = LocalDate.parse(lastPeriodStartDate, dateTimeFormat);
		} catch (Exception ex) {
			this._lastPeriodStartDate = null;
		}
	}
	
	public LocalDate getLastPeriodEndDate() {
		if (this._lastPeriodEndDate != null) {
			return this._lastPeriodEndDate;
		} else {
			if (this._currentPeriodStartDate != null) {
				return this._currentPeriodStartDate.minusDays(1);
			} else {
				return null;
			}
		}
	}

	public void setLastPeriodEndDate(String lastPeriodEndDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._lastPeriodEndDate = LocalDate.parse(lastPeriodEndDate, dateTimeFormat);
		} catch (Exception ex) {
			this._lastPeriodEndDate = null;
		}
	}
	
	public LocalDate getLastPeriodPaymentDate() {
		return this._lastPeriodPaymentDate;
	}

	public void setLastPeriodPaymentDate(String lastPeriodPaymentDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._lastPeriodPaymentDate = LocalDate.parse(lastPeriodPaymentDate, dateTimeFormat);
		} catch (Exception ex) {
			this._lastPeriodPaymentDate = null;
		}
	}
	
	public LocalDate getCurrentPeriodStartDate() {
		if (this._currentPeriodStartDate != null) {
			return this._currentPeriodStartDate;
		} else {
			if (this._lastPeriodEndDate != null) {
				return this._lastPeriodEndDate.plusDays(1);
			} else {
				return null;
			}
		}
	}

	public void setCurrentPeriodStartDate(String currentPeriodStartDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._currentPeriodStartDate = LocalDate.parse(currentPeriodStartDate, dateTimeFormat);
		} catch (Exception ex) {
			this._currentPeriodStartDate = null;
		}
	}
	
	public LocalDate getCurrentPeriodEndDate() {
		if (this._currentPeriodEndDate != null) {
			return this._currentPeriodEndDate;
		} else {
			if (this._nextPeriodStartDate != null) {
				return this._nextPeriodStartDate.minusDays(1);
			} else {
				return null;
			}
		}
	}

	public void setCurrentPeriodEndDate(String currentPeriodEndDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._currentPeriodEndDate = LocalDate.parse(currentPeriodEndDate, dateTimeFormat);
		} catch (Exception ex) {
			this._currentPeriodEndDate = null;
		}
	}
	
	public LocalDate getCurrentPeriodPaymentDate() {
		return this._currentPeriodPaymentDate;
	}

	public void setCurrentPeriodPaymentDate(String currentPeriodPaymentDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._currentPeriodPaymentDate = LocalDate.parse(currentPeriodPaymentDate, dateTimeFormat);
		} catch (Exception ex) {
			this._currentPeriodPaymentDate = null;
		}
	}
	
	public LocalDate getNextPeriodStartDate() {
		if (this._nextPeriodStartDate != null) {
			return this._nextPeriodStartDate;
		} else {
			if (this._currentPeriodEndDate != null) {
				return this._currentPeriodEndDate.plusDays(1);
			} else {
				return null;
			}
		}
	}

	public void setNextPeriodStartDate(String nextPeriodStartDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._nextPeriodStartDate = LocalDate.parse(nextPeriodStartDate, dateTimeFormat);
		} catch (Exception ex) {
			this._nextPeriodStartDate = null;
		}
	}
	
	public LocalDate getNextPeriodEndDate() {
		return this._nextPeriodEndDate;
	}

	public void setNextPeriodEndDate(String nextPeriodEndDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._nextPeriodEndDate = LocalDate.parse(nextPeriodEndDate, dateTimeFormat);
		} catch (Exception ex) {
			this._nextPeriodEndDate = null;
		}
	}
	
	public LocalDate getNextPeriodPaymentDate() {
		return this._nextPeriodPaymentDate;
	}

	public void setNextPeriodPaymentDate(String nextPeriodPaymentDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._nextPeriodPaymentDate = LocalDate.parse(nextPeriodPaymentDate, dateTimeFormat);
		} catch (Exception ex) {
			this._nextPeriodPaymentDate = null;
		}
	}
	
	public LocalDate getDateByType(String value) {
		switch (value.toUpperCase()) {
		case "PRIOR_PERIOD_START":
			return this.getLastPeriodStartDate();
		
		case "PRIOR_PERIOD_END":
			return this.getLastPeriodEndDate();
			
		case "PRIOR_PERIOD_PAYMENT":
			return this.getLastPeriodPaymentDate();
	
		case "NEXT_PERIOD_START":
			return this.getNextPeriodStartDate();

		case "NEXT_PERIOD_END":
			return this.getNextPeriodEndDate();

		case "NEXT_PERIOD_PAYMENT":
			return this.getNextPeriodPaymentDate();

		case "CURRENT_PERIOD_START":
			return this.getCurrentPeriodStartDate();

		case "CURRENT_PERIOD_END":
			return this.getCurrentPeriodEndDate();

		case "CURRENT_PERIOD_PAYMENT":
			return this.getCurrentPeriodPaymentDate();
			
		default:
			return null;
		}
	}
}

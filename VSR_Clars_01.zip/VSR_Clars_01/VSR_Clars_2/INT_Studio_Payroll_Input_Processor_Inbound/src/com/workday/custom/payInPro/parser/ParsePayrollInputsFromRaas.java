package com.workday.custom.payInPro.parser;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;

import workday.com.bsvc.DeductionAllObjectType;
import workday.com.bsvc.EarningAllObjectType;
import workday.com.bsvc.PayrollInputProcessorRequestType;
import workday.com.bsvc.SubmitPayrollInputDataType;
import workday.com.bsvc.WorkerObjectType;
import workday.com.logmessages.LogMessageType;
import workday.com.logmessages.LogMessagesType;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.ListIterator;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(name = "ParsePayrollInputsFromRaas", type = mediation, toolTip = "", scope = "prototype", smallIconPath = "icons/ParsePayrollInputsFromRaas_16.png", largeIconPath = "icons/ParsePayrollInputsFromRaas_24.png")
public class ParsePayrollInputsFromRaas {
	public MediationContext ctx;
	private ArrayList<LogMessageType> logMessageList;

	/**
	 * This method is called by the Assembly framework.
	 *
	 * Use the <code>MediationContext</code> to access objects in the context, such
	 * as the message, properties and variables e.g.
	 * <ul>
	 * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
	 * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
	 * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
	 * </ul>
	 */
	@ComponentMethod
	public void process(com.capeclear.mediation.MediationContext arg0) {
		// Must be first in this method to instantiate the current Mediation Context.
		ctx = MediationTube.getCurrentMediationContext();

		getCustomMediationContextProperties();

		logMessageList = new ArrayList<LogMessageType>();

		ListIterator<SubmitPayrollInputDataType> iterPayInputData = payInputExisting.getPayrollInputData().listIterator();

		while (iterPayInputData.hasNext()) {
			ArrayList<SubmitPayrollInputDataType> tmpList;
			
			SubmitPayrollInputDataType payInputData = iterPayInputData.next();

			try {
				if (payInputData.getWorkerReference() == null) {
					addLogMessage("error", "No worker reference found on pay input", null, payInputData.getPayrollInputID(),
							"ParsePayrollInputsFromRaas", null, null, null, null, null, null);
				} else {
					WorkerObjectType workerRef = payInputData.getWorkerReference();
					EarningAllObjectType earningRef = payInputData.getEarningReference();
					DeductionAllObjectType deductionRef = payInputData.getDeductionReference();
					//PayrollInputWorktagsDataType worktagRef = payInputData.getWorktagData();
					
					String workerKey = (workerRef == null) ? "" : workerRef.getID().getType() + "|" + workerRef.getID().getValue() ;
					String earningKey = (earningRef == null) ? "" : earningRef.getID().getType() + "|" + earningRef.getID().getValue();
					String deductionKey = (deductionRef == null) ? "" : deductionRef.getID().getType() + "|" + deductionRef.getID().getValue();
					
					String finalHashMatchBasic = workerKey + "|" + earningKey + "|" + deductionKey;
					tmpList = payInputExistingHash.getOrDefault(finalHashMatchBasic, new ArrayList<SubmitPayrollInputDataType>());
					tmpList.add(payInputData);
					payInputExistingHash.put(finalHashMatchBasic, tmpList);
					
					// TODO: Match by Worktag(s)
					//String worktagHash = (worktagRef == null) ? "0" : String.valueOf(worktagRef.hashCode());
					//String finalHashMatchWorktags = workerHash + "|" + earningHash + "|" + deductionHash + "|" + worktagHash;
					//tmpList = payInputExistingHash.getOrDefault(finalHashMatchWorktags, new ArrayList<SubmitPayrollInputDataType>());
					//tmpList.add(payInputData);
					//payInputExistingHash.put(finalHashMatchWorktags, tmpList);
					
				}
			} catch (Exception e) {
				addLogMessage("error", "Unhandled error in ParsePayrollInputsFromRaas", e.toString(),
						payInputData.getPayrollInputID(), "ParsePayrollInputsFromRaas", null, null, null, null, null, org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(e));

			}
		}

		setCustomMediationContextProperties();
	}


	private void addLogMessage(String inLogLevel, String inMessage, String inMessageDetail, String inReferenceID, String inLocalIn, String inRecordNumber, String inWorkerType, String inWorkerId, String inPayComponentType, String inPayComponentID, String inSupportData) {
		LogMessageType lm = new LogMessageType();
		
		XMLGregorianCalendar tmpXmlCal = null;
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTimeInMillis(System.currentTimeMillis());
		try {
			tmpXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		lm.setTimestamp(tmpXmlCal);
		lm.setLogLevel(inLogLevel);
		lm.setMessage(inMessage);
		lm.setMessageDetail(inMessageDetail);
		lm.setRecordNumber(inRecordNumber);
		lm.setReferenceID(inReferenceID);
		lm.setSupportData(inSupportData);
		lm.setLocalIn(inLocalIn);
		lm.setWorkerID(inWorkerId);
		lm.setWorkerType(inWorkerType);
		lm.setPayComponentID(inPayComponentID);
		lm.setPayComponentType(inPayComponentType);
		
		logMessageList.add(lm);
	}

	private final String payInputExisting_prop = "globalPayInputs_Existing";
	private PayrollInputProcessorRequestType payInputExisting;

	private final String payInputExistingHash_prop = "globalPayInputs_Existing_HashMap";
	private HashMap<String, ArrayList<SubmitPayrollInputDataType>> payInputExistingHash;

	private String logMessages_prop = "global_list_log_messages";
	private LogMessagesType logMessages;

	@SuppressWarnings("unchecked")
	public void getCustomMediationContextProperties() {
		Object tmpExistingInputReq;
		tmpExistingInputReq = ctx.getProperty(payInputExisting_prop);
		if (tmpExistingInputReq == null) {
			payInputExisting = null;
		} else {
			payInputExisting = (PayrollInputProcessorRequestType) tmpExistingInputReq;
		}

		Object tmpExistingInputHash;
		tmpExistingInputHash = ctx.getProperty(payInputExistingHash_prop);
		if (tmpExistingInputHash == null) {
			payInputExistingHash = new HashMap<String, ArrayList<SubmitPayrollInputDataType>>();
		} else {
			payInputExistingHash = (HashMap<String, ArrayList<SubmitPayrollInputDataType>>) tmpExistingInputHash;
		}
	}

	public void setCustomMediationContextProperties() {
		logMessages = new LogMessagesType();
		logMessages.setLogMessage(logMessageList);

		// Sets the HashMap of stored custom data.
		ctx.setProperty(payInputExistingHash_prop, payInputExistingHash);
		ctx.setProperty(logMessages_prop, logMessages);
	}
}

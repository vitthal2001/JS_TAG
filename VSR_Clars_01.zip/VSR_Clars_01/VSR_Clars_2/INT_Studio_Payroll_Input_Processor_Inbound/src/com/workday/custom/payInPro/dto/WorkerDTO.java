package com.workday.custom.payInPro.dto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class WorkerDTO {
	private ReferenceDTO _workerReference;
	private ReferenceDTO _primaryPositionReference;
	private ReferenceDTO _payGroupReference;
	private LocalDate _terminationDate;
	private Boolean _terminated;
	private String _ssn;
	
	public WorkerDTO() {
		this._terminationDate = null;
	}
	
	public ReferenceDTO getWorkerReference() {
		if (this._workerReference == null) {
			return null;
		} else {
			return (ReferenceDTO) this._workerReference.clone();	
		}
	}

	public void setWorkerReference(ReferenceDTO ref) {
		if (ref == null) {
			this._workerReference = null;
		} else {
			this._workerReference = (ReferenceDTO) ref.clone();
		}
	}
	
	public ReferenceDTO getPrimaryPositionReference() {
		if (this._primaryPositionReference == null) {
			return null;
		} else {
			return (ReferenceDTO) this._primaryPositionReference.clone();	
		}
	}

	public void setPrimaryPositionReference(ReferenceDTO ref) {
		if (ref == null) {
			this._primaryPositionReference = null;
		} else {
			this._primaryPositionReference = (ReferenceDTO) ref.clone();
		}
	}
	
	public ReferenceDTO getPayGroupReference() {
		if (this._payGroupReference == null) {
			return null;
		} else {
			return (ReferenceDTO) this._payGroupReference.clone();	
		}
	}

	public void setPayGroupReference(ReferenceDTO ref) {
		if (ref == null) {
			this._payGroupReference = null;
		} else {
			this._payGroupReference = (ReferenceDTO) ref.clone();
		}
	}
	
	public Boolean getTerminated() {
		if (this._terminated == null) {
			return false;
		} else {
			return this._terminated;
		}
	}

	public void setTerminated(Boolean terminated) {
		this._terminated = terminated;
	}
	
	public String getSSN() {
		return this._ssn;
	}

	public void setSSN(String value) {
		this._ssn = value;
	}
	
	public LocalDate getTerminationDate() {
		return this._terminationDate;
	}

	public void setTerminationDate(String terminationDate, DateTimeFormatter dateTimeFormat) {
		try {
			this._terminationDate = LocalDate.parse(terminationDate, dateTimeFormat);
		} catch (Exception ex) {
			this._terminationDate = null;
		}
	}
}

package com.parse.xml;


import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import com.capeclear.assembly.annotation.Property.Edit;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
//import com.capeclear.assembly.annotation.Property;
import com.capeclear.xml.utils.XmlUtils;

import static com.capeclear.assembly.annotation.Component.Type.*;


/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "Xmlfileparsing",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/Xmlfileparsing_16.png",
        largeIconPath = "icons/Xmlfileparsing_24.png"
        )
public class Xmlfileparsing {
	public String itemPath = "";
    /**
     * This method is called by the Assembly framework.
     *
     * Use the <code>MediationContext</code> to access objects in the context,
     * such as the message, properties and variables e.g.
     * <ul>
     * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
     * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
     * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
     * </ul>    
     */
    @ComponentMethod
    public void process(java.io.InputStream input) {
    	
    	System.out.println("******SPLIT ELEMENT:");
    	
    	// Use attributes to find the "split" node
    	String lastElement = itemPath;
		int lastNodeLength = 0;
		if (lastElement.contains("/")) {
			lastNodeLength = lastElement.split("/").length;
			lastElement = lastElement.split("/")[lastNodeLength - 1];
		}
		if (lastElement.contains("\\")) {
			lastNodeLength = lastElement.split("\\\\").length;
			lastElement = lastElement.split("\\\\")[lastNodeLength - 1];
		}
		System.out.println("******SPLIT ELEMENT:" + lastElement);
    	// Get the mediation context
    	MediationContext ctx = MediationTube.getCurrentMediationContext();
    	
    	
    	// Create the XMLInputFactory.   The factory is a class that is used to create the XMLReader
    	XMLInputFactory inputFactory = XmlUtils.getXMLInputFactory();
    	//Create the XMLReader
		XMLEventReader xmlReader;
		// Try to create the reader from the factory
		try {
			//input is from the parameters to the process method
			xmlReader = inputFactory.createXMLEventReader(input);
		} catch (XMLStreamException e) {
			// not XML, then the error below is likely
			throw new RuntimeException(
					"XML reader was unable to be created based on your input.  Please confrim that the message is XML",
					e);
		}
		//Start the loop
				try {
					String tagName = "";
				//XML event that we are on now	
				XMLEvent curr = null;
				//boolean process = false;
				//Loop through all nodes
				do {
					// if the current element is null, get the next one (first record only)
					if (curr == null) {
						//gets next event from the stream (whitespace included)
						curr = xmlReader.nextEvent();
					}
						if (curr.isStartElement()) {
							// Get the tag name
							if (curr.asStartElement().toString().contains("mon"))
									{
										System.out.println(curr.asStartElement());

									}
							else {
								tagName = getTagNameFromStart(curr.asStartElement());
								ctx.setProperty("p.valstart",tagName);
								}
						}
						else if (curr.isEndElement()) {
							// Get the tag name
							if (curr.asEndElement().toString().contains("mon"))
									{
										System.out.println(curr.asEndElement());

									}
							else 
							{
								
								tagName = getTagNameFromEnd(curr.asEndElement());
								ctx.setProperty("p.valend",tagName);
							}
						}
						else if (curr.isCharacters()) {
							// If whitespace skip
							if (curr.asCharacters().isWhiteSpace()) {
								// do nothing
							}
							// If CDATA or ignorable whitespace, skip
							else if (curr.asCharacters().isIgnorableWhiteSpace()
									|| curr.asCharacters().isCData()) {
								// Do Nothing - will be skipped
							}
							// Otherwise store the last data value Process Chars
							
							else if (curr.asCharacters().getData().toString().contains("mon"))
									{
										System.out.println(curr.asCharacters().getData());

									}
							else
							{
								ctx.setProperty("p.char",curr.asCharacters().getData());
								System.out.println(curr.asCharacters().getData());
							}
						}
						//gets next event from the stream (whitespace included)
						curr = xmlReader.nextEvent();
						// end of loop - keeps going until curr is the end document	
					}
				while (!curr.isEndDocument());
				
				}
				//end try
						 catch (XMLStreamException e) {
							//throw this error if a problem happens while looping through the records
							throw new RuntimeException(
									"XML reader had a problem reading the nextEvent",
									e);
						}
    }
    //Helper method to get the tag name from an end element
   	private String getTagNameFromEnd(EndElement end) {
   		if (end.getName().getPrefix() != "") {
   			return end.getName().getPrefix() + ":"
   					+ end.getName().getLocalPart();
   		}

   		return end.getName().getLocalPart();
   	}
   	//Helper method to get the tag name from an start element
   	private String getTagNameFromStart(StartElement start) {
   		if (start.getName().getPrefix() != "") {
   			return start.getName().getPrefix() + ":"
   					+ start.getName().getLocalPart();
   		}

   		return start.getName().getLocalPart();
   	}
    @Property(name = "Item Path", order = 1, edit = Edit.DEFAULT, toolTip = "The XPATH to the primary record,  normally wd:Report Data/wd:Report_Entry")
   	public String getItemPath() {
   		return itemPath;
   	}
   	public void setItemPath(String itemPath) {
   		this.itemPath = itemPath;
   	}
}

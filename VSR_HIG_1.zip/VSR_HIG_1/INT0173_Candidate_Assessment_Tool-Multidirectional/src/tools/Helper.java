package tools;

import java.util.Calendar;
import java.util.Date;

public class Helper {
	
	public static void main(String[] args) 
	{
		
	}
	
	public static Date getStartOfFailedWindow(Date currentDate, Integer durationOfWindow) throws Exception
	{
		try
		{
			
			Calendar c = Calendar.getInstance();
			c.setTime(currentDate);
			c.add(java.util.Calendar.DATE, (durationOfWindow * -1));
			
			return c.getTime();
			
		}
		catch (Exception e)
		{
			throw new Exception("Java error getting the start of the failure window!  Error Message: " + e.getMessage());
		}
	}

}

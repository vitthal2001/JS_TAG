package com.wd.util;

import static com.capeclear.assembly.annotation.Component.Type.mediation;

import java.util.Map;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import com.capeclear.assembly.annotation.Property.Edit;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
import com.capeclear.xml.utils.XmlUtils;


/**
 * A simple custom bean which demonstrates how to process messages in a mediation step.
 * 
 * This particular example looks for two configurably named elements and uses the values found in them to
 * populate a HashMap.
 * 
 * The code is purely intended to be provide an example of how to produce a custom step and is not intended
 * to be generic in that it makes the following assumptions:
 * <UL>
 * <LI>The map value will precede the map key</LI>
 * <LI>All map values will be followed by a map key</LI>
 * <LI>No error handling for deviations from the above is performed</LI>
 * </UL>
 * 
 * @author Doug Lee
 */
@Component(
        name = "Populate Hash Map",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/PopulateHashMap_16.png",
        largeIconPath = "icons/PopulateHashMap_24.png"
        )
public class putHash {
	/**
	 * The localname of the element which contains the map key 
	 */

	String keyName;

	/**
	 * The localname of the element which contains the map values
	 */

	String valueName;
	
	/**
	 * The name of the mediation context property which contains the Map
	 */
	String mapName;

    /**
     * This method is called by the Assembly framework.    
     */

	@SuppressWarnings("unchecked")
	@ComponentMethod
    public void process(java.io.InputStream input) {
    	checkProperty("Map name", mapName);
    	checkProperty("Key name", keyName);
    	checkProperty("Value name", valueName);
    	
    	MediationContext ctx = MediationTube.getCurrentMediationContext();
    	
    	Object o_hashmap = ctx.getProperty( mapName );
    	if ( ! ( o_hashmap instanceof Map ) ) {
    		throw new RuntimeException("Property HashMap does not contain a Map");
    	}
    	
    	@SuppressWarnings("rawtypes")
		Map map = (Map)o_hashmap;
    	
    	XMLInputFactory input_factory = XmlUtils.getXMLInputFactory();
    	XMLEventReader reader;
    	try {
			reader = input_factory.createXMLEventReader(input);
		} catch (XMLStreamException e) {
			throw new RuntimeException("Unable to obtain XML reader on input", e);
		}
    	
    	//
    	// Stream process the incoming XML document to look for key and value names.
    	//
    	XMLEvent event;
		String employee_id = null;
		String other_id = null;
    	try {
    		
    		do {
            	event = reader.nextEvent();
            	if ( event.isStartElement() ) {
            		StartElement start = event.asStartElement();

            		String name = start.getName().getLocalPart();
            		if ( valueName.equals(name )) {
            			employee_id = reader.getElementText();
            		}
            		else if (keyName.equals(name) ) {
            			other_id = reader.getElementText();
            			map.put(other_id, employee_id);
            		}
            	}    			
    		}
    		while ( ! event.isEndDocument() );
    		
    	}
    	catch (XMLStreamException xee) {
    		throw new RuntimeException("Error parsing XML", xee);
    	}
    	
    }
    
    /**
     * Check whether the specified value has been initialized
     * @param name Name of the bean property
     * @param value
     */

    private void checkProperty(String name, String value) {
    	if ( ( value == null ) || ( value.length() == 0 ) ) {
    		throw new RuntimeException("Property \"" + name + "\" has not been initialized" );
    	}
    }

	public String getKeyName() {
		return keyName;
	}

	@Property(name="Key name", order=2, edit=Edit.DEFAULT, toolTip="The localname of the element containing the map keys")
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	public String getValueName() {
		return valueName;
	}

	@Property(name="Value name", order=3, edit=Edit.DEFAULT, toolTip="The localname of the element containing the map keys")
	public void setValueName(String valueName) {
		this.valueName = valueName;
	}

	public String getMapName() {
		return mapName;
	}

	@Property(name="Map name", order=1, edit=Edit.DEFAULT, toolTip="The name of the property containing the Map")
	public void setMapName(String mapName) {
		this.mapName = mapName;
	}


}

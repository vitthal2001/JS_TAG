package com.wd.dart.excel;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Hyperlink;

import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.MessageVariable;
import com.opencsv.CSVReader;

public class ExcelWriter {
	String WORKBOOK_VARIABLE_NAME = "v.dart.workbook";
	String WORKSHEET_PROPERTY_NAME = "p.worksheet.to.be.added";
	String WORKSHEET_POSITION_PROPERTY_NAME = "p.worksheet.position";
	String WORKSHEET_COLUMN_WIDTH_NAME = "p.dart.spreadsheet.column.width";
	String LINE_BREAK_IN_CELL = "<br>";
	String[] HYPERLINK_PREFIXES = {"https://", "http://"};
	
	/**
	 * Add main message as a sheet to the DART workbook. Assume the main message is in CSV format when this method is called on the assembly workflow.
	 * @param medCtx
	 */
	@ComponentMethod
    public InputStream process(MediationContext medCtx) throws Exception {
		try{
			validateSetting(medCtx);
			String sheetName = (String)medCtx.getProperty(WORKSHEET_PROPERTY_NAME);
			Integer sheetPosition = (Integer)medCtx.getProperty(WORKSHEET_POSITION_PROPERTY_NAME);
			int sheetColumnWidth = (Integer) medCtx.getProperty(WORKSHEET_COLUMN_WIDTH_NAME);
			
			InputStream csvStream = (InputStream) medCtx.getMessage().getMessagePart(0, InputStream.class);
			
			MessageVariable workBookMsgVar = medCtx.getVariables().get(WORKBOOK_VARIABLE_NAME);
			Workbook workBook;
			if(workBookMsgVar != null){
				workBook = new XSSFWorkbook(workBookMsgVar.getInputStream());
			}
			else{
				workBook = new XSSFWorkbook(); 
			}
			
			CreationHelper helper = workBook.getCreationHelper();			
	        Sheet sheet = workBook.createSheet(sheetName);			
				        
	        CSVReader csvReader = new CSVReader(new InputStreamReader(csvStream), ',');
	        
	        String[] csvValues;
	        int r = 0;
	        Row row;
	        Cell cell;
	        int i = 0;
	        
	        //Handle the title row first: Bold the title and set the column width
	        CellStyle headerCellStyle = workBook.createCellStyle();
	        headerCellStyle.setWrapText(true);
	        headerCellStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
	        Font headerFont = workBook.createFont();
        	headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        	headerCellStyle.setFont(headerFont);
        	csvValues = csvReader.readNext();
	        row = sheet.createRow(r++);	        	
        	for (i = 0; i < csvValues.length; i++){
        		cell = row.createCell(i);
        		cell.setCellStyle(headerCellStyle);        		
        		cell.setCellValue(helper.createRichTextString(csvValues[i]));
        		sheet.setColumnWidth(i, 256*sheetColumnWidth);
        	}    
	        
	        //Handle the data rows and cells.
	        //to enable newlines that are needed, set a cell styles with wrap=true
            CellStyle cellStyle = workBook.createCellStyle();
            cellStyle.setWrapText(true);
            cellStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
            
	        while ((csvValues = csvReader.readNext()) != null) {
	        	row = sheet.createRow(r++);	        	
	        	for (i = 0; i < csvValues.length; i++){
	        		cell = row.createCell(i);
	        		cell.setCellStyle(cellStyle);
	        		if(csvValues[i] != null) 
	        			csvValues[i] = csvValues[i].replaceAll(LINE_BREAK_IN_CELL, "\n");
	        		cell.setCellValue(helper.createRichTextString(csvValues[i]));
	        		
	        		if(isHyperlink(csvValues[i])){
	        			Hyperlink cellLink = helper.createHyperlink(Hyperlink.LINK_URL);
	        			cellLink.setAddress(csvValues[i]);
	        			cell.setHyperlink(cellLink);
	        		}
	        	}            
	        }               
	        
	        csvReader.close();
	        
	        if(sheetPosition != null && sheetPosition >= 0){
	        	workBook.setSheetOrder(sheetName, sheetPosition);
	        }
	        
	        ByteArrayOutputStream byteOutput = new ByteArrayOutputStream();
	        workBook.write(byteOutput);
	        workBook.close();
	        
	        ByteArrayInputStream byteInput = new ByteArrayInputStream(byteOutput.toByteArray());
	        return byteInput;	        
	        
		}
		catch (Exception ex){
			System.out.println("Error occurred when writing a sheet to the DART workbook : " + ex.getMessage());
			ex.printStackTrace();
			throw ex;
		}
    }
	
	protected void validateSetting(MediationContext medCtx) throws Exception {
		if(medCtx.getProperty(WORKSHEET_PROPERTY_NAME) == null || ((String)medCtx.getProperty(WORKSHEET_PROPERTY_NAME)).isEmpty()){
			throw new Exception("Try to add a sheet to the DART workbook, but the sheet name isn't provieded!");
		}		
	}
	
	protected boolean isHyperlink(String strValue){
		boolean isHyperlink = false;
		String str = strValue.toLowerCase();
		for(int i = 0; i < HYPERLINK_PREFIXES.length; i++ ){
			if(str.startsWith(HYPERLINK_PREFIXES[i])){
				isHyperlink = true;
				break;
			}
		}
		return isHyperlink;
	}
}

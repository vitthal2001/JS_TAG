package com.workday.integrations.events;

import java.util.List;

public class Functions {
	
	public static String listToCommaDelimString(List<String> list) {
		if (list == null || list.size() < 1) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		for (String item : list) {
			sb.append(item).append(',');
		}
		if (sb.length() > 0) {
			// remove trailing ','
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}
	
	public static String stringFormatInt(String strFormat, int intValue) {
		return String.format(strFormat, intValue); 
	}
	
	public static String removeCommas(String strIn) {
		return strIn.replaceAll(",", "");
	
	}
	
	public static String replaceSpecialCharsAndBlank(String strIn) {
		
		String strTemp = strIn.replaceAll("[（(]", "_");
		String strTemp2 = strTemp.replaceAll("[）)]", "");
		String strTemp3 = strTemp2.replaceAll("[`']", "_");
		
		return strTemp3.replaceAll(" ", "_");
	
	}	
	
	public static String getNameAndTemplateName(String strIn, String strDelimiter) {
		int charPos = strIn.lastIndexOf(strDelimiter);
		String strText = strIn.substring(0, charPos);
		return strText.replaceAll("___", "__");
	
	}	
	
	
	//<Last Name>_<First Name>_<Employee ID>_<Pay Period End Date>.pdf
	
	
	public static String getEmployeeiDFromPaySlip(String strFileName, String strDelimiter) {
		
		int charPos = strFileName.lastIndexOf(strDelimiter);
		
		String strTextMinusPayPeriod =  strFileName.substring(0, charPos);
		
		int charPos2ndDelim = strTextMinusPayPeriod.lastIndexOf(strDelimiter);
		
		String strEmployeeID = strTextMinusPayPeriod.substring(charPos2ndDelim);
		
		return strEmployeeID;
		
		
	}
	
	public static String setZippedFileNameForPerfReview(String strKey, String strEmployeeID) {
		
		
		// Sample;   <Last Name>_<First Name>__<PR Template Name>__<Date of Extraction>.pdf
		
		
		//Split the Name from the Template Name
		int charPos = strKey.lastIndexOf("__");
		
		String strName = strKey.substring(0, charPos);
		String strTemplateName = strKey.substring(charPos);
		
		String strText = "";
		if (strEmployeeID == null){
			strText = strName  + strTemplateName +  ".zip";
		}
		else{
			strText = strName + "__" + strEmployeeID + strTemplateName +  ".zip";
		}
		
		return strText;
	
	}	
	
	
}

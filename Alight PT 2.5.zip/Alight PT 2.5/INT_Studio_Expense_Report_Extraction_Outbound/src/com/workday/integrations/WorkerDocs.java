package com.workday.integrations;

import java.util.ArrayList;
import java.util.Collections;

public class WorkerDocs {
	private final ArrayList<String> documentNames;
	
	public WorkerDocs() {
		documentNames =  new ArrayList<String>();
	}
	
	public void clearDocs() throws Exception {
		documentNames.clear();
	}
	
	public String dedupeDocName (String strDocName) throws Exception {
		int intOccurrences, intIndexOfDot;
	
		
		documentNames.add(strDocName);
		intOccurrences = Collections.frequency(documentNames, strDocName);
		
		if (intOccurrences > 1) {
			intIndexOfDot = strDocName.lastIndexOf('.');
			if (intIndexOfDot != -1 ) {
				strDocName = strDocName.substring(0, intIndexOfDot) + '_' + String.format("%03d", intOccurrences) + strDocName.substring(intIndexOfDot);
			} else {
				strDocName = strDocName + '_' + String.format("%03d", intOccurrences);	
			}
		}
		return strDocName;
	}

}

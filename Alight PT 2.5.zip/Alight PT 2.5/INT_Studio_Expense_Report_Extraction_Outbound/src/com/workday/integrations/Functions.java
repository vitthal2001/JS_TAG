package com.workday.integrations;

import java.util.List;

public class Functions {
	
	public static String listToCommaDelimString(List<String> list) {
		if (list == null || list.size() < 1) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		for (String item : list) {
			sb.append(item).append(',');
		}
		if (sb.length() > 0) {
			// remove trailing ','
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}
	
	public static String stringFormatInt(String strFormat, int intValue) {
		return String.format(strFormat, intValue); 
	}
	
	public static String removeCommas(String strIn) {
		return strIn.replaceAll(",", "");
	
	}
	
	
}

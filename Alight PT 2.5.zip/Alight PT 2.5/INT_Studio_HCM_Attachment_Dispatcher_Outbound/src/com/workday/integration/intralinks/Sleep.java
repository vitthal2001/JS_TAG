package com.workday.integration.intralinks;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import static com.capeclear.assembly.annotation.Component.Type.*;


/**
 * Custom outtransport
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "Sleep",
        type = outtransport,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/Sleep_16.png",
        largeIconPath = "icons/Sleep_24.png"
        )
public class Sleep {

    /**
     * This method is called by the Assembly framework.    
     */
    @ComponentMethod
    public void sleepCycle(java.lang.String arg0) throws InterruptedException {
		long pollIntervalMilliseconds = Long.valueOf(Long.parseLong(arg0))  * 1000; 
		
		Thread.sleep(pollIntervalMilliseconds) ;

    }
}

package com.workday.integration.intralinks;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import static com.capeclear.assembly.annotation.Component.Type.*;


/**
 * Custom outtransport
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "PollSleep",
        type = outtransport,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/PollSleep_16.png",
        largeIconPath = "icons/PollSleep_24.png"
        )
public class PollSleep {

    /**
     * This method is called by the Assembly framework.    
     */
    @ComponentMethod
    public void process(java.lang.String arg0) {
        // TODO implement
    }
}

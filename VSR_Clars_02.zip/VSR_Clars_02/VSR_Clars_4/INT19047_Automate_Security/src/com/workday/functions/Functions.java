package com.workday.functions;

import java.util.List;

public class Functions {
	public static String listToReportString(List<String> listIn)
	{
		if(listIn != null && listIn.size() > 0)
		{
			boolean first = true;
			String toReturn= "";
			for(int i = 0; i < listIn.size(); i++)
			{
				if(first)
				{
					toReturn += listIn.get(i);
					first = false;
				}
				else{
					toReturn += "!" + listIn.get(i);
				}
			}
			return toReturn;
		}
		return "ERROR";
	}
	public static int stringToInt(String numberIn)
	{
		try{
			int number = Integer.parseInt(numberIn);
			return number;
		}
		catch (Exception e)
		{
			return 0;
		}
	}

}

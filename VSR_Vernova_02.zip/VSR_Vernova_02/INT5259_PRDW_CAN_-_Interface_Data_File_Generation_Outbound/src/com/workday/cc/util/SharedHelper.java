package com.workday.cc.util;

import java.util.Map;

import com.capeclear.mediation.MediationContext;
import com.workday.esb.intsys.ParsedIntegrationSystems;
import com.workday.esb.intsys.TypedValue;

/**
 * Utility class providing static helper methods which may be invoked from MVEL in assemblies
 * 
 * @author Doug Lee
 */
public class SharedHelper {

    /**
     * For each integration attribute create a MediationContext property named with an attr_ prefix and with each whitespace in the attribute name
     * converted to an underscore.  This is the same behaviour as that implemented by Document Transform.
     * 
     * In order to use this helper class you would use the MVEL expression com.workday.cc.util.SharedHelper.attributesToProperties(context)
     * 
     * @param intsys An instance of MediationContext, for example that the context MVEL helper object
     */

    public static void attributesToProperties(final MediationContext context) {
        final ParsedIntegrationSystems intsys = (ParsedIntegrationSystems) context.getProperty(ParsedIntegrationSystems.INTEGRATION_SYSTEM_PROPERTY);
        final Map<String, TypedValue> attributeMap = intsys.getAttributes();
        for (final String name : attributeMap.keySet()) {
            context.setProperty("attr_" + name.replaceAll("\\s+", "_"), attributeMap.get(name).getTextValue());
        }
    }
}

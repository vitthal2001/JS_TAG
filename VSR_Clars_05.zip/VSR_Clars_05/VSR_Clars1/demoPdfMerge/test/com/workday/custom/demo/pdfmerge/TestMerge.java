package com.workday.custom.demo.pdfmerge;

import com.capeclear.logger.LogControl;
import com.capeclear.logger.Logger;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.MediationMessage;
import com.workday.aunit.AssemblyTestCase;
import com.workday.aunit.actions.Action;
import com.workday.aunit.actions.Action.Type;
import com.workday.aunit.actions.StandardAction;
import com.workday.aunit.annotations.AssemblyTest;
import com.workday.aunit.annotations.AssertAfterCompletion;
import com.workday.aunit.annotations.AtComponent;
import com.workday.aunit.annotations.UnitTest;


@AssemblyTest(project="demoPdfMerge", displayLabel="Demo of merging PDFs")
public class TestMerge extends AssemblyTestCase {
	Logger log = LogControl.getLogger( getClass() );

	@UnitTest(startComponent="In")
	public void testMerge() {
		
	}

	@AtComponent(id="MergePDFs", step="Store")
	public Action mockStore() {
		return new StandardAction( Type.mock );
	}
	
	/*@AtComponent( id="PutIntegrationMessage" )
	public Action mockPIM() {
		return new StandardAction( Type.mock );
	}*/
	
	@AssertAfterCompletion
	public void validateNoErrors() throws Exception {
		MediationContext ctx = getMediationContext();
		if ( !ctx.isErrorHandled() ) {
			Throwable t = ctx.getException();
			if ( t != null ) {
				log.error("An unhandled error occurred", t);
			}
			assertNull(t);
		}

		MediationMessage msg = ctx.getMessage();
		assertEquals( "Mimetype is not correct", "application/pdf", msg.getMimeType(0) );
		
		//
		// Message length should be ~44k
		//
		
		assertTrue("Message is too short", msg.getLength() > 40000 );
		

		
	}
}

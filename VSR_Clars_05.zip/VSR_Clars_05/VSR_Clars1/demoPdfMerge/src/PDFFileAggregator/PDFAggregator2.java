package PDFFileAggregator;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;

import com.capeclear.logger.LogControl;
import com.capeclear.logger.Logger;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.MediationException;
import com.capeclear.mediation.MessageContextVariables;
import com.capeclear.mediation.impl.cc.MediationTube;

public class PDFAggregator2 {

    private static final Logger LOG = LogControl.getLogger(PDFAggregator2.class);

    static final String OTHER_VAR_NAME = "PDFOutputFile.pdf";

    public void process(InputStream input, OutputStream output) throws MediationException, IOException {
        // TODO implement
        LOG.info(
                "Beginning to extract information from the MediationContext to bridge to the Java business service object...");

        try {

            PDFMergerUtility PDFmerger = new PDFMergerUtility();
            
            MediationContext ctx = MediationTube.getCurrentMediationContext();
            MessageContextVariables vars = ctx.getVariables();
            if ( !vars.isVariable("PDFOutputFile.pdf") ) {
            		throw new RuntimeException("Variable \"" + OTHER_VAR_NAME + "\" is not populated");
            }
            

            PDFmerger.addSource(input);
            PDFmerger.addSource( vars.get("PDFOutputFile.pdf").getInputStream() );
            PDFmerger.setDestinationStream( output );
            //
            // For test purposes allow 1GB of main memory to be used for PDF merge functionality
            //
            
            PDFmerger.mergeDocuments( MemoryUsageSetting.setupMixed( 1024*1024*1024 ) );


        } catch (RuntimeException r_e) {
        		throw r_e;
        }
        catch ( Exception e) {
        		final String err_msg = "An error occurred merging the PDF documents";
        		LOG.error(err_msg, e);
            throw new RuntimeException(err_msg, e);
        }

    }

}
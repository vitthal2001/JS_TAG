package com.workday.custom.aunit.int19073.utilities.ssk109;

public interface IFlexLogTestResourceLoader {

	public void loadFileToVariable(String variable, String fileResouce, String contentType) throws Throwable;
}

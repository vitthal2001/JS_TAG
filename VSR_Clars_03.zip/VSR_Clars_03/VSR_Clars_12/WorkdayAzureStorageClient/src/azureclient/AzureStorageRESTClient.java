package azureclient;

import static com.capeclear.assembly.annotation.Component.Type.outtransport;

import java.io.InputStream;
import java.net.URI;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.http.Header;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.mvel.MVEL;

import com.capeclear.assembly.AssemblyContext;
import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import com.capeclear.assembly.annotation.Property.Edit;
import com.capeclear.assembly.aware.AssemblyContextAware;
import com.capeclear.assembly.impl.AssemblyUtils;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.MediationException;

/**
 */
@Component(name = "AzureStorageRESTClient", type = outtransport, toolTip = "Microsoft Azure Storage REST Client", scope = "prototype", smallIconPath = "icons/AzureStorageRESTClient_16.png", largeIconPath = "icons/AzureStorageRESTClient_24.png")
public class AzureStorageRESTClient implements AssemblyContextAware {

	public static final String AZURE_STORAGE_VERSION = "2018-03-28";

	public static final DateTimeFormatter ISO8061_DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	public static final DateTimeFormatter ISO8061_DATE_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssX");
	//DateTimeFormatter.RFC_1123_DATE_TIME does not pad the date as required by Azure
	public static final DateTimeFormatter RFC1123_DATE_TIME = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy HH:mm:ss z");

	private AssemblyContext assemblyContext;
	private Method method;
	private String accountName;
	private String accountKey;
	private AuthMode authMode = AuthMode.STANDARD;

	public String getMethod() {
		return method != null ? method.name() : null;
	}

	@Property(name = "method", edit = Edit.DEFAULT)
	public void setMethod(String method) {
		this.method = method != null ? Method.valueOf(method.toUpperCase()) : null;
	}

	public String getAccountName() {
		return accountName;
	}

	@Property(name = "accountName", edit = Edit.DEFAULT)
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountKey() {
		return accountKey;
	}

	@Property(name = "accountKey", edit = Edit.DEFAULT)
	public void setAccountKey(String accountKey) {
		this.accountKey = accountKey;
	}

	public String getAuthMode() {
		return authMode != null ? authMode.name() : null;
	}

	@Property(name = "authMode", edit = Edit.DEFAULT)
	public void setAuthMode(String authMode) {
		this.authMode = authMode != null ? AuthMode.valueOf(authMode.toUpperCase()) : null;
	}

	@ComponentMethod
	public void process(MediationContext context) {
		try {
			URI dynEndpoint = context.getDynamicEndpointURI();
			if (method == null) {
				throw new MediationException("method not set");
			}

			if (accountName == null || accountName.isEmpty()) {
				throw new MediationException("accountName not set");
			}

			if (accountKey == null || accountKey.isEmpty()) {
				throw new MediationException("accountKey not set");
			}

			//System.out.println("Method: " + method + " URL: " + dynEndpoint);

			HttpRequestBase request = null;
			switch (method) {
			case GET:
				request = new HttpGet(dynEndpoint);
				break;
			case POST:
				request = new HttpPost(dynEndpoint);
				InputStream contents = (InputStream) context.getMessage().getMessagePart(0, java.io.InputStream.class);
				String mimeType = context.getMessage().getMimeType(0);
				((HttpPost) request).setEntity(new InputStreamEntity(contents, context.getMessage().getLength(0), ContentType.create(mimeType)));
				break;
			case PUT:
				request = new HttpPut(dynEndpoint);
				contents = (InputStream) context.getMessage().getMessagePart(0, java.io.InputStream.class);
				mimeType = context.getMessage().getMimeType(0);
				((HttpPut) request).setEntity(new InputStreamEntity(contents, context.getMessage().getLength(0), ContentType.create(mimeType)));
				break;
			case DELETE:
				request = new HttpDelete(dynEndpoint);
				break;
			default:
				throw new MediationException("Unsupported method " + method);
			}
			setHeaders(context, request);
			configureRequest(context, request);

			DefaultHttpClient httpClient = new DefaultHttpClient();

			HttpResponse response = httpClient.execute(request);

			//System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
			context.setProperty("http.response.status", String.valueOf(response.getStatusLine().getStatusCode()));
			if (response.getEntity() != null && response.getEntity().getContentType() != null) {
				context.getMessage().setMessagePart(0, response.getEntity().getContentType().getValue(), response.getEntity().getContent());
			} else {
				context.getMessage().setMessagePart(0, "text/plain", "");
			}

			if (response.getStatusLine().getStatusCode() >= 400) {
				throw new MediationException(String.format("Status Code: %d Message: %s", response.getStatusLine().getStatusCode(), response.getStatusLine().getReasonPhrase()));
			}

		} catch (Exception e) {
			throw new MediationException("AzureRESTClient Error", e);
		}
	}

	private void setHeaders(MediationContext context, HttpRequestBase request) {
		for (Iterator<String> i = context.getMessage().getHeaderNameIterator(); i.hasNext();) {
			String name = i.next();
			request.setHeader(name, context.getMessage().getHeader(name));
		}
	}

	private void configureRequest(MediationContext context, HttpUriRequest request) throws NoSuchAlgorithmException, InvalidKeyException {
		Map<String, Object> vars = AssemblyUtils.createMediationExpressionContextWithAssembly(context, getAssemblyContext());
		String accountNameValue = MVEL.evalToString(accountName, vars);
		String accountKeyValue = MVEL.evalToString(accountKey, vars);

		URIBuilder builder = new URIBuilder(request.getURI());

		ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.of("GMT"));
		String date = RFC1123_DATE_TIME.format(currentTime);

		request.setHeader("x-ms-date", date);
		request.setHeader("x-ms-version", AZURE_STORAGE_VERSION);

		StringBuilder stringToSign = new StringBuilder();

		if (authMode == AuthMode.STANDARD) {
			stringToSign.append(method).append("\n");
			stringToSign.append("\n"); //No Content-MD5
			String contentType = "";
			if (request instanceof HttpEntityEnclosingRequest) {
				contentType = ((HttpEntityEnclosingRequest) request).getEntity().getContentType().getValue();
			}
			stringToSign.append(contentType.trim()).append("\n");
			stringToSign.append("\n"); //No Date
			canonicalizeHeaders(stringToSign, request.getAllHeaders()); //CanonicalizedHeaders
			stringToSign.append("/").append(accountNameValue);
			if (builder.getPath() != null) {
				stringToSign.append(builder.getPath());
			}
			canonicalizeParameters(stringToSign, builder.getQueryParams());
		} else if (authMode == AuthMode.TABLE) {
			stringToSign.append(date).append("\n");
			stringToSign.append("/").append(accountNameValue);
			if (builder.getPath() != null) {
				stringToSign.append(builder.getPath());
			}
		}
		Mac sha256_HMAC = Mac.getInstance("HMACSHA256");
		SecretKeySpec secret_key = new SecretKeySpec(Base64.getDecoder().decode(accountKeyValue), "HmacSHA256");
		sha256_HMAC.init(secret_key);
		String signature = Base64.getEncoder().encodeToString(sha256_HMAC.doFinal(stringToSign.toString().getBytes()));
		request.setHeader("Authorization", String.format("SharedKeyLite %s:%s", accountNameValue, signature));
	}

	private void canonicalizeHeaders(StringBuilder stringToSign, Header[] headers) {
		//convert to header names to lowercase
		//TODO see if it is possible for Apache HTTPClient to support more than one header value. If so multiple values should be joined with - character
		Map<String, String> lc = Stream.of(headers).collect(Collectors.toMap(h -> h.getName().toLowerCase(), h -> h.getValue()));

		lc.entrySet().stream().filter(h -> h.getKey().startsWith("x-ms-")).sorted((e1, e2) -> e1.getKey().compareTo(e2.getKey())).forEach(h -> {
			stringToSign.append(h.getKey()).append(":");
			//TODO should replace non-quoted linear whitespace (return/line feed (CRLF), spaces, and tabs) with a single space. This should be controlled in the assembly and not handled here. 
			if (h.getValue() != null) {
				stringToSign.append(h.getValue().trim());
			}
			stringToSign.append("\n");
		});
	}

	private void canonicalizeParameters(StringBuilder stringToSign, List<NameValuePair> params) {
		Map<String, String> lc = params.stream().collect(Collectors.toMap(p -> p.getName(), p -> p.getValue(), (p1, p2) -> p1 + "-" + p2));
		if (lc.containsKey("comp")) {
			stringToSign.append("?comp=").append(lc.get("comp"));
		}

	}

	@Override
	public AssemblyContext getAssemblyContext() {
		return this.assemblyContext;
	}

	@Override
	public void setAssemblyContext(AssemblyContext assemblyContext) {
		this.assemblyContext = assemblyContext;
	}

	private static enum Method {
		GET, POST, PUT, DELETE;
	}

	private static enum AuthMode {
		STANDARD, TABLE;
	}

}

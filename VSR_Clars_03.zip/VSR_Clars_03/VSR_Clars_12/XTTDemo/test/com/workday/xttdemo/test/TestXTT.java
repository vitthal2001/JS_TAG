package com.workday.xttdemo.test;

import javax.xml.transform.stream.StreamSource;

import com.capeclear.logger.LogControl;
import com.capeclear.logger.Logger;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.MediationMessage;
import com.workday.aunit.AssemblyTestCase;
import com.workday.aunit.actions.Action;
import com.workday.aunit.actions.Action.Type;
import com.workday.aunit.actions.StandardAction;
import com.workday.aunit.annotations.AssemblyTest;
import com.workday.aunit.annotations.AssertAfterCompletion;
import com.workday.aunit.annotations.AtComponent;
import com.workday.aunit.annotations.UnitTest;
import com.workday.mediation.impl.mediators.etv.ETVInfo;
import com.workday.mediation.impl.mediators.etv.ETVInfoCollection;

/**
 * Basic test of functionality:  ensure that earnings are reordered correctly for the case in which all earnings have priorities mapped in the integration map
 * 
 * @author Doug Lee
 */

@AssemblyTest(project="XTTDemo", displayLabel="Test of XTT processing")
public class TestXTT extends AssemblyTestCase {
	
	Logger log = LogControl.getLogger( TestXTT.class ) ;
	

	@UnitTest(startComponent="Transform",startStep="XsltPlus")
	public void testXsltAndXtt() throws Exception {
		this.setMessagePart(0, "test/GetWorkers.xml", "text/xml");
	}
	
	@AtComponent(id="ReportXformError")
	public Action terminateOnError() {
		return StandardAction.create(Type.terminate);
	}
	
	@AtComponent(id="ReportXTTError")
	public Action terminateOnXTTError() {
		return StandardAction.create(Type.terminate);
	}
	
	@AtComponent(id="ReportXTTMessages")
	public Action mockMessageReporting() {
		return StandardAction.create(Type.mock);
	}

	@AssertAfterCompletion
	public void validateOutput() throws Exception {
		
		MediationContext ctx = getMediationContext();
		Throwable t = ctx.getException();
		
		if (t != null ) {
			log.error("Error occurred", t);
		}
		
		assertNull("Unexpected exception", t);

		MediationMessage msg = ctx.getMessage();
		@SuppressWarnings("unchecked")
		StreamSource root_source = (StreamSource)msg.getRootPart(new Class[] {StreamSource.class});

		//
		// Validate that the document output is as expected
		//
		
		assertTrue("Document is incorrectly transformed", compare( getTestResourceInputStream("test/ExpectedOutput.txt"), "text/plain", root_source.getInputStream(), msg.getMimeType(0), Comparator.text) );
		
		//
		// Test that the messages are generated as expected
		//
		
		Object o_etvmsgs = ctx.getProperty( "etv.messages" );
		assertTrue("Property etv.messages does not contain an ETVInfoCollection object", o_etvmsgs instanceof ETVInfoCollection );
		
		ETVInfoCollection messages = (ETVInfoCollection)o_etvmsgs;
		//
		// Iterate over the collection - we should only have a single entry
		//
		
		int count = 0;
		for(ETVInfo info:messages) {
			//
			// First message should target employee 21003 WID 3895af7993ff4c509cbea2e1817172e0
			if ( ++count == 1 ) {
				assertEquals( "Message is incorrectly targetted", "3895af7993ff4c509cbea2e1817172e0", info.getTargetWID() );
			}
		}
		assertEquals("Unexpected number of INFO messages", 1, messages.getCurrentNumInfo() );
		assertEquals("Unexpected number of WARNING messages", 1, messages.getCurrentNumWarnings() );
		assertFalse("Error messages were generated", messages.hasError() );
		assertFalse("Critical messages were generated", messages.hasCritical() );
	}
	
}

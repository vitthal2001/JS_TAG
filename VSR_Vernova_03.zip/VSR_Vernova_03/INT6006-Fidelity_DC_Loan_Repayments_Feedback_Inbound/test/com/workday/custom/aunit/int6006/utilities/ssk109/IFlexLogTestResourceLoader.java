package com.workday.custom.aunit.int6006.utilities.ssk109;

public interface IFlexLogTestResourceLoader {

	public void loadFileToVariable(String variable, String fileResouce, String contentType) throws Throwable;
}

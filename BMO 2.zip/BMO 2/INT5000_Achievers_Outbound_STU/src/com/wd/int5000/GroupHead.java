package com.wd.int5000;

public class GroupHead {
	
	public String departmentID;
	public String departmentDescription;
	public String groupHeadEIN;
	public String groupHeadOwner;

	public GroupHead(String departmentID, String departmentDescription, String groupHeadEIN, String groupHeadOwner) {
	super();
	  this.departmentID = departmentID;
	  this.departmentDescription = departmentDescription;
	  this.groupHeadEIN = groupHeadEIN;
	  this.groupHeadOwner = groupHeadOwner;
	}

	public String getDepartmentID() {
	return departmentID;
	}
	public void setDepartmentID(String departmentID) {
	this.departmentID = departmentID;
	}
	public String getDepartmentDescription() {
	return departmentDescription;
	}
	public void setDepartmentDescription(String departmentDescription) {
	this.departmentDescription = departmentDescription;
	}
	public String getGroupHeadEIN() {
	return groupHeadEIN;
	}
	public void setGroupHeadEIN(String groupHeadEIN) {
	this.groupHeadEIN = groupHeadEIN;
	}
	public String getGroupHeadOwner() {
	return groupHeadOwner;
	}
	public void setGroupHeadOwner(String groupHeadOwner) {
	this.groupHeadOwner = groupHeadOwner;
	}

	}
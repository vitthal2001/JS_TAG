package com.wd.int5000;

public class Executive {

	public String firstName;
	  public String lastName;
	  public String bmoCommunityId;
	  public String lobId;
	  public String lobDescr;
	  public String communityId;
	  public String communityDescr;
	  public String leaderLed;
	  public String leaderLedId;

	  public String EIN;

	public Executive(String firstName, String lastName, String bmoCommunityId, String lobId, String lobDescr,
	String communityId, String communityDescr, String leaderLed, String leaderLedId, String eIN) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.bmoCommunityId = bmoCommunityId;
	this.lobId = lobId;
	this.lobDescr = lobDescr;
	this.communityId = communityId;
	this.communityDescr = communityDescr;
	this.leaderLed = leaderLed;
	this.leaderLedId = leaderLedId;
	EIN = eIN;
	}

	public String getEIN() {
	return EIN;
	}
	public void setEIN(String eIN) {
	EIN = eIN;
	}
	public String getFirstName() {
	return firstName;
	}
	public void setFirstName(String firstName) {
	this.firstName = firstName;
	}
	public String getLastName() {
	return lastName;
	}
	public void setLastName(String lastName) {
	this.lastName = lastName;
	}
	public String getBmoCommunityId() {
	return bmoCommunityId;
	}
	public void setBmoCommunityId(String bmoCommunityId) {
	this.bmoCommunityId = bmoCommunityId;
	}
	public String getLobId() {
	return lobId;
	}
	public void setLobId(String lobId) {
	this.lobId = lobId;
	}
	public String getLobDescr() {
	return lobDescr;
	}
	public void setLobDescr(String lobDescr) {
	this.lobDescr = lobDescr;
	}
	public String getCommunityId() {
	return communityId;
	}
	public void setCommunityId(String communityId) {
	this.communityId = communityId;
	}
	public String getCommunityDescr() {
	return communityDescr;
	}
	public void setCommunityDescr(String communityDescr) {
	this.communityDescr = communityDescr;
	}
	public String getLeaderLed() {
	return leaderLed;
	}
	public void setLeaderLed(String leaderLed) {
	this.leaderLed = leaderLed;
	}
	public String getLeaderLedId() {
	return leaderLedId;
	}
	public void setLeaderLedId(String leaderLedId) {
	this.leaderLedId = leaderLedId;
	}
}

function stripslashes (msg) {
  return (msg).replace(/\//g, ' ');
}

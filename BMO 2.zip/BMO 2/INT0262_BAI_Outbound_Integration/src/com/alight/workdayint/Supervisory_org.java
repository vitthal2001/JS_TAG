package com.alight.workdayint;

public class Supervisory_org {
	
	public String org_id;
	public String org_name;
	public String org_wid;
	public String parent_org_wid;
	public String parent_org_id;
	public String parent_org_name;
	public Supervisory_org(String org_wid, String org_id, String org_name, String parent_org_wid, String parent_org_id,
			String parent_org_name) {
		super();
		this.org_id = org_id;
		this.org_name = org_name;
		this.org_wid = org_wid;
		this.parent_org_wid = parent_org_wid;
		this.parent_org_id = parent_org_id;
		this.parent_org_name = parent_org_name;
	}
	public String getOrg_id() {
		return org_id;
	}
	public void setOrg_id(String org_id) {
		this.org_id = org_id;
	}
	public String getOrg_name() {
		return org_name;
	}
	public void setOrg_name(String org_name) {
		this.org_name = org_name;
	}
	public String getOrg_wid() {
		return org_wid;
	}
	public void setOrg_wid(String org_wid) {
		this.org_wid = org_wid;
	}
	public String getParent_org_wid() {
		return parent_org_wid;
	}
	public void setParent_org_wid(String parent_org_wid) {
		this.parent_org_wid = parent_org_wid;
	}
	public String getParent_org_id() {
		return parent_org_id;
	}
	public void setParent_org_id(String parent_org_id) {
		this.parent_org_id = parent_org_id;
	}
	public String getParent_org_name() {
		return parent_org_name;
	}
	public void setParent_org_name(String parent_org_name) {
		this.parent_org_name = parent_org_name;
	}
	
	
	

}

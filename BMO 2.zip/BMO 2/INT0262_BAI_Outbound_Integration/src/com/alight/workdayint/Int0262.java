package com.alight.workdayint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Int0262 {
	public static HashMap orgsWithParent;
	public static HashMap orgsWithName;
	public static String  setMaps(java.util.HashMap a, java.util.HashMap b){
		orgsWithName = a;
		orgsWithParent = b;
		return "set";
	}
	
	
public static String    getHierarcyById(String origId){
		ArrayList a = new ArrayList();
		ArrayList b = new ArrayList();
		boolean skip = false;
		String cOrg=origId;
		while(!skip){
			a.add(cOrg);
			b.add(orgsWithName.get(cOrg));
			if(orgsWithParent.get(cOrg) != null)	
			{   
				cOrg = (String)orgsWithParent.get(cOrg);
				
			}else{
				skip = true;
			}
		}
		String hierarchy="";
		String hierarchyname="";
		for(int i=a.size();i>0;i--){
			
			if(i==a.size()){
				hierarchy = (String)a.get(i-1);
				hierarchyname = (String)b.get(i-1);
				
			}else{
				hierarchy = hierarchy + "|" + (String)a.get(i-1);
				hierarchyname = hierarchyname + "|" + (String)b.get(i-1);
			}
			
			
		}
		return hierarchy;
	}
	
	
     public static String   getHierarcyByName(String origId){
		ArrayList a = new ArrayList();
		ArrayList b = new ArrayList();
		boolean skip = false;
		String cOrg=origId;
		
		while(!skip){
			a.add(cOrg);
			b.add(orgsWithName.get(cOrg));
			if(orgsWithParent.get(cOrg) != null)	
			{   
				cOrg = (String)orgsWithParent.get(cOrg);
				
			}else{
				skip = true;
			}
		}
		
		String hierarchy="";
		String hierarchyname="";
		
		for(int i=a.size();i>0;i--){
			if(i==a.size()){
				hierarchy = (String)a.get(i-1);
				hierarchyname = (String)b.get(i-1);
			}else{
				hierarchy = hierarchy + "|" + (String)a.get(i-1);
				hierarchyname = hierarchyname + "|" + (String)b.get(i-1);
			}
			
		}
		
		
		
		return hierarchyname;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
		
        HashMap orgsWithParent;
		HashMap orgsWithName;
		
		orgsWithName= new HashMap();
		//orgsWithName= Class.forName("HashMap<String,String>");
		
		orgsWithName.put("orgTopLeve1","Very Top Sup Org");
		orgsWithName.put("orgMiddleLeve1","Next to Tep Level");
		orgsWithName.put("orgMiddleLeve2","Middle Level");
		orgsWithName.put("orgMiddleBottom","Bottom Level");
		orgsWithName.put("orgMiddleLeve3","org Middle Leve3");
	    
	     orgsWithParent= new HashMap();
				
	     orgsWithParent.put("orgMiddleBottom","orgMiddleLeve2");
	     orgsWithParent.put("orgMiddleLeve2","orgMiddleLeve1");
	     orgsWithParent.put("orgMiddleLeve1","orgTopLeve1");
	     orgsWithParent.put("orgMiddleLeve3","orgTopLeve1");
	     orgsWithParent.put("orgTopLeve1", null);

	     setMaps(orgsWithName,orgsWithParent);
	     
	     
         String s = "orgMiddleLeve3";
         String sdesc = "org Middle Leve3";
    
         
         System.out.println(getHierarcyById(s)); 
         System.out.println(getHierarcyByName(s));
 
	}
	
	
	
	
}

package com.wd.dart.test;

import com.workday.aunit.AssemblyTestCase;
import com.workday.aunit.annotations.AssemblyTest;
import com.workday.aunit.annotations.AssertAfterCompletion;
import com.workday.aunit.annotations.AssertBefore;
import com.workday.aunit.annotations.UnitTest;

//import javafx.beans.property.SetProperty;

@AssemblyTest(project = "DART-HCM", displayLabel = "Demonstrates using the AssertAfterCompletion annotation e.g. to verify error handling logic")

public class DARTTester extends AssemblyTestCase {
	public void MockDocumentRetrievalTest() {
    }
    
    @UnitTest(startComponent="WriteCSVToExcelWorkbook",startStep="WriteToDARTWorkbook")
    public void testWorkdayIn0() throws Exception {
    	
    	setMessagePart(0, "test/TesterFie.csv", "text/csv");
    	
   	
    	//setVariable("wd.retrieve.variable", "test/Incoming-1.xml", "text/xml");
    	//setIntegrationSystem(intSysResponseResourcePath)
    }
    /*
    @AssertBefore(id="ProcessEachWorker")
	public void verifySummaryDoc() throws Exception {
    	System.out.println(evaluateExpression("parts[0].xpath('count(/summary/wd:WorkerSummary)')"));
    	
    	assertEquals("10", evaluateExpression("parts[0].xpath('count(/summary/wd:WorkerSummary)')"));
	}
    */
    @AssertAfterCompletion
    public void verifyFinish() throws Exception {
        
        //assertEquals("ok", getMediationContext().getProperty("verify.this"));
    	String ExcelFile = getMediationContext().getVariables().get("v.dart.workbook").toString();
    	System.out.println(ExcelFile.length());
    }
    
    

}

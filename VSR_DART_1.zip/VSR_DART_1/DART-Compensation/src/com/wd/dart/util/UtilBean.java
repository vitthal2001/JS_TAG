package com.wd.dart.util;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.workday.esb.intsys.ParsedIntegrationSystems;

public class UtilBean {
	
	/**
	 * All time tracking countries code attributes and day attributes must be named by the pattern of the following prefix plus the index, such as
	 * Use Time Tracking in Country 1, 1st Day Use Time Tracking in Country 1; 
	 * Use Time Tracking in Country 2, 1st Day Use Time Tracking in Country 2. 
	 * So addtional countries' attributes can be added to the integration attribute list minimum code change. 
	 */
	final static String TIME_TRACKING_COUNTRY_PROPERTY_STEM = "Use Time Tracking in Country ";
	final static String TIME_TRACKING_COUNTRY_FIRST_DAY_PROPERTY_STEM = "1st Day Use Time Tracking in Country ";
	
	/**
	 * Returns the string of a date that is varied 'vary' days from today. 
	 * @param vary	the varied days from today. It can be positive and negative
	 * @return	a date string in the format 'yyyy-MM-dd'
	 */
	public String getDateStringVariedFromToday(int vary){
		String variedStr = null;
		GregorianCalendar cal = new GregorianCalendar();	
		cal.add(Calendar.DATE, vary);
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		variedStr = dateFormatter.format(cal.getTime());
		
		return variedStr;
	}
	
	/**
	 * Returns the string of the first day of the current year in the format 'yyyy-MM-dd'
	 * @return
	 */
	public String getCurrentYearFirstDateString(){
		String firstDateStr = "";
		GregorianCalendar cal = new GregorianCalendar();
		cal = new GregorianCalendar(cal.get(Calendar.YEAR), 0, 1);
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		firstDateStr = dateFormatter.format(cal.getTime());
		return firstDateStr;
	}
	
	/**
	 * Return the time tracking countries code and 1st day of using time tracking in the pattern of 
	 * country_code:1st_day_using_time_tracking|country_code:1st_day_using_time_tracking|.....
	 * Assume the attributes of time tracking countries and days are being configured in index order, and not case of using "Time Tracking in Country 1" and 
	 * "Time Tracking in Country 3", and skip "Time Tracking in Country 2"
	 * @param medCtx
	 * @return countriesCodeNDay string list.
	 */
	public String getTTCountriesCodesNDays (ParsedIntegrationSystems intsys){
		String countriesCodeNDays = "";
		int index = 1;
		String countryCode;
		String countryDay;
		do{
			countryCode = intsys.getAttributeReferenceData(TIME_TRACKING_COUNTRY_PROPERTY_STEM + index, "ISO_3166-1_Alpha-3_Code");
			countryDay = intsys.getAttribute(TIME_TRACKING_COUNTRY_FIRST_DAY_PROPERTY_STEM + index);
			if(countryCode != null && countriesCodeNDays.isEmpty()){
				countriesCodeNDays = countryCode + ":" + countryDay;
			}
			else if(countryCode != null){
				countriesCodeNDays += "|" + countryCode + ":" + countryDay;				
			}
			
			index += 1;
			
		}while(countryCode != null);
		
		
		return countriesCodeNDays;
	}
}


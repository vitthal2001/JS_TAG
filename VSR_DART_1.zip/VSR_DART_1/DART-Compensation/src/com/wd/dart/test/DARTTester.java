package com.wd.dart.test;

import com.workday.aunit.AssemblyTestCase;

public class DARTTester extends AssemblyTestCase {

}

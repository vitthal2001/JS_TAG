package test;

public class TestIntInfo {

}

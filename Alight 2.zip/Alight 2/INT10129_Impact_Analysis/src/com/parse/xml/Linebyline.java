package com.parse.xml;

import static com.capeclear.assembly.annotation.Component.Type.mediation;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.xml.stream.XMLStreamWriter;
import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.logger.LogControl;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
import com.capeclear.xml.utils.XmlUtils;


/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "Linebyline",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/Linebyline_16.png",
        largeIconPath = "icons/Linebyline_24.png"
        )
public class Linebyline {

    /**
     * This method is called by the Assembly framework.
     *
     * Use the <code>MediationContext</code> to access objects in the context,
     * such as the message, properties and variables e.g.
     * <ul>
     * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
     * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
     * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
     * </ul>    
     */
    @ComponentMethod
    public void process(java.io.InputStream input, java.io.OutputStream out) {
    	
    	MediationContext ctx = MediationTube.getCurrentMediationContext();
    	
    	try ( BufferedReader r = new BufferedReader( new InputStreamReader(input)))
    	{
    	List<String> results = new ArrayList<String>();	
    	XMLStreamWriter writer = XmlUtils.getXMLOutputFactory().createXMLStreamWriter( out );

    	String word = ctx.getProperty("Search_word").toString().toLowerCase();
    	String File_name = ctx.getProperty("p.file.name").toString();
    	String Int_name = ctx.getProperty("p.int.sys.name").toString();
    	String Delimiter = ctx.getProperty("Delim").toString();
    	
    	
    	
    	String buffline = r.readLine();
         while (buffline != null) {
             results.add(buffline);
             buffline = r.readLine();
         }
         
         int count = 0;
         writer.writeStartElement("Lines");
         for (String num : results) { 
        	 count = count + 1;
        	 if (num.toLowerCase().contains(word) 
            	     && 
            	     num !=null 
            	     &&
            	     ((File_name.contains(".java") && !(num.toLowerCase().contains("//")))
            	     ||
            	     (!(File_name.contains(".java")) && !(num.toLowerCase().contains("<xsl:stylesheet")) && !(num.toLowerCase().contains("<?xml version")) && !(num.toLowerCase().contains("http://")) && !(num.toLowerCase().contains("urn:com.workday")) && !(num.toLowerCase().contains("<!--")) && !(num.toLowerCase().contains("-->"))))
            	     )
        	 {        
        		 String Replaced_delim = num.replaceAll(Delimiter, "");
        		 writer.writeStartElement("Line_Details");
        		    writer.writeStartElement("Int_Name");
						writer.writeCharacters(Int_name);
				    writer.writeEndElement();
				    writer.writeStartElement("File_Name");
						writer.writeCharacters(File_name);
				    writer.writeEndElement();
					writer.writeStartElement("Line_Content");
						writer.writeCharacters(Replaced_delim.replaceAll("\\s+", " "));
					writer.writeEndElement();
					writer.writeStartElement("Line_No");
						writer.writeCharacters(String.valueOf(count));
				    writer.writeEndElement();
					writer.writeStartElement("Search_Word");
						writer.writeCharacters(word);
				    writer.writeEndElement(); 
				writer.writeEndElement();  				
        	 }        	 
         }
         writer.writeEndElement();
         writer.flush();
 		 writer.close();
		
    	}
    	catch (Exception e) {
    		String err_msg = "An error occurred converting the file to text: " + e.getMessage();
			LogControl.getLogger( getClass() ).error(err_msg, e);
			throw new RuntimeException(err_msg, e);
		}
    }
}

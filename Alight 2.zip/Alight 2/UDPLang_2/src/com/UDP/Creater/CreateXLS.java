package com.UDP.Creater;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;

import static com.capeclear.assembly.annotation.Component.Type.*;

/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
		name = "CreateXLS",
		type = mediation,
		toolTip = "",
		scope = "prototype",
		smallIconPath = "icons/CreateXLS_16.png",
		largeIconPath = "icons/CreateXLS_24.png"
		)
public class CreateXLS {

	/**
	 * This method is called by the Assembly framework.
	 *
	 * Use the <code>MediationContext</code> to access objects in the context,
	 * such as the message, properties and variables e.g.
	 * <ul>
	 * <li><code>InputStream input is the input value from custom component</code></li>
	 * <li><code>OutputStream output is the output value to the custom component</code></li>
	 * </ul>    
	 */

	@ComponentMethod
	public void process( java.io.InputStream input, java.io.OutputStream output ) {

		try {
			ArrayList<ArrayList<String>> arList=null;
			ArrayList<String> arl=null;
			BufferedReader myInput = null;
			//	String fName = "abc.csv";
			String thisLine;
			myInput = new BufferedReader(new InputStreamReader(input));
			int i=0;
			arList = new ArrayList<ArrayList<String>>();
			while ((thisLine = myInput.readLine()) != null)
			{
				arl = new ArrayList<String>();
				String arrSpl[] = thisLine.split("\\|");
				for(int j=0;j<arrSpl.length;j++)
				{
					arl.add(arrSpl[j]);
				}
				arList.add(arl);
				i++;
			}
			myInput.close();

			WritableWorkbook workbook = Workbook.createWorkbook(output);
			WritableSheet sheet=workbook.createSheet("Sheet1", 0);
			for(int k=0;k<arList.size();k++)
			{
				ArrayList<String> ardata = (ArrayList<String>)arList.get(k);
				for(int p=0;p<ardata.size();p++)
				{
					String data = ardata.get(p).toString();
					if(data.startsWith("=")){
						data=data.replaceAll("\"", "");
						data=data.replaceAll("=", "");
						sheet.addCell(new Label(p, k, data));
					}else if(data.startsWith("\"")){
						data=data.replaceAll("\"", "");
						sheet.addCell(new Label(p, k, data));
					}else{
						data=data.replaceAll("\"", "");
						sheet.addCell(new Label(p, k, data));
					}
				}
			}
			workbook.write();
			workbook.close();
			output.flush();
			output.close();
		}
		catch (WriteException we) {
			we.printStackTrace();
		}
		catch (IOException io_e) {
			io_e.printStackTrace();
		}
		catch ( Exception e ) {
			e.printStackTrace();
		}
	}
}

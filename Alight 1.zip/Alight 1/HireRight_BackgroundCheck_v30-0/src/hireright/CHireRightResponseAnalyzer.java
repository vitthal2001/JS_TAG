/*
 * @(#)$RCSfile: ?,v $
 * $Revision: ? $
 * $Date: ? $
 * $Author: ? $
 * $Source: ?,v $
 *
 * Copyright 2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	D.Onischenko	2015-03-20	Created
 */

package hireright;

/**
 * @author donischenko
 * @version $Revision: ? $
 * @source $Source: ?,v $
 */

import javax.xml.transform.dom.DOMSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.MediationMessage;
import org.apache.log4j.Logger;
import org.w3c.dom.Node;

@Component
	(
		name = "CHireRightResponseAnalyzer"
		, type = Component.Type.mediation
		, toolTip = ""
		, scope = "singleton"
		, smallIconPath = "icons/CHireRightResponse_16.png"
		, largeIconPath = "icons/CHireRightResponse_24.png"
	)
public class CHireRightResponseAnalyzer
{
	private static final Logger LOGGER = Logger.getLogger(CHireRightResponseAnalyzer.class);

	@SuppressWarnings("unused")
	protected static final String CLASS_VERSION = "$Revision: ? $ $Author: ? $";

	private static final String ERROR_CALLING_HIRE_RIGHT_WEB_SERVICE = "Error calling HireRight web service";
	private static final String OK = "OK";

	private static final Class[] ROOT_PART = {DOMSource.class};

	@ComponentMethod
	public void process(MediationContext mediationContext)
	{
		try
		{
			if (mediationContext == null)
			{
				LOGGER.error("MediationContext missing");
				throw new CException(ERROR_CALLING_HIRE_RIGHT_WEB_SERVICE);
			}

			MediationMessage message = mediationContext.getMessage();
			if (message == null)
			{
				LOGGER.error("MediationMessage missing");
				throw new CException(ERROR_CALLING_HIRE_RIGHT_WEB_SERVICE);
			}

			@SuppressWarnings("unchecked")
			DOMSource domSource = (DOMSource) message.getRootPart(ROOT_PART);
			if (domSource == null)
			{
				LOGGER.error("DOMSource missing");
				throw new CException(ERROR_CALLING_HIRE_RIGHT_WEB_SERVICE);
			}

			Node node = domSource.getNode();
			if (node == null)
			{
				LOGGER.error("Node missing");
				throw new CException(ERROR_CALLING_HIRE_RIGHT_WEB_SERVICE);
			}

			XPathFactory xPathFactory = XPathFactory.newInstance();
			XPath xPath = xPathFactory.newXPath();
			String sStatus = evaluateXPathString(xPath, node, "/HireRightResponse/Status");

			if (!OK.equals(sStatus))
			{
				String sErrorCode = evaluateXPathString(xPath, node, "/HireRightResponse/ErrorCode");
				String sErrorDescription = evaluateXPathString(xPath, node, "/HireRightResponse/ErrorDescription");

				LOGGER.error("Status='" + sStatus + "', ErrorCode='" + sErrorCode + "', ErrorDescription='" + sErrorDescription + '\'');
				throw new CException(ERROR_CALLING_HIRE_RIGHT_WEB_SERVICE + ": " + sErrorDescription + '"');
			}
		}
		catch (CException e)
		{
			throw new RuntimeException(e.getMessage(), e);
		}
		catch (Throwable t)
		{
			LOGGER.error(t.getMessage(), t);
			throw new RuntimeException(ERROR_CALLING_HIRE_RIGHT_WEB_SERVICE);
		}
	}

	private String evaluateXPathString(XPath xPath, Object item, String sExpression)
	{
		try
		{
			return (String) xPath.evaluate(sExpression, item, XPathConstants.STRING);
		}
		catch (Throwable t)
		{
			LOGGER.error("Error evaluating XPath string " + sExpression + ": " + t.getMessage(), t);
			return null;
		}
	}

	@SuppressWarnings("serial")
	private static class CException extends Exception
	{
		public CException()
		{
			super();
		}

		public CException(String message)
		{
			super(message);
		}

		public CException(String message, Throwable cause)
		{
			super(message, cause);
		}

		public CException(Throwable cause)
		{
			super(cause);
		}
	}
}

package com.workday.ps.charutils;

import java.io.IOException;
import java.io.PushbackInputStream;
import java.util.HashMap;
import java.util.Map;

import com.workday.ps.utils.IOUtils;

public class BOMUtils {
	final static Map<String,byte[]> BOMs;
	static int maxLength = 0;
	
	/**
	 * Retrieves a byte array containing the BOM for the specified character encoding.  Note that the returned byte array values
	 * are mutable and provide direct access to the arra
	 * 
	 * @param character_encoding
	 * @return a byte array containing the BOM for the specified character encoding.  Null if no matching character encoding is found.
	 * @throws IllegalArgumentException
	 */
	
	public static byte[] getBOMForEncoding(String character_encoding) throws IllegalArgumentException {
		if ( character_encoding == null ) {
			throw new IllegalArgumentException("character encoding must be non-null");
		}
		String char_enc = character_encoding.trim().toUpperCase();
		
		byte[] bom = BOMs.get( char_enc );
		if ( bom == null ) {
			throw new IllegalArgumentException( String.format( "No BOM available for character encoding \"%s\"", char_enc ) );
		}

		return bom;
	}
	
	/**
     * Read the first few bytes of the InputStream in order to detect a BOM.  If no BOM is found the InputStream is returned to
     * its original state so that the full content can be read from it.
     * 
     * @param input
     * @return The character encoding matching the BOM or null if no BOM is detected
     * @throws IOException if an error occurs reading the input stream
     */
    
    public static String findEncodingFromBOM(PushbackInputStream input) throws IOException {
		byte possibleBOM[] = new byte[5];
		int total_bytes = IOUtils.read(input, possibleBOM);
		
		Map.Entry<String,byte[]> matched_bom = null;
		String source_encoding = null;

		for( Map.Entry<String,byte[]> entry: BOMs.entrySet() ) {
			byte[] bom_bytes = entry.getValue();
			
			//
			// If the number of bytes that we've been able to read from the input message is as long or longer than this BOM then compare the byte sequences
			//
			if ( total_bytes >= bom_bytes.length ) {
				boolean bom_match = false;
				for( int i=0; i< bom_bytes.length; i++) {
					bom_match = bom_bytes[i] == possibleBOM[i];
					if ( !bom_match ) {
						break;
					}
				}
				
				if ( bom_match ) {
					matched_bom = entry;
					break;
				}
			}
		}
		
		if ( matched_bom != null ) {
			source_encoding = matched_bom.getKey();
			//
			// Push back any bytes which were not part of the BOM
			//
			pushback(input, possibleBOM, total_bytes, matched_bom.getValue().length);
		}
		else {
			//
			// Push back all of the bytes which were read to try to detect a BOM
			//
			pushback( input, possibleBOM, total_bytes, 0);

		}
		return source_encoding;
    }
    
    private static void pushback(PushbackInputStream input, byte buffer[], int length, int end_index) throws IOException {
		for(int i=length-1; i>= end_index; i--) {
			input.unread( buffer[i] );
		}    	
    }
    
    /**
     * Obtain the maximum number of bytes present in the BOMs that we can handle.
     * 
     * @return The length of the longest BOM that we can handle
     */
    
    public static int getMaxBOMLength() {
    		return maxLength;
    }
    
    //
    // Populate the lookup data for finding the encoding matching BOM
    //
    static {
    		BOMs = new HashMap<String,byte[]>();
    		
    		BOMs.put("UTF-8", new byte[] {(byte)0xEF, (byte)0xBB, (byte)0xBF} );
    		BOMs.put("UTF-16", new byte[] {(byte)0xFE, (byte)0xFF} );
    		BOMs.put("UTF-16BE", BOMs.get("UTF-16"));
    		BOMs.put("UTF-16LE", new byte[] {(byte)0xFF, (byte)0xFE} );
    		BOMs.put("UTF-32", new byte[] {(byte)0x00, (byte)0x00, (byte)0xFE, (byte)0xFF} );
    		BOMs.put("UTF-32BE", BOMs.get("UTF-32"));
    		BOMs.put("UTF-32LE", new byte[] { (byte)0xFE, (byte)0xFF, (byte)0x00, (byte)0x00 } );
    		BOMs.put("GB18030", new byte[] {(byte)0x84, (byte)0x31, (byte)0x95, (byte)0x33} );
    		

    		for( byte b[] : BOMs.values() ) {
    			if ( b.length > maxLength ) {
    				maxLength = b.length;
    			}
    		}
   		
    }

}

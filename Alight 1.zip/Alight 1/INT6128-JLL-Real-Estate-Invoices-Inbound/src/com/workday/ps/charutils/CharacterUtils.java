package com.workday.ps.charutils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capeclear.capeconnect.attachments.io.FileBackedManagedData;

/**
 * Utilities in support of character manipulation in Workday assemblies
 * 
 * @author Doug Lee
 */
public class CharacterUtils {
	public static final String DEFAULT_CHARSET = "utf-8";
	//
	// Regex Pattern to extract the charset, if present, in a content-type field.
	//
	
	static Pattern charsetPattern = Pattern.compile("(?:.*charset=)([^()<>@,;:\\\"/\\[\\]?.=\\s]*)");
	
	/**
	 * Obtain the character encoding from a content-type header
	 * @param content_type  a content-type value from which a character set name is to be extracted.  e.g. "text/plain; charset=iso-8859-1"
	 * @param default_charset  The name of the character set to be returned if non is specified in the content-type value supplied
	 * @return the character encoding contained in the content-type value or the default_charset if no encoding was specified
	 */
	
	public static String getCharacterEncodingFromContentType( String content_type, String default_charset ) {
		String result = default_charset;
		
		if ( content_type != null && content_type.length() > 0 ) {
			//
			// If the content-type specifies a charset then extract this given the 
	    		Matcher matcher = charsetPattern.matcher( content_type );
	    		
	    		if ( matcher.find() ) {
	    			result = matcher.group(1);
	    		}
    		}
		
		return result;
	}
	
	/**
	 * Obtain the character encoding from a content-type header defaulting to UTF-8 is no character encoding is specified
	 * @param content_type  a content-type value from which a character set name is to be extracted.  e.g. "text/plain; charset=iso-8859-1"
	 * @return the character encoding contained in the content-type value or utf-8 if no encoding was specified
	 * 
	 */
	
	public static String getCharacterEncodingFromContentType(String content_type) {
		return getCharacterEncodingFromContentType( content_type, DEFAULT_CHARSET );
	}
	
	/**
	 * This utility function is used to obtain the character encoding specified on the input message to a custom
	 * mediation step.  A mediation step which needs to use this function should either use the DataHandler as
	 * the input parameter - although the DataHandler can be obtained via the MediationMessage from the MediationContext
	 * if you need direct access to those interfaces.
	 * 
	 * @param dh
	 * @return The character encoding specified in the DataHandler or utf-8 if none was specified
	 */
	
	public static String getCharacterEncoding(javax.activation.DataHandler dh) {
		return getCharacterEncodingFromContentType( dh.getContentType() );
	}
	
	/**
	 * This utility function is used to obtain the character encoding specified in the assembly on the output mimetype of a
	 * custom bean mediation step.  This function relies on the assembly framework providing an instance of FileBackedManagedData
	 * as the implementation of the OutputStream.
	 * 
	 * @param out The OutputStream from which the content-type is to be extracted.  This must be an instance of FileBackedManagedData
	 * @return The character encoding specified on the mimetype of the output of the mediation step.  "utf-8" will be returned as a default
	 * if no charset is configured onto the output mimetype.
	 * @throws IllegalArgumentException if the provided OutputStream is not an instance of FileBackedManagedData
	 */

	public static String getCharacterEncoding(java.io.OutputStream out) throws IllegalArgumentException {
		return getCharacterEncoding(out, DEFAULT_CHARSET);
	}
	
	/**
	 * This utility function is used to obtain the character encoding specified in the assembly on the output mimetype of a
	 * custom bean mediation step.  This function relies on the assembly framework providing an instance of FileBackedManagedData
	 * as the implementation of the OutputStream.
	 * 
	 * @param out The OutputStream from which the content-type is to be extracted.  This must be an instance of FileBackedManagedData
	 * @return The character encoding specified on the mimetype of the output of the mediation step
	 * @throws IllegalArgumentException if the provided OutputStream is not an instance of FileBackedManagedData
	 */

	public static String getCharacterEncoding(java.io.OutputStream out, String default_charset)  {
		String charset = default_charset;
		
		if ( out instanceof FileBackedManagedData ) {
			FileBackedManagedData fbmd = (FileBackedManagedData)out;
			
			charset = getCharacterEncodingFromContentType( fbmd.getContentType() , default_charset);
		}
		else {
			throw new IllegalArgumentException("Content-type cannot be extracted from supplied OutputStream");
		}
		return charset;
	}	
	/**
	 * Determine if a character is legal in XML.  For the moment ignore 10000 to 10FFFF as possibilities
	 * @param ch
	 * @return
	 */
	
	public static boolean isCharacterLegalInXML(int ch) {
		return (
			( (ch > 31) &&
			  ( ( ch <= 0xd7ff) || ( (ch >= 0xe000 ) && ( ch <= 0xfffd) ) ||( ch >= 0x10000 ) && ( ch <= 0x10ffff ) ) ) ||
			  ( ch == 9) || (ch == 10) || (ch == 13) ) ;
	}
}

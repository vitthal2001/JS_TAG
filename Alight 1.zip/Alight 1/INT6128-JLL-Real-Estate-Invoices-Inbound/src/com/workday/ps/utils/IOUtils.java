package com.workday.ps.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;

/**
 * Everyone has an IOUtils class ... but the CapeClear and Workday ones are not public and we can't necessarily depend on the versions of Apache and other libraries
 * which are present in the integration runtime so we'll provide our own implementation.
 * 
 * 
 * @author Doug Lee
 *
 */
public class IOUtils {
	
	/**
	 * Copy the contents of the InputStream to the OutputStream using a specified buffer size
	 * 
	 * @param input The InputStream from which the contents are to be read
	 * @param output The OutputStream to which the output is to be written
	 * @param buffer_size The size of the buffer to be allocated for holding the data
	 * @return the number of bytes copied
	 * @throws IOException if an error occurs reading or writing the data
	 */
	
	public static long copy(InputStream input, OutputStream output, int buffer_size) throws IOException {
		byte buffer[] = new byte[buffer_size];
		int num_bytes;
		long num_written = 0;
		
		do {
			num_bytes = input.read(buffer);
			if ( num_bytes > 0 ) {
				output.write(buffer, 0, num_bytes);
				num_written += num_bytes;
			}
		} while ( num_bytes >= 0);
		return num_written;
	}
	
	/**
	 * Copy the contents of the InputStream to the OutputStream
	 * @param input The InputStream from which the contents are to be read
	 * @param output The OutputStream to which the output is to be written
	 * @return
	 * @throws IOException
	 */
	
	public static long copy(InputStream input, OutputStream output ) throws IOException {
		return copy(input, output, 65536);
	}
	/**
	 * Copy the contents of the Reader to the Writer using a specified buffer size
	 * 
	 * @param reader The Reader from which the contents are to be read
	 * @param writer The Writer to which the output is to be written
	 * @param buffer_size The size of the buffer to be allocated for holding the data
	 * @return the number of characters copied
	 * @throws IOException if an error occurs reading or writing the data
	 */
	
	public static long copy(Reader reader, Writer writer, int buffer_size) throws IOException {
		char buffer[] = new char[buffer_size];
		int num_chars;
		long num_written = 0;
		do {
			num_chars = reader.read(buffer);
			if ( num_chars > 0 ) {
				writer.write(buffer, 0, num_chars);
				num_written += num_chars;
			}
		} while ( num_chars >= 0);
		return num_written;
	}
	
	/**
	 * Copy the contents of the Reader to the Writer
	 * 
	 * @param reader The Reader from which the contents are to be read
	 * @param writer The Writer to which the output is to be written
	 * @return the number of characters copied
	 * @throws IOException if an error occurs reading or writing the data
	 */
	
	public static long copy(Reader reader, Writer writer ) throws IOException {
		return copy(reader, writer, 32768);
	}
	/**
	 * Copy the text contents of an InputStream to an OutputStream changing the character encoding if required
	 * 
	 * @param input The InputStream from which the contents are to be read
	 * @param input_encoding The character encoding when converting the input stream to character data
	 * @param output The OutputStream to which the output is to be written
	 * @param output_encoding The character encoding to be used when converting the character data to bytes
	 * @return the number of characters copied
	 * @throws IOException if an error occurs reading or writing the data
	 */
	public static long copy(InputStream input, String input_encoding, OutputStream output, String output_encoding) throws IOException {
		
		long count = 0;
		if ( output_encoding.trim().toLowerCase().equals( input_encoding.trim().toLowerCase()) ) {
			count = copy(input, output);
		}
		else {
			//
			// The input and output encodings are not the same so we need to change the encoding
			//

			try(
				InputStreamReader reader = new InputStreamReader( input, input_encoding );
				OutputStreamWriter writer = new OutputStreamWriter( output, output_encoding )
				) {
				count = IOUtils.copy(reader,  writer);  			
			}
	
		}
		return count;
	}
	
	/**
	 * Read as many bytes as possible into the target buffer.  Note that some InputStream implementations
	 * do not guarantee to fill a byte array in a single read.  This function guarantees that behaviour since
	 * we will block if necessary and continue reading until either the buffer is full or the end of file
	 * has been reached.
	 * 
	 * @param input
	 * @param buffer
	 * @throws IOException if an error occurs reading the file
	 * @return
	 */
	
	public static int read(InputStream input, byte buffer[]) throws IOException {
		int total_bytes = 0;
		int num_bytes = 0;
		do {
			num_bytes = input.read(buffer, total_bytes, buffer.length - total_bytes);
			if ( num_bytes > 0 ) {
				total_bytes += num_bytes;
			}
		} while ( ( num_bytes > 0 ) && ( total_bytes < buffer.length)) ;
		return total_bytes;
	}

}

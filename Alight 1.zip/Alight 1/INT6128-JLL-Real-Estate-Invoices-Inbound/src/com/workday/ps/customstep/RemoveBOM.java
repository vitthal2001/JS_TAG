package com.workday.ps.customstep;

import static com.capeclear.assembly.annotation.Component.Type.mediation;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PushbackInputStream;

import javax.activation.DataHandler;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.logger.LogControl;
import com.capeclear.logger.Logger;
import com.workday.ps.charutils.BOMUtils;
import com.workday.ps.charutils.CharacterUtils;
import com.workday.ps.utils.IOUtils;


/**
 * Custom mediation step to be used to remove a BOM from an incoming message and, if necessary, change the character encoding
 * to that specified on the Output configuration of the custom mediation step in the assembly
 * 
 * This step assumes that both the input and output messages are text messages of some form.  It is not suitable for use with non-text messages.
 * 
 * @author Doug Lee
 */

@Component(
        name = "RemoveBOM",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons.RemoveBOM_16.png",
        largeIconPath = "icons.RemoveBOM_32.png"
        )
public class RemoveBOM {
	private static final String DEFAULT_CHARSET = "utf-8";
	
	private Logger log = LogControl.getLogger( getClass() );
	
    /**
     * Detect a BOM on the incoming file and automatically, remove the BOM and automatically convert the incoming message into the
     * output encoding specified on the custom mediation step.  If an error occurs during the processing of the message it will be
     * logged and then thrown as a RuntimeException which will can then be dealt with by an error handler in the assembly using
     * this custom bean.
     * 
     * @param input_dh A DataHandler containing the input message. We use this means of referencing the input message so that we have access to any MIME type (content-type) configured on the incoming message
     * @param output The OutputStream to which we'll write the output message    
     */
	
    @ComponentMethod
    public void process(DataHandler input_dh, OutputStream output) { 

	    	//
	    	// Create a PushbackInputStream to read the input as we'll need to put the potential BOM bytes back into the stream if they turn out not to be part of a BOM.
	    	//
    		try(PushbackInputStream pushback = new PushbackInputStream( input_dh.getInputStream(), 5)) {
        		String input_encoding = null;
        		
        		try {
	    			input_encoding = BOMUtils.findEncodingFromBOM( pushback );
	    		}
	    		catch (IOException io_e) {
	    			logError("Error attempting to read BOM from message: " + io_e.getMessage(), io_e);
	    		}
	    		
	    		//
	    		// If an input encoding was not identified then we'll look for an encoding specified on the content type of the incoming message.  If this isn't present
	    		// then we'll default to utf-8
	    		//
	    		
	    		if ( input_encoding == null ) {
	    			input_encoding = CharacterUtils.getCharacterEncodingFromContentType( input_dh.getContentType(), DEFAULT_CHARSET );
	    			log.info( "No BOM found on message.  Using " + input_encoding + " for reading input message" );
	    		}
	    		else {
	    			log.info("Found BOM for " + input_encoding );
	    		}
	    		
	    		//
	    		// If a character encoding has been specified on the Output configuration of the step then use this encoding when writing the file.  If no
	    		// encoding is specified then use the default (UTF-8).  We can detect the configured encoding from the FileBackedManagedData content-type since
	    		// the custom mediation step framework will populate the content-type of the FileBackedManagedData that it creates to hold the output message.
	    		//
	    		
	    		String output_encoding = CharacterUtils.getCharacterEncoding( output );	    		

	    		//
	    		// Now copy the remaining bytes of the input to the output changing the character encoding if required
	    		//
	    		
    			IOUtils.copy(pushback, input_encoding, output, output_encoding);

    		}
    		catch (IOException io_e ) {
    			logError("Error processing message whilst removing BOM: " + io_e.getMessage(), io_e);
    		}		
    }
    
    private void logError(final String err_msg, Throwable t) {
		log.error(err_msg, t);
		throw new RuntimeException(err_msg, t);    	
    }
}

package com.workday.ps.customstep;

import static com.capeclear.assembly.annotation.Component.Type.mediation;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PushbackInputStream;

import javax.activation.DataHandler;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.logger.LogControl;
import com.capeclear.logger.Logger;
import com.workday.ps.charutils.BOMUtils;
import com.workday.ps.charutils.CharacterUtils;
import com.workday.ps.utils.IOUtils;


/**
 * Custom mediation step to be used to add a BOM to an incoming message.  An error will be generated if the character encoding of the incoming
 * message does not have a recognized BOM.  If no Output mimetype is configured on the custom step then the character encoding will be taken
 * from that configured as the charset on the incoming message mimeypte.  If no mimetype is set on either the input or output message then
 * the default of UTF-8 is applied.
 * 
 * This step assumes that both the input and output messages are text messages of some form.  It is not suitable for use with non-text messages.
 * 
 * @author Doug Lee
 */

@Component(
        name = "RemoveBOM",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/AddBOM_16.png",
        largeIconPath = "icons/AddBOM_24x.png"
        )
public class AddBOM {
	
	private Logger log = LogControl.getLogger( getClass() );
	
    /**
     * @param input_dh A DataHandler containing the input message. We use this means of referencing the input message so that we have access to any MIME type (content-type) configured on the incoming message
     * @param output The OutputStream to which we'll write the output message    
     */
	
    @ComponentMethod
    public void process(DataHandler input_dh, OutputStream output) { 

    		//
    		// If the content type of the incoming message defines a character set (e.g. text/plain; charset=UTF-16) then use that.  We'll not assign a default
    		// value at this stage as we first need to see if a BOM identifying the encoding is present on the incoming message
    		//
    	
    		String input_encoding = CharacterUtils.getCharacterEncodingFromContentType( input_dh.getContentType(), null );
    		
	    	//
	    	// Create a PushbackInputStream to read the input as we'll need to put the potential BOM bytes back into the stream if they turn out not to be part of a BOM.
	    	//
    		
    		try(PushbackInputStream pushback = new PushbackInputStream( input_dh.getInputStream(), 5)) {
        		String bom_input_encoding = null;
        		
        		try {
	    			bom_input_encoding = BOMUtils.findEncodingFromBOM( pushback );
	    		}
	    		catch (IOException io_e) {
	    			logError("Error attempting to read BOM from message: " + io_e.getMessage(), io_e);
	    		}
	    		
	    		//
	    		// If an input encoding was not identified then we'll look for an encoding specified on the content type of the incoming message.  If this isn't present
	    		// then we'll default to utf-8
	    		//
	    		
	    		if ( bom_input_encoding == null ) {
	    			//
	    			// If no BOM is found and no charset was specified on the incoming message then we'll assume that the incoming message is UTF-8
	    			//
	    			if ( input_encoding == null ) {
	    				log.info("Assuming input is UTF-8:  no BOM on input message;  no charset defined on input content-type."  );
	    				input_encoding = CharacterUtils.DEFAULT_CHARSET;
	    			}
	    		}
	    		else {
	    			log.info("Found BOM for " + bom_input_encoding + " on incoming message");
	    			
	    			//
	    			// If no charset was specified on the incoming message then use the character encoding implied by the BOM
	    			//
	    			if ( input_encoding == null ) {
	    				input_encoding = bom_input_encoding;
	    			}
	    			else {
	    				//
	    				// We have both a BOM and a charset specified on the content-type.  If these are different then we need
	    				// to treat this as an error condition
	    				//
	    				if ( !input_encoding.equals( bom_input_encoding) ) {
	    					final String err_msg = String.format("Mismatched input encodings:  BOM on input message specifies %s, content-type specifies %s", bom_input_encoding, input_encoding);
	    					log.error( err_msg );
	    					throw new RuntimeException( err_msg );
	    				}
	    			}
	    		}   
	    		
	    		String output_encoding = CharacterUtils.getCharacterEncoding(output, input_encoding);
	    		
	    		byte bom[] = BOMUtils.getBOMForEncoding(output_encoding);
	    		
	    		if ( bom == null ) {
	    			final String err_msg = String.format("No recognized BOM for encoding %s", output_encoding);
	    			log.error( err_msg );
	    			throw new RuntimeException( err_msg );
	    		}
	    		
	    		//
	    		// Write the BOM to the output message
	    		//
	    		
	    		output.write(bom);
	    		
	    		//
	    		// Copy the input to the output.  The character encoding is changed if necessary
	    		//
	    		
	    		IOUtils.copy(pushback,  input_encoding, output, output_encoding);

    		}
    		catch (IOException io_e ) {
    			logError("Error processing input document whilst adding BOM: " + io_e.getMessage(), io_e);
    		}		
    }
    
    private void logError(final String err_msg, Throwable t) {
		log.error(err_msg, t);
		throw new RuntimeException(err_msg, t);    	
    }
}

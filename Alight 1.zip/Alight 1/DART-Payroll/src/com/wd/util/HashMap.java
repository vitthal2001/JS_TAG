package com.wd.util;

import java.util.Iterator;
import java.util.Set;

public class HashMap {

	private static java.util.HashMap<String, java.util.HashMap<String, String>> hashMaps = new java.util.HashMap<String, java.util.HashMap<String, String>>();
	
	/**
	 * Adds a key/value to the hashmap identified by id
	 * if there is no hashmap with this id then one will be created 
	 * @param id
	 * @param key
	 * @param value
	 */
	public static void put(String id, String key, String value)
	{
		getHashMap(id).put(key, value);
	}
	
	/**
	 * returns the value for the key from the hashmap identified by id 
	 * @param id
	 * @param key
	 * @return
	 */
	public static Object get(String id, String key)
	{
		return getHashMap(id).get(key);
	}

	/**
	 * returns the value for the key from the hashmap identified by id, 
	 * if the key is not found then the refaultValue is returned
	 * @param id
	 * @param key
	 * @param defaultValue
	 * @return
	 */
	public static Object get(String id, String key, String defaultValue)
	{
		Object value = getHashMap(id).get(key);
		if (value == null)
		{
			return defaultValue;
		} else
		{
			return value;
		}
	}

	/**
	 * Informational, prints the list of hashmap ids and their content size
	 */
	public static String getKeyInformation()
	{
		String result = "";
		Set<String> keys = hashMaps.keySet();
		for (Iterator<String> iterator = keys.iterator(); iterator.hasNext();) 
		{
			String object = iterator.next();
			int size = getHashMap(object).size();
			result = result + object + ":" + size + "\n";
		}
		return result;
	}

	/**
	 * Informational, returns the content size of a hashmap identified by id
	 * @param id
	 * @return
	 */
	public static int size(String id)
	{
		return getHashMap(id).size();
	}

	/**
	 * Internal, returns the hashmap object identified by id
	 * @param id
	 * @return
	 */
	public static java.util.HashMap<String, String> getHashMap(String id)
	{
		java.util.HashMap<String, String> map = hashMaps.get(id);
		if (map == null)
		{
			map = new java.util.HashMap<String, String>();
			hashMaps.put(id, map);
		}
		return map;
	}
}

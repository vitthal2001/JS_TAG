package com.wd.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class UtilBean {
	
	/**
	 * Returns the string of a date that is varied 'vary' days from today. 
	 * @param vary	the varied days from today. It can be positive and negative
	 * @return	a date string in the format 'yyyy-MM-dd'
	 */
	public String getDateStringVariedFromToday(int vary){
		String variedStr = null;
		GregorianCalendar cal = new GregorianCalendar();	
		cal.add(Calendar.DATE, vary);
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		variedStr = dateFormatter.format(cal.getTime());
		
		return variedStr;
	}
	
	/**
	 * Returns the string of the first day of the current year in the format 'yyyy-MM-dd'
	 * @return
	 */
	public String getCurrentYearFirstDateString(){
		String firstDateStr = "";
		GregorianCalendar cal = new GregorianCalendar();
		cal = new GregorianCalendar(cal.get(Calendar.YEAR), 0, 1);
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		firstDateStr = dateFormatter.format(cal.getTime());
		return firstDateStr;
	}
	
	/**
	 * Return the default BP list. Additional BP could be added in down stream depends on the payroll countries setting. 
	 *  @return bpList the hard code required BP list to make the list as mandentory. The individual entry is the BP ref id(type Business_Process_Type)
	 *  
	 */
	public List<String> getRequiredBPs(){
		ArrayList<String> bpList = new ArrayList<String>();
		
		bpList.add("Payment Election Enrollment Event");
		bpList.add("Payment Printing Event");
		bpList.add("Assign Pay Group");
		bpList.add("Copy Withholding Orders for Worker Event");
		bpList.add("Outsourced Payment Release Event");
		bpList.add("Payroll Retro Worker Data Event");
		bpList.add("Settlement Run Event");
		bpList.add("Prenote Run Event");
		bpList.add("Assign Costing Allocation");
		bpList.add("Copy Withholding Orders for Workers");
		bpList.add("Copy Tax Elections for Workers");
		bpList.add("Review Payment Acknowledgement");
		bpList.add("Payment Release Event");
		bpList.add("Pay Cycle Event");
		bpList.add("Copy Tax Elections for Worker Event");
		bpList.add("Print Checks Task");
		
		return bpList;
	}
	
	/**
	 * Return the default E&G BP list. Additional BP could be added in down stream depends on the payroll countries setting.
	 * @return bpList the hard code required E&G BP list to make the list as mandentory. The individual entry is the BP ref id(type Business_Process_Type)
	 *  
	 */
	public List<String> getRequiredEnGBPs(){
		ArrayList<String> bpEnGList = new ArrayList<String>();
		
		bpEnGList.add("Create Payroll Commitment Adjustments");
		bpEnGList.add("Create Initial Payroll Commitments");
		
		return bpEnGList;
	}
	
	/**
	 *  Return the default EIB templates' WS operation names list. Additional WS operation name could be added in down stream depends on the payroll countries setting.
	 *  @return eibWSList the hard code required EIB's WS API list to make the list as mandentory. The individual entry is the "Web Service Operation Name".
	 *  
	 */
	public List<String> getRequiredEIBTemplates(){
		ArrayList<String> eibWSList = new ArrayList<String>();
		
		eibWSList.add("Put Payroll Off-cycle Payment");
		eibWSList.add("Put Period Schedule");
		eibWSList.add("Change No Retro Processing Prior To");
		eibWSList.add("Assign Costing Allocation");
		eibWSList.add("Submit Payroll Input");
		
		return eibWSList;
	}
}

package com.wd.int0008;

public class Manager_Hash {
	
	public String managerID;
	public String companyID;
	public String supOrg;
	
	public Manager_Hash(String managerID, String companyID, String supOrg) {
	super();
	  this.managerID = managerID;
	  this.companyID = companyID;
	  this.supOrg = supOrg;
	}
	
	public String getManagerID() {
	return managerID;
	}
	public void setManagerID(String managerID) {
	this.managerID = managerID;
	}
	
	public String getCompanyID() {
	return companyID;
	}
	public void setCompanyID(String companyID) {
	this.companyID = companyID;
	}

	public String getSupOrg() {
	return supOrg;
	}
	public void setSupOrg(String supOrg) {
	this.supOrg = supOrg;
	}
	}
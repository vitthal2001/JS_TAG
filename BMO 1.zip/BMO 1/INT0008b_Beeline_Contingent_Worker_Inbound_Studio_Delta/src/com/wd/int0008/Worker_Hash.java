package com.wd.int0008;

public class Worker_Hash 
{
public String beelineID;
public String workerEIN;
public String departmentID;
public String locationID;
public String managerID;
public String fristName;
public String lastName;
public String middleName;
public String prehireID;
public String poistionID;
public String workerType;
public String beelineCC;
public String positionCC;
public String beelineRef;
public String assignmentID;
public String businessTitle;
public String workerStatus;
public String hours;
public String rate;
public String frequency;
public String currency;
public String startDate;
public String endDate;
public String termDate;
public String termDateFuture;
public String assignmentRefID;

public Worker_Hash (String beelineID, String workerEIN, String departmentID, String locationID, String managerID, String fristName, 
		String lastName, String middleName, String prehireID, String poistionID, String workerType, String beelineCC, String positionCC, String beelineRef,
		String assignmentID, String businessTitle, String workerStatus, String hours, String rate, String frequency, String currency,
		String startDate, String endDate,String termDate,String termDateFuture,String assignmentRefID ){
super();
	  this.beelineID = beelineID;
	  this.workerEIN = workerEIN;
	  this.departmentID = departmentID;
	  this.locationID = locationID;  
	  this.managerID = managerID;
	  this.fristName = fristName;
	  this.lastName = lastName;
	  this.middleName = middleName;
	  this.prehireID = prehireID;
	  this.poistionID = poistionID;
	  this.workerType = workerType;
	  this.beelineCC = beelineCC;
	  this.positionCC = positionCC;
	  this.beelineRef = beelineRef;
	  this.assignmentID = assignmentID;
	  this.businessTitle = businessTitle;
	  this.workerStatus = workerStatus;
	  this.hours = hours;
	  this.rate = rate;
	  this.frequency = frequency;
	  this.currency = currency;
	  this.startDate = startDate;
	  this.endDate = endDate;
	  this.termDate = termDate;
	  this.termDateFuture = termDateFuture;
	  this.assignmentRefID = assignmentRefID;
}

public String getBeelineID() {
return beelineID;
}

public String getWorkerEIN() {
return workerEIN;
}

public String getDepartmentID() {
return departmentID;
}

public String getLocationID() {
return locationID;
}

public String getManagerID() {
return managerID;
}

public String getFirstName() {
return fristName;
}

public String getLastName() {
return lastName;
}

public String getMiddleName() {
return middleName;
}

public String getPreHireID() {
return prehireID;
}

public String getPositionID() {
return poistionID;
}

public String getWorkerType() {
return workerType;
}

public String getBeelineCC() {
return beelineCC;
}

public String getPositionCC() {
return positionCC;
}

public String getBeelineRef() {
return beelineRef;
}

public String getAssignmentID() {
return assignmentID;
}

public String getBusinessTitle() {
return businessTitle;
}

public String getWorkerStatus() {
return workerStatus;
}

public String getHours() {
return hours;
}

public String getRate() {
return rate;
}

public String getFrequency() {
return frequency;
}

public String getCurrency() {
return currency;
}

public String getStartDate() {
return startDate;
}

public String getEndDate() {
return endDate;
}

public String getTermDate() {
return termDate;
}

public String getTermDateFuture() {
return termDateFuture;
}

public String getAssignmentRefID() {
return assignmentRefID;
}

public void setBeelineID(String beelineID) {
this.beelineID = beelineID;
}

public void setWorkerEIN(String workerEIN) {
this.workerEIN = workerEIN;
}

public void setDepartmentID(String departmentID) {
this.departmentID = departmentID;
}

public void setLocationID(String locationID) {
this.locationID = locationID;
}

public void setManagerID(String managerID) {
this.managerID = managerID;
}

public void setFirstName(String fristName) {
this.fristName = fristName;
}

public void setLastName(String lastName) {
this.lastName = lastName;
}

public void setMiddleName(String middleName) {
this.middleName = middleName;
}

public void setPreHireID(String prehireID) {
this.prehireID = prehireID;
}

public void setPositionID(String poistionID) {
this.poistionID = poistionID;
}

public void setWorkerType(String workerType) {
this.workerType = workerType;
}

public void setBeelineCC(String beelineCC) {
this.beelineCC = beelineCC;
}

public void setPositionCC(String positionCC) {
this.positionCC = positionCC;
}

public void setBeelineRef(String beelineRef) {
this.beelineRef = beelineRef;
}

public void setAssignmentID(String assignmentID) {
this.assignmentID = assignmentID;
}

public void setBusinessTitle(String businessTitle) {
this.businessTitle = businessTitle;
}

public void setWorkerStatus(String workerStatus) {
this.workerStatus = workerStatus;
}

public void setHours(String hours) {
this.hours = hours;
}

public void setRate(String rate) {
this.rate = rate;
}

public void setFrequency(String frequency) {
this.frequency = frequency;
}

public void setCurrency(String currency) {
this.currency = currency;
}

public void setStartDate(String startDate) {
this.startDate = startDate;
}

public void setEndDate(String endDate) {
this.endDate = endDate;
}

public void setTermDate(String termDate) {
this.termDate = termDate;
}

public void setTermDateFuture(String termDateFuture) {
this.termDateFuture = termDateFuture;
}

public void setAssignmentRefID(String assignmentRefID) {
this.assignmentRefID = assignmentRefID;
}

}
package com.workday.dart.test;

import java.io.IOException;
import java.io.StringReader;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.mediators.utils.XPath;
import com.workday.aunit.AssemblyTestCase;

/**
 * Utility AUnit assistance class providing XPath assertion functions
 * 
 * @author Doug Lee
 *
 */

public abstract class DARTTestCase extends AssemblyTestCase {

	public void assertXPathEquals(String msg, String expected, String xpath, Document doc) throws Exception {
		assertEquals(msg, expected, getXPath(xpath).stringValueOf(doc));				
	}
	
	public void assertXPathTrue(String msg, String xpath, Document doc) throws Exception {
		assertTrue( msg, getXPath(xpath).booleanValueOf(doc) );
	}
	
	public void assertXPathFalse(String msg, String xpath, Document doc) throws Exception {
		assertFalse( msg, getXPath(xpath).booleanValueOf(doc) );
		
	}
	
	private XPath getXPath(String xpath) throws Exception {
		return new XPath(xpath, "18", getMediationContext());
	}
	
	/**
	 * Converts the root part of the current message as a DOM Document.  Note that this approach should not be used within integrations
	 * as it will force the current message into memory as well as 
	 * @param ctx
	 * @return
	 * @throws SAXException If the current message is not well formed
	 * @throws IOException
	 */
	public Document getRootPartAsDoc(MediationContext ctx) throws SAXException, IOException {
		return com.capeclear.xml.utils.DOMUtils.parseToDOM( new InputSource( new StringReader( ctx.getMessage().getRootPartAsText() ) ) );
	}
}

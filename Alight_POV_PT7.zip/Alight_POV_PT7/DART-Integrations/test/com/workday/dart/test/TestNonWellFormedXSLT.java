package com.workday.dart.test;

import org.w3c.dom.Document;

import com.capeclear.mediation.MediationContext;
import com.workday.aunit.actions.Action;
import com.workday.aunit.actions.StandardAction;
import com.workday.aunit.annotations.AssemblyTest;
import com.workday.aunit.annotations.AssertAfter;
import com.workday.aunit.annotations.AtComponent;
import com.workday.aunit.annotations.UnitTest;

@AssemblyTest(project="DART-Integrations", displayLabel="Test of non-well-formed XSLT")
public class TestNonWellFormedXSLT extends DARTTestCase {
	
	@UnitTest(startComponent="ValidateWellFormed")
	public void testGetIds() throws Exception {
		MediationContext ctx = getMediationContext();
		ctx.setProperty("p.review.file", "Review_XSLT.xsl");
		ctx.setProperty("p.int.sys.name", "DART Test Non-Well-Formed");
		ctx.setProperty("p.file.name", "badlyFormed.xsl" );

		setMessagePart(0, "test/badlyFormed.txt", "text/xml");
	}


	
	@AssertAfter(id="FixUpError", step="Xslt")
	public void assertWhenFinished() throws Exception {
		
		Document doc = getRootPartAsDoc( getMediationContext() ); 
		
		assertXPathEquals("Severity is not ERROR", "ERROR", "/note/node/severity", doc);
		
	}
	
	@AtComponent(id="CallAggregateDataLines")
	public Action terminateTest() {
		return new StandardAction( Action.Type.terminate );
	}

}

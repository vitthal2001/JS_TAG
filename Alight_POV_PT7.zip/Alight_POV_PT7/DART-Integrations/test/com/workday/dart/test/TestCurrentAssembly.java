package com.workday.dart.test;

import org.w3c.dom.Document;

import com.capeclear.logger.LogControl;
import com.capeclear.mediation.MediationContext;
import com.workday.aunit.actions.Action;
import com.workday.aunit.actions.StandardAction;
import com.workday.aunit.annotations.AssemblyTest;
import com.workday.aunit.annotations.AssertAfter;
import com.workday.aunit.annotations.AtComponent;
import com.workday.aunit.annotations.UnitTest;

@AssemblyTest(project="DART-Integrations", displayLabel="Test of non-well-formed XSLT")
public class TestCurrentAssembly extends DARTTestCase {
	
	@UnitTest(startComponent="ValidateWellFormed")
	public void testGetIds() throws Exception {
		MediationContext ctx = getMediationContext();
		ctx.setProperty("p.review.file", "Review_Studio.xsl");
		ctx.setProperty("p.int.sys.name", "DART Test Old Assembly");
		ctx.setProperty("p.file.name", "assembly.xml" );

		setMessagePart(0, "test/assembly-newVersion.xml", "text/xml");
	}

	@AssertAfter(step="Store", id="LogCurrentData")
	public void errorEncountered() {
		Throwable t = getMediationContext().getException();
		if ( t != null ) {
			LogControl.getLogger(getClass()).error("Error in reviewing Studio", t);
		}
		
		assertNull("Error encountered", t);
	}

	
	@AssertAfter(id="ReviewXML", step="Eval")
	public void assertWhenFinished() throws Exception {
		
		Document doc = getRootPartAsDoc( getMediationContext() ); 
		
		assertXPathFalse("Obsolete erroneously reported", "exists(/note/node[message='Obsolete assembly version'])", doc);
		
	}
	
	@AtComponent(id="CallAggregateDataLines")
	public Action terminateTest() {
		return new StandardAction( Action.Type.terminate );
	}


}

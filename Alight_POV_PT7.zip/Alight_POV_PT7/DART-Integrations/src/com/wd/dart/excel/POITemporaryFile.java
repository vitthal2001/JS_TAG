package com.wd.dart.excel;

import java.io.File;
import java.io.IOException;

import org.apache.poi.util.TempFile;
import org.apache.poi.util.TempFileCreationStrategy;

import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.impl.cc.MediationTube;
import com.capeclear.utils.api.IDisposable;

public class POITemporaryFile implements IDisposable {
    File file;
    
    POITemporaryFile(File file) {
        this.file = file;
    };

    public static void installTemporaryFileCreationStrategy() {
       TempFile.setTempFileCreationStrategy( new TempFileCreationStrategy() {
           @Override
           public File createTempFile(String prefix, String suffix) throws IOException {
               MediationContext ctx = MediationTube.getCurrentMediationContext();
               POITemporaryFile tmp_file = new POITemporaryFile( File.createTempFile(prefix, suffix) );
               ctx.addDisposable( tmp_file );

               return tmp_file.getFile();
           }
           public File createTempDirectory(String prefix) throws IOException{
        	   MediationContext ctx = MediationTube.getCurrentMediationContext();
               POITemporaryFile tmp_file = new POITemporaryFile( new File(prefix) );
               ctx.addDisposable( tmp_file );

               return tmp_file.getFile();
           }
           
           ;
       } );
    };
    
    File getFile() {
        return file;
    }
    
    @Override
    public void dispose() {
        if ( file != null ) {
            if ( file.exists() ) {
                file.delete();
                file = null;
            }
        }
    };
}
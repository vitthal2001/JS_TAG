package com.wd.dart.excel;

import java.awt.Color;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.util.TempFile;
import org.apache.poi.util.TempFileCreationStrategy;

import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.capeconnect.attachments.io.FileBackedManagedData;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.MessageVariable;
import com.capeclear.mediation.impl.cc.MediationTube;
import com.opencsv.CSVReader;
import com.wd.dart.excel.POITemporaryFile;

public class ExcelWriter {
    String WORKBOOK_VARIABLE_NAME = "v.dart.workbook";
    String WORKSHEET_PROPERTY_NAME = "p.worksheet.to.be.added";
    String WORKSHEET_POSITION_PROPERTY_NAME = "p.worksheet.position";
    String WORKSHEET_COLUMN_WIDTH_NAME = "p.dart.spreadsheet.column.width"; 
    String[] HYPERLINK_PREFIXES = {"https://", "http://"};
    
    private String styleIDError = "error";
    private String styleIDWarning = "warning";
    private String styleIDInfo = "info";
    
    /**
     * Add main message as a sheet to the DART workbook. Assume the main message is in CSV format when this method is called on the assembly workflow.
     * @param ctx
     */
    @SuppressWarnings("deprecation")
	//@SuppressWarnings("deprecation")
    @ComponentMethod
    public void process(MediationContext ctx, java.io.OutputStream output) throws Exception {
        try{
            validateSetting(ctx);
            FileBackedManagedData dataStore = new FileBackedManagedData("text/plain");
            ctx.addDisposable(dataStore);
            Runtime rt = Runtime.getRuntime();
            long freeMem = rt.freeMemory();
            long maxMem = rt.maxMemory();
            long totalMem = rt.totalMemory();
           
            System.out.println("****Before Store: Free Memory= " + freeMem);
            System.out.println("****Before Store: Max Memory= " + maxMem);
            System.out.println("****Before Store: Total Memory= " + totalMem);
            
          //Override the temp file behavior
            TempFile.setTempFileCreationStrategy( new TempFileCreationStrategy() {
                   @Override
                   public File createTempFile(String prefix, String suffix) throws IOException {
                       MediationContext ctx = MediationTube.getCurrentMediationContext();
                       POITemporaryFile tmp_file = new POITemporaryFile( File.createTempFile(prefix, suffix) );
                       ctx.addDisposable( tmp_file );

                       return tmp_file.getFile();
                   }
                   public File createTempDirectory(String prefix) throws IOException{
                       MediationContext ctx = MediationTube.getCurrentMediationContext();
                       POITemporaryFile tmp_file = new POITemporaryFile( new File(prefix) );
                       ctx.addDisposable( tmp_file );

                       return tmp_file.getFile();
                   }
                   ;
               } );
            
            
            
            String sheetName = (String) ctx.getProperty(WORKSHEET_PROPERTY_NAME);
            Integer sheetPosition = (Integer) ctx.getProperty(WORKSHEET_POSITION_PROPERTY_NAME);
            int sheetColumnWidth = (Integer) ctx.getProperty(WORKSHEET_COLUMN_WIDTH_NAME);
            
            InputStream csvStream = (InputStream) ctx.getMessage().getMessagePart(0, InputStream.class);
            
            MessageVariable workBookMsgVar = ctx.getVariables().get(WORKBOOK_VARIABLE_NAME);
            XSSFWorkbook wb = null;
            if(workBookMsgVar != null) {
                wb = new XSSFWorkbook(workBookMsgVar.getInputStream());
            }
            else {
                wb = new XSSFWorkbook(); 
            }
            SXSSFWorkbook workBook = new SXSSFWorkbook((XSSFWorkbook) wb); 
    			workBook.setCompressTempFiles(true);
            CreationHelper helper = workBook.getCreationHelper();           
            SXSSFSheet sheet = workBook.createSheet(sheetName);          
                        
            CSVReader csvReader = new CSVReader(new InputStreamReader(csvStream), ',');
            
            String[] csvValues;
            int r = 0;
            Row row;
            Cell cell;
            int i = 0;
            int numHeaders = 2;
            int rowLength = 7;
            
            //Handle the title row first: Bold the title and set the column width
            CellStyle headerCellStyle = workBook.createCellStyle();
            headerCellStyle.setWrapText(true);
            headerCellStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
            
            Font headerFont = workBook.createFont();
            headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
            headerCellStyle.setFont(headerFont);
            csvValues = csvReader.readNext();
            row = sheet.createRow(r++); 
            
            for (i = 0; i < csvValues.length; i++){ //apply to each cell in header row
                cell = row.createCell(i);
                cell.setCellStyle(headerCellStyle);             
                cell.setCellValue(helper.createRichTextString(csvValues[i]));
                if (i == 4) {
                		sheet.setColumnWidth(i, 256*sheetColumnWidth*3);
                		System.out.println("****Widened column width to: " + 256*sheetColumnWidth*3); 
                } else {
                		sheet.setColumnWidth(i, 256*sheetColumnWidth);
                }
            } 
            
            csvValues = csvReader.readNext();
            row = sheet.createRow(r++);
            
            for (i = 0; i < csvValues.length; i++){ //apply to each cell in header row
                cell = row.createCell(i);
                cell.setCellStyle(headerCellStyle);             
                cell.setCellValue(helper.createRichTextString(csvValues[i]));
                if (i == 4) {
            			sheet.setColumnWidth(i, 256*sheetColumnWidth*3);
            			System.out.println("****Widened column width to: " + 256*sheetColumnWidth*3); 
                } else {
            			sheet.setColumnWidth(i, 256*sheetColumnWidth);
                }
            }    
            
            //Handle the data rows and cells.
            //to enable newlines that are needed, set a cell styles with wrap=true
            
            //define info, warning, and error cell styles
            
            XSSFCellStyle warningCellStyle = (XSSFCellStyle) workBook.createCellStyle();
            warningCellStyle.setWrapText(true);
            warningCellStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
            warningCellStyle.setFillForegroundColor(new XSSFColor(Color.decode("#FFEB9C"))); //yellow font: #9C6500 yellow background: #FFEB9C 
            warningCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            XSSFFont warningFont = (XSSFFont) workBook.createFont();
            //warningFont.setColor(new XSSFColor(Color.decode("#9C6500"))); //gives excel warning color
            //warningFont.setBold(true);
            warningCellStyle.setFont(warningFont);
            
            XSSFCellStyle warningWithFontColorCellStyle = (XSSFCellStyle) workBook.createCellStyle();
            warningWithFontColorCellStyle.setWrapText(true);
            warningWithFontColorCellStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
            warningWithFontColorCellStyle.setFillForegroundColor(new XSSFColor(Color.decode("#FFEB9C"))); //yellow font: #9C6500 yellow background: #FFEB9C 
            warningWithFontColorCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            XSSFFont warningFontWithColor = (XSSFFont) workBook.createFont();
            warningFontWithColor.setColor(new XSSFColor(Color.decode("#9C6500"))); //gives excel warning color
            warningFontWithColor.setBold(true);
            warningWithFontColorCellStyle.setFont(warningFontWithColor);
            
            
            XSSFCellStyle errorCellStyle = (XSSFCellStyle) workBook.createCellStyle();
            errorCellStyle.setWrapText(true);
            errorCellStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
            errorCellStyle.setFillForegroundColor(new XSSFColor(Color.decode("#FFC7CE"))); //red font: #9C0006 bad background: #FFC7CE
            errorCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            XSSFFont errorFont = (XSSFFont) workBook.createFont();
            //errorFont.setColor(new XSSFColor(Color.decode("#9C0006"))); //gives excel error color
            //errorFont.setBold(true);
            errorCellStyle.setFont(errorFont);
            
            XSSFCellStyle errorWithFontColorCellStyle = (XSSFCellStyle) workBook.createCellStyle();
            errorWithFontColorCellStyle.setWrapText(true);
            errorWithFontColorCellStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
            errorWithFontColorCellStyle.setFillForegroundColor(new XSSFColor(Color.decode("#FFC7CE"))); //red font: #9C0006 bad background: #FFC7CE
            errorWithFontColorCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            XSSFFont errorFontWithColor = (XSSFFont) workBook.createFont();
            errorFontWithColor.setColor(new XSSFColor(Color.decode("#9C0006"))); //gives excel error color
            errorFontWithColor.setBold(true);
            errorWithFontColorCellStyle.setFont(errorFontWithColor);
            
            while ((csvValues = csvReader.readNext()) != null) {
                    row = sheet.createRow(r++); //create new row
                    for (i = 0; i < csvValues.length; i++) { //iterate through cells in row
                        cell = row.createCell(i);
                      /*  if (csvValues[3].equals("WARNING")) { //produce Warning yellow font if you want
                        		if (i==3) {
                        			cell.setCellStyle(warningWithFontColorCellStyle);
                        		} else {
                            cell.setCellStyle(warningCellStyle);
                        		}
                        } else if (csvValues[3].equals("ERROR")) { //produce Error red font if you want
                        		if (i==3) {
                        			cell.setCellStyle(errorWithFontColorCellStyle);
                        		} else {
                            cell.setCellStyle(errorCellStyle);
                        		}
                        }*/
                        

                    if (csvValues[i] != null) {
                        csvValues[i] = csvValues[i].replaceAll("<br>", "\n");
                        cell.setCellValue(helper.createRichTextString(csvValues[i]));
            
                        } else {
                            System.out.println(csvValues[i]);
                            //cell.setCellType(Cell.CELL_TYPE_BLANK);
                        }
                    if(isHyperlink(csvValues[i])){
                        Hyperlink cellLink = helper.createHyperlink(Hyperlink.LINK_URL);
                        cellLink.setAddress(csvValues[i]);
                        cell.setHyperlink(cellLink);
                    }
                    }
            }
            
                    csvReader.close();
                
                    if (sheetPosition != null && sheetPosition >= 0) {
                        workBook.setSheetOrder(sheetName, sheetPosition);
                    }
                    
                    sheet.setAutoFilter(new CellRangeAddress(numHeaders-1, sheet.getLastRowNum(), 0, rowLength-1)); //takes format sheet.setAutoFilter(new CellRangeAddress(firstrow, lastrow, firstcol, lastcol));
                    System.out.println("****set auto filter"); 
                    
                    workBook.write(output);
            		
                    output.flush();
                    output.close();
                    workBook.dispose();
                    workBook.close();
                    freeMem = rt.freeMemory();
                    maxMem = rt.maxMemory();
                    totalMem = rt.totalMemory();
                   
                    System.out.println("****After Store:Free Memory= " + freeMem);
                    System.out.println("****After Store:Max Memory= " + maxMem);
                    System.out.println("****After Store:Total Memory= " + totalMem);  
            
                    return;          
            
        } catch (Exception ex) {
            System.out.println("Error occurs when writing a sheet to the DART workbook : " + ex.getMessage());
            ex.printStackTrace();
            throw ex;
        }
    }
    
    protected boolean isHyperlink(String strValue){
        boolean isHyperlink = false;
        String str = strValue.toLowerCase();
        for(int i = 0; i < HYPERLINK_PREFIXES.length; i++ ){
            if(str.startsWith(HYPERLINK_PREFIXES[i])){
                isHyperlink = true;
                break;
            }
        }
        return isHyperlink;
    }
    private void validateSetting(MediationContext ctx) throws Exception {
        if(ctx.getProperty(WORKSHEET_PROPERTY_NAME) == null || ((String)ctx.getProperty(WORKSHEET_PROPERTY_NAME)).isEmpty()){
            throw new Exception("Tried to add a sheet to the DART workbook, but the sheet name isn't provided!");
        }       
    }
}

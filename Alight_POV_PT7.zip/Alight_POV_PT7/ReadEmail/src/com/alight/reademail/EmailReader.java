package com.alight.reademail;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Flags.Flag;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;

import org.jsoup.Jsoup;

public class EmailReader {
	
	public static ArrayList getUnreadMessages() throws MessagingException, IOException {
     	
   	 
    	ArrayList unreadMessages = new java.util.ArrayList(); 
     	ParsedEmail email = new ParsedEmail();
     	String ccEmailAddress = "";
     	String result = "";
     	
     	Properties properties = new Properties();

 		properties.put("mail.imap.host", "imap.gmail.com");
 		properties.put("mail.imap.port", "993");
 		properties.put("mail.imap.starttls.enable", "true");
 		properties.put("mail.imap.ssl.trust", "imap.gmail.com");

 		Session emailSession = Session.getDefaultInstance(properties);

 		// create the imap store object and connect to the imap server
 		Store store = emailSession.getStore("imaps");

 		store.connect("imap.gmail.com", "hrdepartmentclt@gmail.com", "JTPHttj4!");

 		// create the inbox object and open it
 		Folder inbox = store.getFolder("Inbox");
 		inbox.open(Folder.READ_WRITE);

 		// retrieve the messages from the folder in an array and print it
 		 Message[] messages = inbox.search(new FlagTerm(new Flags(Flag.SEEN), false));
 		 for (int i = 0, n = messages.length; i < n; i++) {
			Message message = messages[i];
			message.setFlag(Flag.SEEN, true);
			//unreadMessages.add(message);
			email = new ParsedEmail();
			//System.out.println("---------------------------------");
			//System.out.println("Email Number " + (i + 1));
			//System.out.println("MessageNumber" + message.getMessageNumber());
			//System.out.println("Subject: " + message.getSubject());
			//System.out.println("From: " + message.getFrom()[0]);
			//System.out.println("Text: " + message.getContent().toString());
			System.out.println(message.getSubject());
			email.setSubject(message.getSubject());
			
			Address[] recipients = message.getRecipients(Message.RecipientType.CC);
			//Address[] recipients = message.getAllRecipients();
			
			ccEmailAddress = "";
			result = "";
			for (Address address : recipients) {
				ccEmailAddress = ccEmailAddress + address.toString() + ",";
			}
			 
			 String parsedText = "";
			 MimeMultipart mimeMultipart = (MimeMultipart)message.getContent();
			 int count = mimeMultipart.getCount();
			 for (int j = 0; j < count; j ++){
		            BodyPart bodyPart = mimeMultipart.getBodyPart(j);
		            parsedText = getText(bodyPart);
		            if(parsedText != null) {
		            	result  = parsedText;
		            }
			 }
			
			
		
		email.setCc(ccEmailAddress);
		email.setBody( email.getSubject() + "\n\n\n" + result);
		unreadMessages.add(email);
		}
     	return unreadMessages;
     }  
     
	
	public static String getText(Part p) throws MessagingException, IOException {
		if (p.isMimeType("text/*")) {
			String s = (String) p.getContent();
			boolean textIsHtml = p.isMimeType("text/html");
			if(textIsHtml) {
				
				s = Jsoup.parse(p.getContent().toString()).text();
				
			}
			return s;
		}

		if (p.isMimeType("multipart/alternative")) {
			// prefer html text over plain text
			Multipart mp = (Multipart) p.getContent();
			String text = null;
			for (int i = 0; i < mp.getCount(); i++) {
				Part bp = mp.getBodyPart(i);
				if (bp.isMimeType("text/plain")) {
					if (text == null)
						text = getText(bp);
					continue;
				} else if (bp.isMimeType("text/html")) {
					//String s = getText(bp);
					String s = Jsoup.parse(mp.getBodyPart(i).getContent().toString()).text();
					if (s != null)
						return s;
				} else {
					return getText(bp);
				}
			}
			return text;
		} else if (p.isMimeType("multipart/*")) {
			Multipart mp = (Multipart) p.getContent();
			for (int i = 0; i < mp.getCount(); i++) {
				
				String s = Jsoup.parse(mp.getBodyPart(i).getContent().toString()).text();
				//String s = getText(mp.getBodyPart(i));
				if (s != null)
					return s;
			}
		}

		return null;
	}

}

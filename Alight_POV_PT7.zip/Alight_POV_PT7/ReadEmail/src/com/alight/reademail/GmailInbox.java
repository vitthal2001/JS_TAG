package com.alight.reademail;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
 
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;
 
public class GmailInbox {
 
    public static void main(String[] args) {
 
        GmailInbox gmail = new GmailInbox();
        gmail.read();
 
    }
    
    public  int CallRead() {
    	
    	read();
    	return  4;
    	
    }
 
    public void read() {
 
        Properties props = new Properties();
 
        try {


        	//System.setProperty("http.proxyHost", "proxycacheST.hewitt.com");
        	//System.setProperty("http.proxyPort", "3228");
        	
        	

        	props.put("mail.smtp.host", "smtp.gmail.com");
        	props.put("mail.smtp.socketFactory.port", "465");
        	props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        	props.put("mail.smtp.auth", true);
        	props.put("mail.smtp.port", "465");
        	props.put("mail.smtp.ssl.enable", true);
        	
        	
        	
            //props.load(new FileInputStream(new File("C:\\workday_workspace\\ReadGmail\\src\\net\\codejava\\mail\\smtp.properties")));
            Session session = Session.getDefaultInstance(props, null);
 
            Store store = session.getStore("imaps");
            store.connect("smtp.gmail.com", "hrdepartmentclt@gmail.com", "JTPHttj4!");
 
            Folder inbox = store.getFolder("inbox");
            inbox.open(Folder.READ_ONLY);
            int messageCount = inbox.getMessageCount();
 
            System.out.println("Total Messages:- " + messageCount);
 
            Message[] messages = inbox.getMessages();
            System.out.println("------------------------------");
 
            for (int i = 0; i < 10; i++) {
                System.out.println("Mail Subject:- " + messages[i].getSubject());
                
                
            }
 
            inbox.close(true);
            store.close();
 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 
}
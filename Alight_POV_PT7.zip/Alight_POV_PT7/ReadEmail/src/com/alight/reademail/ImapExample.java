package com.alight.reademail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;
import org.jsoup.Jsoup;

public class ImapExample {
	public static void check(String host, String storeType, String user, String password) {
		try {

			// create properties
			Properties properties = new Properties();

			properties.put("mail.imap.host", host);
			properties.put("mail.imap.port", "993");
			properties.put("mail.imap.starttls.enable", "true");
			properties.put("mail.imap.ssl.trust", host);

			Session emailSession = Session.getDefaultInstance(properties);

			// create the imap store object and connect to the imap server
			Store store = emailSession.getStore("imaps");

			store.connect(host, user, password);

			// create the inbox object and open it
			Folder inbox = store.getFolder("Inbox");
			inbox.open(Folder.READ_WRITE);

			// retrieve the messages from the folder in an array and print it
			 //Message[] messages = inbox.search(new FlagTerm(new Flags(Flag.SEEN), true));
			//System.out.println("messages.length---" + messages.length);
			
			Message message = inbox.getMessage(15);
			  message.setFlag(Flag.SEEN, false);
			System.out.println("MessageNumber" + message.getMessageNumber());
			System.out.println("Subject: " + message.getSubject());
			System.out.println("From: " + message.getFrom()[0]);
			System.out.println("Text: " + message.getContent().toString());
			
			 MimeMultipart mimeMultipart = (MimeMultipart)message.getContent();
			 int count = mimeMultipart.getCount();
			 for (int j = 0; j < count; j ++){
		            BodyPart bodyPart = mimeMultipart.getBodyPart(j);
		            System.out.println("isMimeType(\"text/*\")" + bodyPart.isMimeType("text/*"));
		            System.out.println("text/html" + bodyPart.isMimeType("text/html"));
		            System.out.println("multipart/alternative" + bodyPart.isMimeType("multipart/alternative"));
		            System.out.println("*********************************      "+ j +"         *********");
		            System.out.println(getText(bodyPart));
		            
			 }

			 /* for (int i = 0, n = messages.length; i < n; i++) {
				Message message = messages[i];
			   message.setFlag(Flag.SEEN, false);
				
				
				
				System.out.println("---------------------------------");
				System.out.println("Email Number " + (i + 1));
				System.out.println("MessageNumber" + message.getMessageNumber());
				System.out.println("Subject: " + message.getSubject());
				System.out.println("From: " + message.getFrom()[0]);
				System.out.println("Text: " + message.getContent().toString());
				
				
				
			} */
			
			// New code to look by the message Id
              
			//Message message = inbox.getMessage(6);
			
			/* List<String> toAddresses = new ArrayList<String>();
			//Address[] recipients = message.getRecipients(Message.RecipientType.);
			Address[] recipients = message.getFrom();
			for (Address address : recipients) {
			    toAddresses.add(address.toString());
			} */
			
			
			
			
			
			
			/* System.out.println("MessageNumber" + message.getMessageNumber());
			System.out.println("Subject: " + message.getSubject());
			System.out.println("From: " + message.getFrom()[0]);
			System.out.println("Text: " + message.getContent().toString());
			
			 /*String result = "";
			 MimeMultipart mimeMultipart = (MimeMultipart)message.getContent();
			 int count = mimeMultipart.getCount();
			 for (int i = 0; i < count; i ++){
		            BodyPart bodyPart = mimeMultipart.getBodyPart(i);
		            if (bodyPart.isMimeType("text/plain")){
		                result = result + "\n" + bodyPart.getContent();
		                break;  //without break same text appears twice in my tests
		            } else if (bodyPart.isMimeType("text/html")){
		                String html = (String) bodyPart.getContent();
		                result = result + "\n" + Jsoup.parse(html).text();

		            }
		        }
			 
			 System.out.println("result =>" + result);
			*/
			inbox.close(false);
			store.close();

		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static String getText(Part p) throws MessagingException, IOException {
		if (p.isMimeType("text/*")) {
			String s = (String) p.getContent();
			boolean textIsHtml = p.isMimeType("text/html");
			if(textIsHtml) {
				
				s = Jsoup.parse(p.getContent().toString()).text();
				
			}
			return s;
		}

		if (p.isMimeType("multipart/alternative")) {
			// prefer html text over plain text
			Multipart mp = (Multipart) p.getContent();
			String text = null;
			for (int i = 0; i < mp.getCount(); i++) {
				Part bp = mp.getBodyPart(i);
				if (bp.isMimeType("text/plain")) {
					if (text == null)
						text = getText(bp);
					continue;
				} else if (bp.isMimeType("text/html")) {
					//String s = getText(bp);
					String s = Jsoup.parse(mp.getBodyPart(i).getContent().toString()).text();
					if (s != null)
						return s;
				} else {
					return getText(bp);
				}
			}
			return text;
		} else if (p.isMimeType("multipart/*")) {
			Multipart mp = (Multipart) p.getContent();
			for (int i = 0; i < mp.getCount(); i++) {
				
				String s = Jsoup.parse(mp.getBodyPart(i).getContent().toString()).text();
				//String s = getText(mp.getBodyPart(i));
				if (s != null)
					return s;
			}
		}

		return null;
	}

	public static FileOutputStream getMessage(String host, String storeType, String user, String password) {
		
		Message message = null;
		FileOutputStream fstream  = null;
		try {

			// create properties
			Properties properties = new Properties();

			properties.put("mail.imap.host", host);
			properties.put("mail.imap.port", "993");
			properties.put("mail.imap.starttls.enable", "true");
			properties.put("mail.imap.ssl.trust", host);

			Session emailSession = Session.getDefaultInstance(properties);

			// create the imap store object and connect to the imap server
			Store store = emailSession.getStore("imaps");

			store.connect(host, user, password);

			// create the inbox object and open it
			Folder inbox = store.getFolder("Inbox");
			inbox.open(Folder.READ_WRITE);

			// retrieve the messages from the folder in an array and print it
			/* Message[] messages = inbox.search(new FlagTerm(new Flags(Flag.SEEN), false));
			System.out.println("messages.length---" + messages.length);

			for (int i = 0, n = messages.length; i < n; i++) {
				Message message = messages[i];
				//message.setFlag(Flag.SEEN, false);
				
				
				
				System.out.println("---------------------------------");
				System.out.println("Email Number " + (i + 1));
				System.out.println("MessageNumber" + message.getMessageNumber());
				System.out.println("Subject: " + message.getSubject());
				System.out.println("From: " + message.getFrom()[0]);
				System.out.println("Text: " + message.getContent().toString());
				
			} */
			
			// New code to look by the message Id
              
			message = inbox.getMessage(2);
			System.out.println("MessageNumber" + message.getMessageNumber());
			System.out.println("Subject: " + message.getSubject());
			System.out.println("From: " + message.getFrom()[0]);
			System.out.println("Text: " + message.getContent().toString());
			
			
			File myfile = new File("message.eml");
			fstream = new FileOutputStream(myfile);
			
			message.writeTo(fstream);
			
			
			inbox.close(false);
			store.close();

		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return fstream;
	}

	public static void main(String[] args) throws MessagingException, IOException {

		String host = "imap.gmail.com";
		String mailStoreType = "imap";
		String username = "hrdepartmentclt@gmail.com";
		String password = "JTPHttj4!";

		//check(host, mailStoreType, username, password);
		
		ParsedEmail email = getParesedEmail();
		
		System.out.println("CC=>"+email.getCc());
		System.out.println("Body=>"+email.getBody());
		System.out.println("Subject=>"+email.getSubject());
		

	}
	
	public static int  callReadEmail() {
		
		
		String host = "imap.gmail.com";
		String mailStoreType = "imap";
		String username = "hrdepartmentclt@gmail.com";
		String password = "JTPHttj4!";

		check(host, mailStoreType, username, password);
		
		return 0;
	}
	
     public FileOutputStream   callGetMessage() {
		
		
		String host = "imap.gmail.com";
		String mailStoreType = "imap";
		String username = "hrdepartmentclt@gmail.com";
		String password = "JTPHttj4!";

		//check(host, mailStoreType, username, password);
		
		return getMessage(host, mailStoreType, username, password);
	}
     
     
     public static ArrayList getUnreadMessages() throws MessagingException, IOException {
     	
    	 
    	ArrayList unreadMessages = new java.util.ArrayList(); 
     	ParsedEmail email = new ParsedEmail();
     	String ccEmailAddress = "";
     	String result = "";
     	
     	Properties properties = new Properties();

 		properties.put("mail.imap.host", "imap.gmail.com");
 		properties.put("mail.imap.port", "993");
 		properties.put("mail.imap.starttls.enable", "true");
 		properties.put("mail.imap.ssl.trust", "imap.gmail.com");

 		Session emailSession = Session.getDefaultInstance(properties);

 		// create the imap store object and connect to the imap server
 		Store store = emailSession.getStore("imaps");

 		store.connect("imap.gmail.com", "hrdepartmentclt@gmail.com", "JTPHttj4!");

 		// create the inbox object and open it
 		Folder inbox = store.getFolder("Inbox");
 		inbox.open(Folder.READ_WRITE);

 		// retrieve the messages from the folder in an array and print it
 		 Message[] messages = inbox.search(new FlagTerm(new Flags(Flag.SEEN), false));
 		 for (int i = 0, n = messages.length; i < n; i++) {
			Message message = messages[i];
			message.setFlag(Flag.SEEN, true);
			//unreadMessages.add(message);
			email = new ParsedEmail();
			//System.out.println("---------------------------------");
			//System.out.println("Email Number " + (i + 1));
			//System.out.println("MessageNumber" + message.getMessageNumber());
			//System.out.println("Subject: " + message.getSubject());
			//System.out.println("From: " + message.getFrom()[0]);
			//System.out.println("Text: " + message.getContent().toString());
			System.out.println(message.getSubject());
			email.setSubject(message.getSubject());
			
			Address[] recipients = message.getRecipients(Message.RecipientType.CC);
			//Address[] recipients = message.getAllRecipients();
			
			ccEmailAddress = "";
			result = "";
			for (Address address : recipients) {
				ccEmailAddress = ccEmailAddress + address.toString() + ",";
			}
			 
			 String parsedText = "";
			 MimeMultipart mimeMultipart = (MimeMultipart)message.getContent();
			 int count = mimeMultipart.getCount();
			 for (int j = 0; j < count; j ++){
		            BodyPart bodyPart = mimeMultipart.getBodyPart(j);
		            parsedText = getText(bodyPart);
		            if(parsedText != null) {
		            	result  = parsedText;
		            }
			 }
			
			
		
		email.setCc(ccEmailAddress);
		email.setBody( email.getSubject() + "\n\n\n" + result);
		unreadMessages.add(email);
		}
     	return unreadMessages;
     }  
     

    
    
 public static ParsedEmail getParesedEmail() throws MessagingException, IOException {
    	
    	ParsedEmail email = new ParsedEmail();
    	String ccEmailAddress = "";
    	String result = "";
    	
    	Properties properties = new Properties();

		properties.put("mail.imap.host", "imap.gmail.com");
		properties.put("mail.imap.port", "993");
		properties.put("mail.imap.starttls.enable", "true");
		properties.put("mail.imap.ssl.trust", "imap.gmail.com");

		Session emailSession = Session.getDefaultInstance(properties);

		// create the imap store object and connect to the imap server
		Store store = emailSession.getStore("imaps");

		store.connect("imap.gmail.com", "hrdepartmentclt@gmail.com", "JTPHttj4!");

		// create the inbox object and open it
		Folder inbox = store.getFolder("Inbox");
		inbox.open(Folder.READ_WRITE);

		// retrieve the messages from the folder in an array and print it
		 //Message[] messages = inbox.search(new FlagTerm(new Flags(Flag.SEEN), false));
    	 
		
				Message message = inbox.getMessage(1);
				message.setFlag(Flag.SEEN, false);
				
				//System.out.println("---------------------------------");
				//System.out.println("Email Number " + (i + 1));
				//System.out.println("MessageNumber" + message.getMessageNumber());
				//System.out.println("Subject: " + message.getSubject());
				//System.out.println("From: " + message.getFrom()[0]);
				//System.out.println("Text: " + message.getContent().toString());
				System.out.println(message.getSubject());
				email.setSubject(message.getSubject());
				
				Address[] recipients = message.getRecipients(Message.RecipientType.CC);
				//Address[] recipients = message.getAllRecipients();
				
				ccEmailAddress = "";
				result = "";
				for (Address address : recipients) {
					ccEmailAddress = ccEmailAddress + address.toString() + ",";
				}
				 
				 String parsedText = "";
				 MimeMultipart mimeMultipart = (MimeMultipart)message.getContent();
				 int count = mimeMultipart.getCount();
				 for (int j = 0; j < count; j ++){
			            BodyPart bodyPart = mimeMultipart.getBodyPart(j);
			            parsedText = getText(bodyPart);
			            if(parsedText != null) {
			            	result  = parsedText;
			            }
				 }
				
				 //System.out.println("result =>" + result);
			
			
			email.setCc(ccEmailAddress);
			email.setBody( email.getSubject() + "\n\n\n" + result);
    	
    	return email;
    }
    
    public static String getTextFromMimeMultipart(
            MimeMultipart mimeMultipart)  throws MessagingException, IOException{
        String result = "";
        int count = mimeMultipart.getCount();
        for (int i = 0; i < count; i++) {
            BodyPart bodyPart = mimeMultipart.getBodyPart(i);
            if (bodyPart.isMimeType("text/plain")) {
                result = result + "\n" + bodyPart.getContent();
                break; // without break same text appears twice in my tests
            } else if (bodyPart.isMimeType("text/html")) {
                String html = (String) bodyPart.getContent();
                result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
            } else if (bodyPart.getContent() instanceof MimeMultipart){
                result = result + getTextFromMimeMultipart((MimeMultipart)bodyPart.getContent());
            }
        }
        return result;
    }
    
}

package transitionator;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.assembly.annotation.Property;
import com.capeclear.mediation.MediationMessage;

import sun.misc.BASE64Encoder;

import static com.capeclear.assembly.annotation.Component.Type.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;


/**
 * Custom mediation
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "otherthingy",
        type = mediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/otherthingy_16.png",
        largeIconPath = "icons/otherthingy_24.png"
        )
public class otherthingy {

    /**
     * This method is called by the Assembly framework.
     *
     * Use the <code>MediationContext</code> to access objects in the context,
     * such as the message, properties and variables e.g.
     * <ul>
     * <li><code>MediationMessage msg = arg0.getMessage();</code></li>
     * <li><code>String myPropValue = (String)arg0.getProperty("myprop");</code></li>
     * <li><code>Source myVar = arg0.getVariables().getVariable("myvar");</code></li>
     * </ul>    
     * @throws IOException 
     * @throws NoSuchAlgorithmException 
     * @throws InvalidKeySpecException 
     * @throws NoSuchPaddingException 
     * @throws InvalidKeyException 
     * @throws BadPaddingException 
     * @throws IllegalBlockSizeException 
     */
    @ComponentMethod
    public void process(com.capeclear.mediation.MediationContext arg0) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        // TODO implement
	    	MediationMessage message = arg0.getMessage();
	    	String thingy = message.getRootPartAsText();
			String key64 = "-----BEGIN PUBLIC KEY-----\r\n" + 
					"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAha2kPH/cIVx35L6KGEcB\r\n" + 
					"9eQ5hRDdbEf+IShvxo2m/gSrjbKFrmBCSCMo7VS/KQW08O2azJ3otP/ne4pC4MZ9\r\n" + 
					"8VsvfPAK4iqmrWcNK+DTPvg4oylNy6cMRdk9msdbf6a9K2VxYCmtSop/B19BzVAP\r\n" + 
					"w//xsVgCSNo7m60S3LiWLbVpVgRPDpZbDWVCpUV7/Ef8Qf/YIXoH0yfzuLl7CM6n\r\n" + 
					"wg98z4sMoqTpGnLZ8K9dqMEeAK5xxG/mKpBXEqx0XR2jzsAHjwxBVT2m3tnU4sFq\r\n" + 
					"u3+Jjxfs+tDYwl/vgQPzxV6escIDH78ac93TVsbM+PuCljpAvC2+h3kwxz5rImJ4\r\n" + 
					"lQIDAQAB\r\n" + 
					"-----END PUBLIC KEY-----\r\n" + 
					"";
		    BASE64Encoder encoder = new BASE64Encoder();
		    byte[] clear = key64.getBytes(StandardCharsets.UTF_8);
			X509EncodedKeySpec publicSpec = new X509EncodedKeySpec(clear);
	        KeyFactory keyFactory;
			keyFactory = KeyFactory.getInstance("RSA");
			PublicKey key = keyFactory.generatePublic(publicSpec);
			Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA1AndMGF1Padding");   
		    cipher.init(Cipher.ENCRYPT_MODE, key);  
		    byte[] encryptedBase64Thingy = cipher.doFinal(thingy.getBytes(StandardCharsets.UTF_8));
		    String encryptedThingy = new String(encryptedBase64Thingy, StandardCharsets.UTF_8);
	    	message.setRootPartAsText(encryptedThingy);
    }
}

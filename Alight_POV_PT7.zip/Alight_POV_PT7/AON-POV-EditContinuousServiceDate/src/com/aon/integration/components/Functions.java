package com.aon.integration.components;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.xml.bind.DatatypeConverter;
import javax.xml.transform.Source;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.capeclear.assembly.impl.AssemblyUtils;
import com.capeclear.mediation.impl.mediators.utils.XPathHelper;

public class Functions {

	private Functions() {

	}

	public static String truncateSchemaDateTime(String dateTime) {
		return truncateSchemaDateTime(dateTime, false);
	}

	public static String truncateSchemaDateTime(String dateTime,
			boolean removeTimezone) {
		if (dateTime == null || dateTime.length() == 0) {
			return dateTime;
		}
		String date = dateTime;
		int posT = dateTime.indexOf('T');
		// check that date is a schema dateTime
		if (posT > -1) {
			// extract the date component
			date = date.substring(0, posT);
			// should the timezone be appended
			if (!removeTimezone) {
				// search for presence of timezone; search for '-', '+', or 'Z'
				int posTz = dateTime.indexOf('-', posT + 1);
				if (posTz < 0) {
					posTz = dateTime.indexOf('+', posT + 1);
					if (posTz < 0) {
						posTz = dateTime.indexOf('Z', posT + 1);
					}
				}
				// was a timezone a component found
				// f (posTz > -1) {
				// date += dateTime.substring(posTz);
				// }
			}
		}

		return date;
	}

	public static String truncateTime(String dateTime) {
		if (dateTime == null || dateTime.length() == 0) {
			return dateTime;
		}
		String time = dateTime;
		int posT = dateTime.indexOf('T');
		// check that time is a schema dateTime
		if (posT > -1) {
			// extract the time component
			time = time.substring(posT + 1, posT + 6);

		}

		return time;
	}

	public static String listToCommaDelimString(List<String> list) {
		if (list == null || list.size() < 1) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		for (String item : list) {
			sb.append(item).append(',');
		}
		if (sb.length() > 0) {
			// remove trailing ','
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}

	public static String xpathToCommaDelimString(String xpath, Source source) {
		return xpathToCommaDelimString(xpath, null, source);
	}

	@SuppressWarnings("unchecked")
	public static String xpathToCommaDelimString(String xpath,
			String namespaces, Source source) {
		StringBuilder sb = new StringBuilder();
		XPathHelper helper = new XPathHelper("PayrollInterfaceFunctions",
				xpath, namespaces, AssemblyUtils.getAssemblyNSMapping());
		try {
			List<Node> nodeList = helper.evaluate(source);
			for (Node node : nodeList) {
				NodeList cnl = node.getChildNodes();
				if (cnl.getLength() == 1) {
					Node cnode = cnl.item(0);
					if (cnode.getNodeType() == Node.TEXT_NODE
							|| cnode.getNodeType() == Node.CDATA_SECTION_NODE) {
						sb.append(cnode.getTextContent()).append(',');
					}
				}
			}
		} catch (Throwable t) {
			throw new RuntimeException("Error occured evaluating XPath '"
					+ xpath + "' as a comma delim list: " + t.getMessage(), t);
		}
		if (sb.length() > 0) {
			// remove trailing ','
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}

	/**
	 * Compares schema DateTime values
	 * 
	 * @param dateTimeString1
	 *            the String DateTime to compared against
	 * @param dateTimeString2
	 *            the String DateTime to compared with
	 * @return the value <code>0</code> if the DateTime represented by
	 *         dateTimeString2 is equal to the DateTime represented by
	 *         dateTimeString1; a value less than <code>0</code> if the DateTime
	 *         of dateTimeString1 is before the DateTime represented by the
	 *         dateTimeString2; and a value greater than <code>0</code> if the
	 *         DateTime of dateTimeString1 is after the DateTime represented by
	 *         dateTimeString2.
	 */
	public static final int compareDateTimes(String dateTimeString1,
			String dateTimeString2) {
		Calendar dateTime1 = DatatypeConverter.parseDateTime(dateTimeString1);
		Calendar dateTime2 = DatatypeConverter.parseDateTime(dateTimeString2);
		return dateTime1.compareTo(dateTime2);
	}

	public static final int compareDates(String dateString1, String dateString2) {
		Calendar date1 = DatatypeConverter.parseDate(dateString1);
		Calendar date2 = DatatypeConverter.parseDate(dateString2);

		date1 = truncDateTime(date1);
		date2 = truncDateTime(date2);

		return date1.compareTo(date2);
	}

	public static final Calendar truncDateTime(Calendar dateTime) {
		Calendar truncDate = (Calendar) dateTime.clone();
		truncDate.set(Calendar.HOUR_OF_DAY, 0);
		truncDate.set(Calendar.HOUR, 0);
		truncDate.set(Calendar.MINUTE, 0);
		truncDate.set(Calendar.SECOND, 0);
		truncDate.set(Calendar.MILLISECOND, 0);
		return truncDate;
	}

	public static String subtractOneDayFromDate(String dateIn) {
		if (dateIn == null || dateIn.length() == 0) {
			return dateIn;
		}

		String dateFormatted = truncateSchemaDateTime(dateIn, true);
		Calendar dateCalendar = DatatypeConverter.parseDate(dateFormatted);

		dateCalendar.add(Calendar.DAY_OF_MONTH, -1);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date = sdf.format(dateCalendar.getTime());

		return date;
	}

	public static String addOneDayFromDate(String dateIn) {
		if (dateIn == null || dateIn.length() == 0) {
			return dateIn;
		}

		String dateFormatted = truncateSchemaDateTime(dateIn, true);
		Calendar dateCalendar = DatatypeConverter.parseDate(dateFormatted);

		dateCalendar.add(Calendar.DAY_OF_MONTH, 1);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date = sdf.format(dateCalendar.getTime());

		return date;
	}

	public static String addNinetyDayFromDate(String dateIn) {
		if (dateIn == null || dateIn.length() == 0) {
			return dateIn;
		}

		String dateFormatted = truncateSchemaDateTime(dateIn, true);
		Calendar dateCalendar = DatatypeConverter.parseDate(dateFormatted);

		dateCalendar.add(Calendar.DAY_OF_MONTH, 90);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date = sdf.format(dateCalendar.getTime());

		return date;
	}

	public static String subtractNinetyDayFromDate(String dateIn) {
		if (dateIn == null || dateIn.length() == 0) {
			return dateIn;
		}

		String dateFormatted = truncateSchemaDateTime(dateIn, true);
		Calendar dateCalendar = DatatypeConverter.parseDate(dateFormatted);

		dateCalendar.add(Calendar.DAY_OF_MONTH, -90);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date = sdf.format(dateCalendar.getTime());

		return date;
	}

	public static String reformatDateTime(String dateIn) {

		String dateOut = dateIn.substring(0, 10);

		String dd = dateOut.substring(8, 10);
		String mm = dateOut.substring(5, 7);
		String yy = dateOut.substring(0, 4);

		String date = dd.concat("/").concat(mm).concat("/").concat(yy);

		return date;
	}

	public static String addYearsToDate(String dateIn, Integer yrs) {
		if (dateIn == null || dateIn.length() == 0) {
			return dateIn;
		}

		String dateFormatted = truncateSchemaDateTime(dateIn, true);
		Calendar dateCalendar = DatatypeConverter.parseDate(dateFormatted);

		dateCalendar.add(Calendar.YEAR, yrs);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date = sdf.format(dateCalendar.getTime());

		return date;
	}

	public static String addMonthsToDate(String dateIn, Integer mnth) {
		if (dateIn == null || dateIn.length() == 0) {
			return dateIn;
		}

		String dateFormatted = truncateSchemaDateTime(dateIn, true);
		Calendar dateCalendar = DatatypeConverter.parseDate(dateFormatted);

		dateCalendar.add(Calendar.MONTH, mnth);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date = sdf.format(dateCalendar.getTime());

		return date;
	}

}

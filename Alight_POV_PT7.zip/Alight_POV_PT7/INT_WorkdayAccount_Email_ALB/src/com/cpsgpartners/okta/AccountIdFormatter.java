package com.cpsgpartners.okta;

//http://stackoverflow.com/questions/3322152/is-there-a-way-to-get-rid-of-accents-and-convert-a-whole-string-to-regular-lette
public class AccountIdFormatter {

	public static String format(final String text, int counter) {
		String newText = java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFKD);
		newText = newText.replaceAll("[^\\p{ASCII}]", "");
		newText = newText.replaceAll("\\s", "");
		if (counter > 0 && counter <= 10) {
			newText = String.format("%s%01d", newText, counter);
		} else if (counter > 10) {
			newText = String.format("%s%02d", newText, counter);
		}
		return newText;
	}
	
	public static String formatstring(final String text) {
		String newText = java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFKD);
		newText = newText.replaceAll("[^\\p{ASCII}]", "");
		newText = newText.replaceAll("\\s", "");
		newText = newText.replaceAll(" ", "");
		//newText = newText.replaceAll("\\.+", "");
		newText = newText.replaceAll("[^a-zA-Z0-9]", "");
		
		
		return newText;
	}
	
	public static boolean isUserNameNeededChange(final String text){
		
		boolean changeNeeded=false;
		String newText = java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFKD);
		newText = newText.replaceAll("[^\\p{ASCII}]", "");
		newText = newText.replaceAll("\\s", "");
		newText = newText.replaceAll(" ", "");
		
		if(!text.equals(newText)) {
			changeNeeded = true;
		}
		return changeNeeded;
	 
	}
	
	public static String format3(final String first,final String last, int counter) {
		String newFirst = java.text.Normalizer.normalize(first, java.text.Normalizer.Form.NFKD);
		String newLast = java.text.Normalizer.normalize(last, java.text.Normalizer.Form.NFKD);
		String finaltext = null ;
		//newFirst = "firstname";
		//newLast = "lastname";
		String newText = "";
		newFirst = newFirst.replaceAll("[^\\p{ASCII}]", "");
		newFirst = newFirst.replaceAll("\\s", "");
		newFirst = newFirst.replaceAll("[^a-zA-Z0-9]", "");
		newFirst = newFirst.replaceAll(" ", "");
		newLast = newLast.replaceAll("[^\\p{ASCII}]", "");
		newLast = newLast.replaceAll("\\s", "");
		newLast = newLast.replaceAll("[^a-zA-Z0-9]", "");
		newLast = newLast.replaceAll(" ", "");
		
		int fcounter = newFirst.length();
		int lcounter = newLast.length();
		
		
	if (counter == 0){
		newText =  newFirst + "." + newLast ;
		
	}
		
	
	else {
		newText =  newFirst + "." + newLast;		
		newText = String.format("%s%01d", newText, counter+1) ;
	}
	
		
		
		
		return newText;
		
		
		
		
	}
	

}

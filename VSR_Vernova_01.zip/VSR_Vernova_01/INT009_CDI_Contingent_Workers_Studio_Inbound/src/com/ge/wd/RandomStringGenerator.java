package com.ge.wd;

import static com.capeclear.assembly.annotation.Component.Type.mediation;
import static org.apache.commons.lang3.RandomStringUtils.random;
import static org.apache.commons.lang3.RandomStringUtils.randomAscii;

import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;

@Component(name = "RandomStringGenerator", type = mediation, toolTip = "", scope = "prototype")
public class RandomStringGenerator {

	private static final String LOWER_CASE = "abcdefghijklmnopqrstuvwxyz";
	private static final String UPPER_CASE = LOWER_CASE.toUpperCase();
	private static final String NUMBERS = "1234567890";
	/* private static final String SPECIAL = "!\"#$%&'()*+,-./:;=?@[\\]^_`{|}~"; */
	private static final String SPECIAL = "!#$%()[]{}";

	@ComponentMethod
	public void generate(com.capeclear.mediation.MediationContext context) {

		/* context.setProperty("password", random(1, UPPER_CASE) + random(1, LOWER_CASE) + random(1, NUMBERS)
				+ random(1, SPECIAL) + randomAscii(6)); */
		context.setProperty("password", random(1, UPPER_CASE) + random(1, LOWER_CASE) + random(1, NUMBERS)
		+ random(1, SPECIAL) + random(3,UPPER_CASE) + random(1, NUMBERS) + random(2, LOWER_CASE));
	}
}
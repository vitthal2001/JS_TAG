package com.workday.custom.int5030;

import com.capeclear.mediation.MediationContext;
import com.workday.mediation.impl.mediators.etv.ETVInfo;

public class ReportValidationsHelper {

    public static final String PROP_HELPER = "wix.etv.report.validations.helper";

    // Child context thread / current instance properties
    public static final String PROP_ETV_MAX_MESSAGES = "etv.max.messages";
    public static final String PROP_ETV_MAX_TOTAL_MESSAGES = "etv.max.total.messages";
    public static final String PROP_ETV_REPORTED_MESSAGES = "etv.reported.messages";
    public static final String PROP_ETV_REPORT_CURRENT_MESSAGE = "etv.report.current.message";
    public static final String PROP_ETV_REPORT_MAX_REACHED = "etv.report.max.reached";
    public static final String PROP_ETV_MAX_REACHED_TYPE = "etv.max.reached.type";
    public static final String PROP_ETV_INFO = "etv.info";

    // Parent context thread / overall state properties
    public static final String PROP_ETV_TOTAL_REPORTED_MESSAGES = "etv.total.reported.messages";
    public static final String PROP_ETV_MAX_SEVERITY_REPORTED = "etv.max.severity.reported";
    public static final String PROP_ETV_TOTAL_MAX_REACHED_REPORTED = "etv.total.max.reached.reported";

    private final MediationContext parentContext;
    private final Object syncLock; // for synchronization only

    private ReportValidationsHelper(final MediationContext context) {
        this.parentContext = context;
        this.syncLock = new Object();
        if (context.getProperty(PROP_ETV_TOTAL_REPORTED_MESSAGES) == null) {
            context.setProperty(PROP_ETV_TOTAL_REPORTED_MESSAGES, 0);
        }
        if (context.getProperty(PROP_ETV_MAX_SEVERITY_REPORTED) == null) {
            context.setProperty(PROP_ETV_MAX_SEVERITY_REPORTED, 0);
        }
        if (context.getProperty(PROP_ETV_TOTAL_MAX_REACHED_REPORTED) == null) {
            context.setProperty(PROP_ETV_TOTAL_MAX_REACHED_REPORTED, false);
        }
    }

    /**
     * Initializes the context for validation reporting
     * @param context
     */
    public static void initValidationReportingState(final MediationContext context) {

        // context does not already have a helper, so initialize this context with a new helper that functions as global state
        if (context.getProperty(PROP_HELPER) == null) {
            context.setProperty(PROP_HELPER, new ReportValidationsHelper(context));
        }

        context.setProperty(PROP_ETV_REPORTED_MESSAGES, 0);
        context.setProperty(PROP_ETV_REPORT_MAX_REACHED, false);
        context.setProperty(PROP_ETV_REPORT_CURRENT_MESSAGE, true);
    }

    /**
     * Check the global state to determine whether or not to report a validation message and max exceeded message.
     * @param localContext
     */
    public static void checkValidationReportingState(final MediationContext localContext) {
        final ReportValidationsHelper helper = (ReportValidationsHelper) localContext.getProperty(PROP_HELPER);
        localContext.setProperty(PROP_ETV_REPORT_CURRENT_MESSAGE, false);

        // read info from the local context
        Integer etvReportedMessages = (Integer) localContext.getProperty(PROP_ETV_REPORTED_MESSAGES);
        final Integer etvMaxMessages = (Integer) localContext.getProperty(PROP_ETV_MAX_MESSAGES);
        final Integer etvMaxTotalMessages = (Integer) localContext.getProperty(PROP_ETV_MAX_TOTAL_MESSAGES);
        final ETVInfo etvInfo = (ETVInfo) localContext.getProperty(PROP_ETV_INFO);

        // peek at parent context for initial checks prior to synchronized block
        Integer etvMaxSeverityReported = (Integer) helper.parentContext.getProperty(PROP_ETV_MAX_SEVERITY_REPORTED);
        Integer etvTotalReportedMessages = (Integer) helper.parentContext.getProperty(PROP_ETV_TOTAL_REPORTED_MESSAGES);
        Boolean etvTotalMaxReachedReported = (Boolean) helper.parentContext.getProperty(PROP_ETV_TOTAL_MAX_REACHED_REPORTED);

        // initial checks to avoid unnecessarily going into the synchronized block
        if (etvInfo.getSeverity().level > etvMaxSeverityReported
                || (etvReportedMessages < etvMaxMessages && etvTotalReportedMessages < etvMaxTotalMessages)) {

            boolean reportCurrentMessage = false;
            boolean reportMaxReachedMessage = false;
            String reportMaxReachedMessageType = null;

            // check and update parent context inside synchronized block
            synchronized (helper.syncLock) {

                // re-get the relevant parent context props
                etvTotalReportedMessages = (Integer) helper.parentContext.getProperty(PROP_ETV_TOTAL_REPORTED_MESSAGES);
                etvMaxSeverityReported = (Integer) helper.parentContext.getProperty(PROP_ETV_MAX_SEVERITY_REPORTED);
                etvTotalMaxReachedReported = (Boolean) helper.parentContext.getProperty(PROP_ETV_TOTAL_MAX_REACHED_REPORTED);

                // if severity is higher than previously seen, then always report it
                if (etvInfo.getSeverity().level > etvMaxSeverityReported.intValue()) {
                    reportCurrentMessage = true;
                    helper.parentContext.setProperty(PROP_ETV_MAX_SEVERITY_REPORTED, Integer.valueOf(etvInfo.getSeverity().level));
                }
                // otherwise only report it if we are still below the specified maximums
                else if (etvReportedMessages < etvMaxMessages && etvTotalReportedMessages < etvMaxTotalMessages) {
                    reportCurrentMessage = true;
                }

                if (reportCurrentMessage) {
                    // increment total count
                    etvTotalReportedMessages = etvTotalReportedMessages + 1;
                    helper.parentContext.setProperty(PROP_ETV_TOTAL_REPORTED_MESSAGES, etvTotalReportedMessages);

                    // check if we need to report the total max was reached, and that hasn't already been done
                    if (!etvTotalMaxReachedReported && etvTotalReportedMessages >= etvMaxTotalMessages) {
                        reportMaxReachedMessage = true;
                        reportMaxReachedMessageType = "integration";
                        helper.parentContext.setProperty(PROP_ETV_TOTAL_MAX_REACHED_REPORTED, true);
                    }
                }

            } // end synchronized parent context work

            // now update local context
            if (reportCurrentMessage) {
                localContext.setProperty(PROP_ETV_REPORT_CURRENT_MESSAGE, true);
                etvReportedMessages = etvReportedMessages + 1;
                localContext.setProperty(PROP_ETV_REPORTED_MESSAGES, etvReportedMessages);
            }

            // if not already set earlier to report max reached due to total max limit, then check the local per instance max limit
            if (!etvTotalMaxReachedReported && !reportMaxReachedMessage && (etvReportedMessages >= etvMaxMessages)) {
                reportMaxReachedMessage = true;
                reportMaxReachedMessageType = "current entity";
            }

            // set the context to report the max reached message, which will be done after the loop is exited.
            if (reportMaxReachedMessage) {
                localContext.setProperty(PROP_ETV_REPORT_MAX_REACHED, reportMaxReachedMessage);
                localContext.setProperty(PROP_ETV_MAX_REACHED_TYPE, reportMaxReachedMessageType);
            }
        }
    }
}

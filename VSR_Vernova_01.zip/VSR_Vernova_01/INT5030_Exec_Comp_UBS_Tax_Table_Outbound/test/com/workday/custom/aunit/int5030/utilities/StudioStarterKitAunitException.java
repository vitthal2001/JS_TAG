package com.workday.custom.aunit.int5030.utilities;

public class StudioStarterKitAunitException extends Exception {

	private static final long serialVersionUID = 4971446697850367070L;
}

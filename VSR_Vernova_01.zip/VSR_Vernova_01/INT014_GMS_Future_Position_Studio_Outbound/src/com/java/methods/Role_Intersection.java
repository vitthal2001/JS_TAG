package com.java.methods;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Role_Intersection {
	
	public static String Intersection(String First, String Second)
	{	
		
		String[] first1 = First.split("\\|");
		String[] second1 = Second.split("\\|");
		Set<String> s1 = new HashSet<>(Arrays.asList(first1) );
    	Set<String> s2 = new HashSet<>(Arrays.asList(second1) );
    	s1.retainAll(s2);
    	String Final = s1.toString().replaceAll(", ", "!");
    	Final = Final.replace("[","");
    	Final = Final.replace("]","");
    	return Final;		
		
	}

}

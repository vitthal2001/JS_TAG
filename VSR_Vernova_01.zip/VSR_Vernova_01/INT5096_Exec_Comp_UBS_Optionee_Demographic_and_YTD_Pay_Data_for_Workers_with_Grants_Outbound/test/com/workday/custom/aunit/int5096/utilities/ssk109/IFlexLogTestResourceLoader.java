package com.workday.custom.aunit.int5096.utilities.ssk109;

public interface IFlexLogTestResourceLoader {

	public void loadFileToVariable(String variable, String fileResouce, String contentType) throws Throwable;
}

package com.workday.custom.aunit.int5096.main;

import com.workday.aunit.annotations.AssemblyTest;
import com.workday.aunit.annotations.AssertAfter;
import com.workday.aunit.annotations.UnitTest;
import com.workday.custom.aunit.int5096.CommonTestCase;

@AssemblyTest(project="INT5096_Exec_Comp_UBS_Optionee_Demographic_and_YTD_Pay_Data_for_Workers_with_Grants_Outbound")
public class FoundationTestCase extends CommonTestCase {


	/**************************************************************************************************************
	 ************************************************************************************************************** 
	 * 
	 * Test Entry Points
	 * 
	 **************************************************************************************************************
	 **************************************************************************************************************/
	@UnitTest(startComponent="ConfigurationSetup")
	public void testFoundation() throws Exception { }

	
	/**************************************************************************************************************
	 ************************************************************************************************************** 
	 * 
	 * Test Validations
	 * 
	 **************************************************************************************************************
	 **************************************************************************************************************/
	@Override
	protected void extendedExitStateVerification(Throwable t) throws Exception { }
	
	@AssertAfter(id="Foundation_152", step="SetConstantValues")
	public void verifyInitialization() throws Exception {
		assertTrue(String.format(MESSAGE_UNEXPECTED_TYPE, PROP_GLOBAL_API_VERSION), ctx.getProperty(PROP_GLOBAL_API_VERSION) instanceof String);
		assertEquals(String.format(MESSAGE_UNEXPECTED_VALUE, PROP_GLOBAL_API_VERSION), VALUE_API_VERSION, (String)ctx.getProperty(PROP_GLOBAL_API_VERSION));
	}
	
	/**************************************************************************************************************
	 ************************************************************************************************************** 
	 * 
	 * Mocks
	 * 
	 **************************************************************************************************************
	 **************************************************************************************************************/
}

package com.java.methods;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MgrVsEmp {
	
	public static String Minus(String First, String Second)
	{	
		String SCheck= "";
		String SEmp= "";
		String SCwr= "";	
		
		String[] first1 = First.split("\\|");
		String[] second1 = Second.split("\\|");
		Set<String> s1 = new HashSet<>(Arrays.asList(first1) );
    	Set<String> s2 = new HashSet<>(Arrays.asList(second1) );
    	
    	s2.removeAll(s1);
    	String Final = s2.toString().replaceAll(", ", "!");
    	Final = Final.replace("[","");
    	Final = Final.replace("]",""); 	
    	
    	String StrMgrList= Final; 
    	String[] arrMgrList = StrMgrList.split("\\!");	
    	
    	for(int i = 0; i< arrMgrList.length; i++)
		{
    		Final = arrMgrList[i].toString();  		
    		if (arrMgrList[i].toString().isEmpty()) 
    		{
    			Final = "Test";			
    		}
    		else
    		{
    			SCheck = Final.substring(0,1);    			 
    			if (SCheck.equals("E"))			
    			{
    			  	SEmp = SEmp + "<int:Worker><int:ID int:type='Employee_ID'>"+ arrMgrList[i].toString().substring(1,arrMgrList[i].toString().length()) +"</int:ID></int:Worker>";
    			}
    			if (SCheck.equals("C"))
    			{
    				SCwr = SCwr + "<int:Worker><int:ID int:type='Contingent_Worker_ID'>"+ arrMgrList[i].toString().substring(1,arrMgrList[i].toString().length()) +"</int:ID></int:Worker>";
    				
    			}
    		}
		}
	    
    	Final= SEmp + "®" + SCwr;
    	return Final;
	}
		
	}

 